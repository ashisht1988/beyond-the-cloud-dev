---
sidebar_position: 10
---

# SOQL

Apex Classes: `SOQL.cls` and `SOQL_Test.cls`.

The lib main class for query construction.

```apex title="Basic Usage Example"
SOQL.of(Account.SObjectType)
    .with(Account.Id, Account.Name)
    .toList();
```

## Methods

The following are methods for using `SOQL`:

[**INIT**](#init)

- [`of(SObjectType ofObject)`](#of)
- [`of(String ofObject)`](#of)

[**SELECT**](#select)

- [`with(SObjectField field)`](#with-fields)
- [`with(SObjectField field1, SObjectField field2)`](#with-field1---field5)
- [`with(SObjectField field1, SObjectField field2, SObjectField field3)`](#with-field1---field5)
- [`with(SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4)`](#with-field1---field5)
- [`with(SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4, SObjectField field5)`](#with-field1---field5)
- [`with(List<SObjectField> fields)`](#with-fields)
- [`with(List<String> fields)`](#with-fields)
- [`with(String fields)`](#with-string-fields)
- [`with(String relationshipName, SObjectField field)`](#with-related-field1---field5)
- [`with(String relationshipName, SObjectField field1, SObjectField field2)`](#with-related-field1---field5)
- [`with(String relationshipName, SObjectField field1, SObjectField field2, SObjectField field3)`](#with-related-field1---field5)
- [`with(String relationshipName, SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4)`](#with-related-field1---field5)
- [`with(String relationshipName, SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4, SObjectField field5)`](#with-related-field1---field5)
- [`with(String relationshipName, Iterable<SObjectField> fields)`](#with-related-fields)
- [`withFieldSet(String fieldSetName)`](#with-field-set)

[**AGGREGATION FUNCTIONS**](#aggregate-functions)

- [`count()`](#count)
- [`count(SObjectField field)`](#count-field)
- [`count(SObjectField field, String alias)`](#count-with-alias)
- [`count(String relationshipName, SObjectField field)`](#count-related-field)
- [`count(String relationshipName, SObjectField field, String alias)`](#count-related-field-with-alias)
- [`avg(SObjectField field)`](#avg)
- [`avg(SObjectField field, String alias)`](#avg-with-alias)
- [`avg(String relationshipName, SObjectField field)`](#avg-related-field)
- [`avg(String relationshipName, SObjectField field, String alias)`](#avg-related-field-with-alias)
- [`countDistinct(SObjectField field)`](#count_distinct)
- [`countDistinct(SObjectField field, String alias)`](#count_distinct-with-alias)
- [`countDistinct(String relationshipName, SObjectField field)`](#count-related-field)
- [`countDistinct(String relationshipName, SObjectField field, String alias)`](#count_distinct-with-alias)
- [`min(SObjectField field)`](#min)
- [`min(SObjectField field, String alias)`](#min-with-alias)
- [`min(String relationshipName, SObjectField field)`](#min-related-field)
- [`min(String relationshipName, SObjectField field)`](#min-related-field-with-alias)
- [`max(SObjectField field)`](#max)
- [`max(SObjectField field, String alias)`](#max-with-alias)
- [`max(String relationshipName, SObjectField field)`](#max-related-field)
- [`max(String relationshipName, SObjectField field, String alias)`](#max-related-field-with-alias)
- [`sum(SObjectField field)`](#sum)
- [`sum(SObjectField field, String alias)`](#sum-with-alias)
- [`sum(String relationshipName, SObjectField field)`](#sum-related-field)
- [`sum(String relationshipName, SObjectField field, String alias)`](#sum-related-field-with-alias)

[**GROUPING**](#grouping)

- [`grouping(SObjectField field, String alias)`](#grouping)

[**toLabel**](#tolabel)

- [`toLabel(SObjectField field)`](#tolabel)
- [`toLabel(SObjectField field, String alias)`](#tolabel)
- [`toLabel(String field)`](#tolabel)
- [`toLabel(String field, String alias)`](#tolabel)

[**format**](#format)

- [`format(SObjectField field)`](#format)
- [`format(SObjectField field, String alias)`](#format)

[**SUBQUERY**](#sub-query)

- [`with(SubQuery subQuery)`](#with-subquery)

[**USING SCOPE**](#using-scope)

- [`delegatedScope()`](#delegatedscope)
- [`mineScope()`](#minescope)
- [`mineAndMyGroupsScope()`](#mineandmygroupsscope)
- [`myTerritoryScope()`](#myterritoryscope)
- [`myTeamTerritoryScope()`](#myteamterritoryscope)
- [`teamScope()`](#teamscope)

[**WHERE**](#where)

- [`whereAre(FilterGroup filterGroup)`](#whereare)
- [`whereAre(Filter filter)`](#whereare)
- [`whereAre(String dynamicCondition)`](#whereare-string)
- [`conditionLogic(String order)`](#conditionlogic)
- [`anyConditionMatching()`](#anyconditionmatching);

[**GROUP BY**](#group-by)

- [`groupBy(SObjectField field)`](#group-by)
- [`groupBy(String relationshipName, SObjectField field)`](#groupby-related)
- [`groupByRollup(SObjectField field)`](#groupbyrollup)
- [`groupByRollup(String relationshipName, SObjectField field)`](#groupbyrollup-related)
- [`groupByCube(SObjectField field)`](#groupbycube)
- [`groupByCube(String relationshipName, SObjectField field)`](#groupbycube-related)

[**WITH DATA_CATEGORY**](#with-data_category)

- [`withDataCategory(DataCategoryFilter dataCategoryFilter)`](#with-data_category)

[**HAVING**](#having)

- [`have(HavingFilterGroup filterGroup)`](#have)
- [`have(HavingFilter filter)`](#have)
- [`have(String dynamicCondition)`](#having-string)
- [`havingConditionLogic(String order)`](#havingconditionlogic)
- [`anyHavingConditionMatching()`](#anyhavingconditionmatching)

[**ORDER BY**](#order-by)

- [`orderBy(SObjectField field)`](#order-by)
- [`orderBy(String field)`](#order-by)
- [`orderBy(String field, String direction)`](#order-by)
- [`orderBy(String relationshipName, SObjectField field)`](#orderby-related)
- [`orderByCount(SObjectField field)`](#orderby-count)
- [`sordDesc()`](#sortdesc)
- [`sort(String direction)`](#sort)
- [`nullsLast()`](#nullslast)
- [`nullsOrder(String nullsOrder)`](#nulls-order)


[**LIMIT**](#limit)

- [`setLimit(Integer amount)`](#setlimit)

[**OFFSET**](#offset)

- [`offset(Integer startingRow)`](#offset)

[**FOR**](#for)

- [`forReference()`](#forreference)
- [`forView()`](#forview)
- [`forUpdate()`](#forupdate)
- [`allRows()`](#allrows)

[**FIELD-LEVEL SECURITY**](#field-level-security)

- [`userMode()`](#usermode)
- [`systemMode()`](#systemmode)
- [`stripInaccessible()`](#stripinaccessible)
- [`stripInaccessible(AccessType accessType)`](#stripinaccessible)

[**SHARING MODE**](#sharing-mode)

- [`withSharing()`](#withsharing)
- [`withoutSharing()`](#withoutsharing)

[**MOCKING**](#mocking)

- [`mockId(String id)`](#mockid)
- [`SOQL.mock(String mockId).thenReturn(SObject record)`](#record-mock)
- [`SOQL.mock(String mockId).thenReturn(List<SObject> records)`](#record-mock)
- [`SOQL.mock(String mockId).thenReturn(Integer amount)`](#count-mock)
- [`SOQL.mock(SObjectType ofObject).thenReturn(SObject record)`](#sobject-type-mock)
- [`SOQL.mock(SObjectType ofObject).thenReturn(List<SObject> records)`](#sobject-type-mock)
- [`SOQL.mock(SObjectType ofObject).thenReturn(Integer amount)`](#sobject-type-mock)
- [`SOQL.mock(String mockId).throwException()`](#exception-mock)
- [`SOQL.mock(String mockId).throwException(String message)`](#exception-mock-with-message)

[**DEBUGGING**](#debugging)

- [`preview()`](#preview)

[**PREDEFINIED**](#predefinied)

- [`byId(SObject record)`](#byid)
- [`byId(Id recordId)`](#byid)
- [`byIds(Iterable<Id> recordIds)`](#byids)
- [`byIds(List<SObject> records)`](#byids)
- [`byRecordType(String recordTypeDeveloperName)`](#byrecordtype)

[**RESULT**](#result)

- [`toId()`](#toid)
- [`toIds()`](#toids)
- [`toIdsOf(SObjectField field)`](#toidsof)
- [`toIdsOf(String relationshipName, SObjectField field)`](#toidsof-related-field)
- [`doExist()`](#doexist)
- [`toValueOf(SObjectField fieldToExtract)`](#tovalueof)
- [`toValuesOf(SObjectField fieldToExtract)`](#tovaluesof)
- [`toInteger()`](#tointeger)
- [`toObject()`](#toobject)
- [`toList()`](#tolist)
- [`toAggregated()`](#toaggregated)
- [`toMap()`](#tomap)
- [`toMap(SObjectField keyField)`](#tomap-with-custom-key)
- [`toMap(String relationshipName, SObjectField targetKeyField)`](#tomap-with-custom-relationship-key)
- [`toMap(SObjectField keyField,  SObjectField valueField)`](#tomap-with-custom-key-and-value)
- [`toAggregatedMap(SObjectField keyField)`](#toaggregatedmap)
- [`toAggregatedMap(String relationshipName, SObjectField targetKeyField)`](#toaggregatedmap-with-custom-relationship-key)
- [`toAggregatedMap(SObjectField keyField, SObjectField valueField)`](#toaggregatedmap-with-custom-value)
- [`toIdMapBy(SObjectField field)`](#toidmapby)
- [`toIdMapBy(String relationshipName, SObjectField targetKeyField)`](#toidmapby-with-relationship)
- [`toAggregatedIdMapBy(SObjectField keyField)`](#toaggregateidmapby)
- [`toAggregatedIdMapBy(String relationshipName, SObjectField targetKeyField)`](#toaggregateidmapby-with-relationship)
- [`toQueryLocator()`](#toquerylocator)
- [`toCursor()`](#tocursor)

## INIT
### of

Constructs an `SOQL`.

**Signature**

```apex title="Method Signatures"
Queryable of(SObjectType ofObject)
Queryable of(String ofObject)
```

**Example**

```sql title="SOQL Query"
SELECT Id FROM Account
```
```apex title="SOQL Lib Implementation"
SOQL.of(Account.SObjectType).toList();
SOQL.of('Account').toList();
```

## SELECT

### with field1 - field5

**Signature**

```apex title="Single Field Method"
Queryable with(SObjectField field)
```
```apex title="Two Fields Method"
Queryable with(SObjectField field1, SObjectField field2);
```
```apex title="Three Fields Method"
Queryable with(SObjectField field1, SObjectField field2, SObjectField field3);
```
```apex title="Four Fields Method"
Queryable with(SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4);
```
```apex title="Five Fields Method"
Queryable with(SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4, SObjectField field5);
```

**Example**

```sql title="SOQL Query"
SELECT Id, Name
FROM Account
```
```apex title="SOQL Lib Field Selection"
SOQL.of(Account.SObjectType)
    .with(Account.Id, Account.Name)
    .toList();

// or

SOQL.of(Account.SObjectType)
    .with(Account.Id)
    .with(Account.Name)
    .toList();
```

### with fields

[SELECT](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_fields.htm)

> `SELECT` statement that specifies the fields to query. The fieldList in the `SELECT` statement specifies the list of one or more fields, separated by commas, that you want to retrieve.

Use for more than 5 fields.

**Signature**

```apex title="Method Signatures"
Queryable with(List<SObjectField> fields)
Queryable with(List<String> fields)
```

**Example**

```sql title="SOQL Query"
SELECT Id, Name, Industry, AccountNumber, AnnualRevenue, BillingCity
FROM Account
```
```apex title="SOQL Lib with List of SObjectFields"
SOQL.of(Account.SObjectType)
    .with(new List<SObjectField>{
        Account.Id,
        Account.Name,
        Account.Industry,
        Account.AccountNumber,
        Account.AnnualRevenue,
        Account.BillingCity
    }).toList();

SOQL.of(Account.SObjectType)
    .with(new List<String>{
        'Id',
        'Name',
        'Industry',
        'AccountNumber',
        'AnnualRevenue',
        'BillingCity'
    }).toList();
```

### with string fields

**NOTE!** With String Apex does not create reference to field. Use `SObjectField` whenever it possible. Method below should be only use for dynamic queries.

**Signature**

```apex title="Method Signature"
Queryable with(String fields)
```

**Example**

```sql title="SOQL Query"
SELECT Id, Name, Industry
FROM Account
```
```apex title="SOQL Lib with String Fields"
SOQL.of(Account.SObjectType)
    .with('Id, Name, Industry')
    .toList();
```

### with related field1 - field5

Allows to add parent field to a query.

**Signature**

```apex title="Single Related Field Method"
Queryable with(String relationshipName, SObjectField field)
```
```apex title="Two Related Fields Method"
Queryable with(String relationshipName, SObjectField field1, SObjectField field2);
```
```apex title="Three Related Fields Method"
Queryable with(String relationshipName, SObjectField field1, SObjectField field2, SObjectField field3);
```
```apex title="Four Related Fields Method"
Queryable with(String relationshipName, SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4);
```
```apex title="Five Related Fields Method"
Queryable with(String relationshipName, SObjectField field1, SObjectField field2, SObjectField field3, SObjectField field4, SObjectField field5);
```

**Example**

```sql title="SOQL Query"
SELECT CreatedBy.Name
FROM Account
```
```apex title="SOQL Lib Related Fields"
SOQL.of(Account.SObjectType)
    .with('CreatedBy', User.Name)
    .toList();

SOQL.of(Account.SObjectType)
    .with('CreatedBy', User.Id, User.Name, User.Phone)
    .toList();
```

### with related fields

Allows to add parent fields to a query.

Use for more than 5 parent fields.

**Signature**

```apex title="Method Signature"
Queryable with(String relationshipName, Iterable<SObjectField> fields)
```

**Example**

```sql
SELECT
    CreatedBy.Id,
    CreatedBy.Name,
    CreatedBy.Phone,
    CreatedBy.FirstName,
    CreatedBy.LastName,
    CreatedBy.Email
FROM Account
```
```apex
SOQL.of(Account.SObjectType)
    .with('CreatedBy', new List<SObjectField>{
        User.Id,
        User.Name,
        User.Phone,
        User.FirstName,
        User.LastName,
        User.Email
    }).toList();
```

### with field set

Pass FieldSet name to get dynamic fields.

**Signature**

```apex
Queryable withFieldSet(String fieldSetName)
```

**Example**

```sql
SELECT
    Id,
    Name,
    Industry
FROM Account
```
```apex
SOQL.of(Account.SObjectType)
    .withFieldSet('AccountFieldSet')
    .toList();
```

## SUB-QUERY

### with subquery

[Using Relationship Queries](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_relationships_query_using.htm)

> Use SOQL to query several relationship types.

For more details check [`SOQL.SubQuery`](soql-sub.md) class.

**Signature**

```apex
Queryable with(SOQL.SubQuery subQuery)
```

**Example**

```sql
SELECT Id, (
    SELECT Id, Name
    FROM Contacts
) FROM Account
```
```apex
SOQL.of(Account.SObjectType)
    .with(SOQL.SubQuery.of('Contacts')
        .with(Contact.Id, Contact.Name)
    ).toList();
```

## [AGGREGATE FUNCTIONS](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_agg_functions.htm)

**Note!** To avoid the `Field must be grouped or aggregated` error, any default fields that are neither in Aggregation Functions nor included in the [GROUP BY](#group-by) clause will be automatically removed.

### count

[COUNT()](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_count.htm#count_section_title)

> `COUNT()` returns the number of rows that match the filtering conditions.

**Note!** COUNT() must be the only element in the SELECT list, any other fields will be automatically removed.

**Signature**

```apex
Queryable count()
```

**Example**

```sql
SELECT COUNT()
FROM Account
```
```apex
SOQL.of(Account.SObjectType).toInteger();

// or

SOQL.of(Account.SObjectType)
    .count()
    .toInteger();
```

### count field

**Signature**

```apex
count(SObjectField field)
```

**Note!** To avoid the `Field must be grouped or aggregated` error, any default fields will be automatically removed.

You can still specify additional fields, but they should be placed after the COUNT() function in the SELECT statement.

**Example**

```sql
SELECT COUNT(Id), COUNT(CampaignId)
FROM Opportunity
```
```apex
 SOQL.of(Opportunity.SObjectType)
    .count(Opportunity.Id)
    .count(Opportunity.CampaignId)
    .toAggregated();
```

### count with alias

**Signature**

```apex
Queryable count(SObjectField field, String alias)
```

**Example**

```sql
SELECT COUNT(Name) names FROM Account
```
```apex
SOQL.of(Account.SObjectType)
    .count(Account.Name, 'names')
    .toAggregated();
```

### count related field

**Signature**

```apex
count(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT COUNT(Account.Name) FROM Contact
```
```apex
SOQL.of(Contact.SObjectType)
    .count('Account', Account.Name)
    .toAggregated();
```

### count related field with alias

**Signature**

```apex
Queryable count(String relationshipName, SObjectField field, String alias)
```

**Example**

```sql
SELECT COUNT(Account.Name) names FROM Contact
```
```apex
SOQL.of(Contact.SObjectType)
    .count('Account', Account.Name, 'names')
    .toAggregated();
```

### avg

**Signature**

```apex
Queryable avg(SObjectField field)
```

**Example**

```sql
SELECT CampaignId, AVG(Amount) FROM Opportunity GROUP BY CampaignId
```
```apex
SOQL.of(Opportunity.SObjectType)
    .with(Opportunity.CampaignId)
    .avg(Opportunity.Amount)
    .groupBy(Opportunity.CampaignId)
    .toAggregate();
```

### avg with alias

**Signature**

```apex
Queryable avg(SObjectField field, String alias)
```

**Example**

```sql
SELECT CampaignId, AVG(Amount) amount FROM Opportunity GROUP BY CampaignId
```
```apex
SOQL.of(Opportunity.SObjectType)
    .with(Opportunity.CampaignId)
    .avg(Opportunity.Amount, 'amount')
    .groupBy(Opportunity.CampaignId)
    .toAggregate();
```

### avg related field

**Signature**

```apex
avg(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT AVG(Opportunity.Amount) FROM OpportunityLineItem
```
```apex
SOQL.of(OpportunityLineItem.SObjectType)
    .avg('Opportunity', Opportunity.Amount)
    .toAggregate();
```

### avg related field with alias

**Signature**

```apex
Queryable avg(String relationshipName, SObjectField field, String alias)
```

**Example**

```sql
SELECT AVG(Opportunity.Amount) amount FROM OpportunityLineItem
```
```apex
SOQL.of(OpportunityLineItem.SObjectType)
    .avg('Opportunity', Opportunity.Amount, 'amount')
    .toAggregate();
```

### count_distinct

**Signature**

```apex
Queryable countDistinct(SObjectField field
```

**Example**

```sql
SELECT COUNT_DISTINCT(Company) FROM Lead
```
```apex
SOQL.of(Lead.SObjectType)
    .countDistinct(Lead.Company)
    .toAggregate();
```

### count_distinct with alias

**Signature**

```apex
Queryable countDistinct(SObjectField field, String alias)
```

**Example**

```sql
SELECT COUNT_DISTINCT(Company) company FROM Lead
```
```apex
SOQL.of(Lead.SObjectType)
    .countDistinct(Lead.Company, 'company')
    .toAggregate();
```

### count_distinct related field

**Signature**

```apex
Queryable countDistinct(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT COUNT_DISTINCT(Lead.Company) FROM CampaignMember
```
```apex
SOQL.of(CampaignMember.SObjectType)
    .countDistinct('Lead', Lead.Company)
    .toAggregate();
```

### count_distinct related field with aliast

**Signature**

```apex
Queryable countDistinct(String relationshipName, SObjectField field, String alias)
```

**Example**

```sql
SELECT COUNT_DISTINCT(Lead.Company) company FROM CampaignMember
```
```apex
SOQL.of(CampaignMember.SObjectType)
    .countDistinct('Lead', Lead.Company, 'company')
    .toAggregate();
```

### min

**Signature**

```apex
Queryable min(SObjectField field)
```

**Example**

```sql
SELECT FirstName, LastName, MIN(CreatedDate)
FROM Contact
GROUP BY FirstName, LastName
```
```apex
SOQL.of(Contact.SObjectType)
    .with(Contact.FirstName, Contact.LastName)
    .min(Contact.CreatedDate)
    .groupBy(Contact.FirstName)
    .groupBy(Contact.LastName)
    .toAggregate();
```

### min with alias

**Signature**

```apex
Queryable min(SObjectField field, String alias)
```

**Example**

```sql
SELECT FirstName, LastName, MIN(CreatedDate) createDate
FROM Contact
GROUP BY FirstName, LastName
```
```apex
SOQL.of(Contact.SObjectType)
    .with(Contact.FirstName, Contact.LastName)
    .min(Contact.CreatedDate, 'createDate')
    .groupBy(Contact.FirstName)
    .groupBy(Contact.LastName)
    .toAggregate();
```

### min related field

**Signature**

```apex
Queryable min(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT MIN(Account.CreatedDate) FROM Contact
```
```apex
SOQL.of(Contact.SObjectType)
    .min('Account', Account.CreatedDate)
    .toAggregate();
```

### min related field with alias

**Signature**

```apex
Queryable min(String relationshipName, SObjectField field, String alias)
```

**Example**

```sql
SELECT MIN(Account.CreatedDate) createdDate FROM Contact
```
```apex
SOQL.of(Contact.SObjectType)
    .min('Account', Account.CreatedDate, 'createdDate')
    .toAggregate();
```

### max

**Signature**

```apex
Queryable max(SObjectField field)
```

**Example**

```sql
SELECT Name, MAX(BudgetedCost)
FROM Campaign
GROUP BY Name
```
```apex
 SOQL.of(Campaign.SObjectType)
    .with(Campaign.Name)
    .max(Campaign.BudgetedCost)
    .groupBy(Campaign.Name)
    .toAggregate();
```

### max with alias

**Signature**

```apex
Queryable max(SObjectField field, String alias)
```

**Example**

```sql
SELECT Name, MAX(BudgetedCost) budgetedCost
FROM Campaign
GROUP BY Name
```
```apex
 SOQL.of(Campaign.SObjectType)
    .with(Campaign.Name)
    .max(Campaign.BudgetedCost, 'budgetedCost')
    .groupBy(Campaign.Name)
    .toAggregate();
```

### max related field

**Signature**

```apex
Queryable max(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT MAX(Campaign.BudgetedCost) FROM CampaignMember
```
```apex
SOQL.of(CampaignMember.SObjectType)
    .max('Campaign', Campaign.BudgetedCost)
    .toAggregate();
```

### max related field with alias

**Signature**

```apex
Queryable max(String relationshipName, SObjectField field, String alias)
```

**Example**

```sql
SELECT MAX(Campaign.BudgetedCost) budgetedCost FROM CampaignMember
```
```apex
SOQL.of(CampaignMember.SObjectType)
    .max('Campaign', Campaign.BudgetedCost, 'budgetedCost')
    .toAggregate();
```

### sum

**Signature**

```apex
Queryable sum(SObjectField field)
```

**Example**

```sql
SELECT SUM(Amount) FROM Opportunity
```
```apex
SOQL.of(Opportunity.SObjectType)
    .sum(Opportunity.Amount)
    .toAggregate();
```

### sum with alias

**Signature**

```apex
Queryable sum(SObjectField field, String alias)
```

**Example**

```sql
SELECT SUM(Amount) amount FROM Opportunity
```
```apex
SOQL.of(Opportunity.SObjectType)
    .sum(Opportunity.Amount, 'amount')
    .toAggregate();
```

## GROUPING

### grouping

**Signature**

```apex
Queryable grouping(SObjectField field, String alias)
```

**Example**

```sql
SELECT LeadSource, Rating,
    GROUPING(LeadSource) grpLS, GROUPING(Rating) grpRating,
    COUNT(Name) cnt
FROM Lead
GROUP BY ROLLUP(LeadSource, Rating)
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource, Lead.Rating)
    .grouping(Lead.LeadSource, 'grpLS')
    .grouping(Lead.Rating, 'grpRating')
    .count(Lead.Name, 'cnt')
    .groupByRollup(Lead.LeadSource)
    .groupByRollup(Lead.Rating)
    .toAggregated();
```

### sum related field

**Signature**

```apex
sum(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT SUM(Opportunity.Amount) FROM OpportunityLineItem
```
```apex
SOQL.of(OpportunityLineItem.SObjectType)
    .sum('Opportunity', Opportunity.Amount)
    .toAggregate();
```

### sum related field with alias

**Signature**

```apex
Queryable sum(String relationshipName, SObjectField field, String alias)
```

**Example**

```sql
SELECT SUM(Opportunity.Amount) amount FROM OpportunityLineItem
```
```apex
SOQL.of(OpportunityLineItem.SObjectType)
    .sum('Opportunity', Opportunity.Amount, 'amount')
    .toAggregate();
```

## toLabel

> To translate SOQL query results into the language of the user who submits the query, use the toLabel method.

**Signature**

```apex
Queryable toLabel(SObjectField field)
Queryable toLabel(SObjectField field, String alias)
Queryable toLabel(String field)
Queryable toLabel(String field, String alias)
```

**Example**

```sql
SELECT Company, toLabel(Status) FROM Lead
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.Company)
    .toLabel(Lead.Status)
    .toList();
```

```sql
SELECT Company, toLabel(Status) leadStatus FROM Lead
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.Company)
    .toLabel(Lead.Status, 'leadStatus')
    .toList();
```

```sql
SELECT Company, toLabel(Recordtype.Name) FROM Lead
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.Company)
    .toLabel('Recordtype.Name')
    .toList();
```

```sql
SELECT Company, toLabel(Recordtype.Name) recordTypeName FROM Lead
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.Company)
    .toLabel('Recordtype.Name', 'recordTypeName')
    .toList();
```

## format

**Signature**

```apex
format(SObjectField field)
format(SObjectField field, String alias)
```

**Example**

```sql
SELECT FORMAT(Amount) FROM Opportunity
```
```apex
SOQL.of(Opportunity.SObjectType)
    .format(Opportunity.Amount)
    .toList();
```

```sql
SELECT FORMAT(Amount) amt FROM Opportunity
```
```apex
SOQL.of(Opportunity.SObjectType)
    .format(Opportunity.Amount, 'amt')
    .toList();
```

## USING SCOPE

[USING SCOPE](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_using_scope.htm)

### delegatedScope

> Filter for records delegated to another user for action. For example, a query could filter for only delegated Task records.

**Signature**

```apex
Queryable delegatedScope()
```

**Example**

```sql
SELECT Id
FROM Task
USING SCOPE DELEGATED
```
```apex
SOQL.of(Task.SObjectType)
    .delegatedScope()
    .toList();
```

### mineScope

> Filter for records owned by the user running the query.

**Signature**

```apex
Queryable mineScope()
```

**Example**

```sql
SELECT Id
FROM Account
USING SCOPE MINE
```
```apex
SOQL.of(Account.SObjectType)
    .mineScope()
    .toList();
```

### mineAndMyGroupsScope

> Filter for records assigned to the user running the query and the user’s queues. If a user is assigned to a queue, the user can access records in the queue. This filter applies only to the ProcessInstanceWorkItem object.

**Signature**

```apex
Queryable mineAndMyGroupsScope()
```

**Example**

```sql
SELECT Id
FROM ProcessInstanceWorkItem
USING SCOPE MINE_AND_MY_GROUPS
```
```apex
SOQL.of(ProcessInstanceWorkItem.SObjectType)
    .mineAndMyGroupsScope()
    .toList();
```

### myTerritoryScope

> Filter for records in the territory of the user running the query. This option is available if territory management is enabled for your organization.

**Signature**

```apex
Queryable myTerritoryScope()
```

**Example**

```sql
SELECT Id
FROM Opportunity
USING SCOPE MY_TERRITORY
```
```apex
SOQL.of(Opportunity.SObjectType)
    .myTerritoryScope()
    .toList();
```

### myTeamTerritoryScope

> Filter for records in the territory of the team of the user running the query. This option is available if territory management is enabled for your organization.

**Signature**

```apex
Queryable myTeamTerritoryScope()
```

**Example**

```sql
SELECT Id
FROM Opportunity
USING SCOPE MY_TEAM_TERRITORY
```
```apex
SOQL.of(Opportunity.SObjectType)
    .myTeamTerritoryScope()
    .toList();
```

### teamScope

> Filter for records assigned to a team, such as an Account team.

**Signature**

```apex
Queryable teamScope()
```

**Example**

```sql
SELECT Id FROM Account USING SCOPE TEAM
```
```apex
SOQL.of(Account.SObjectType)
    .teamScope()
    .toList();
```

## WHERE

### whereAre

[WHERE](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_conditionexpression.htm)

> The condition expression in a `WHERE` clause of a SOQL query includes one or more field expressions. You can specify multiple field expressions in a condition expression by using logical operators.

For more details check [`SOQL.FilterGroup`](soql-filters-group.md) and [`SOQL.Filter`](soql-filter.md)

**Signature**

```apex
Queryable whereAre(FilterClause conditions)
```

**Example**

```sql
SELECT Id
FROM Account
WHERE Id = :accountId OR Name = '%MyAccount%'
```
```apex
SOQL.of(Account.SObjectType)
    .whereAre(SOQL.FilterGroup
        .add(SOQL.Filter.with(Account.Id).equal(accountId))
        .add(SOQL.Filter.with(Account.Name).contains('MyAccount'))
        .anyConditionMatching()
    ).toList();
```

### whereAre string

Execute conditions passed as String.

**Signature**

```apex
Queryable whereAre(String conditions)
```

**Example**

```sql
SELECT Id
FROM Account
WHERE NumberOfEmployees >=10 AND NumberOfEmployees <= 20
```
```apex
SOQL.of(Account.SObjectType)
    .whereAre('NumberOfEmployees >=10 AND NumberOfEmployees <= 20')
    .toList();
```

### conditionLogic

Set conditions order for SOQL query. When not specify all conditions will be with `AND`.

**Signature**

```apex
Queryable conditionLogic(String order)
```

**Example**

```sql
SELECT Id
FROM Account
WHERE Name = 'Test' AND BillingCity = 'Krakow'
```
```apex
SOQL.of(Account.SObjectType)
    .whereAre(SOQL.Filter.with(Account.Name).equal('Test'))
    .whereAre(SOQL.Filter.with(Account.BillingCity).equal('Krakow'))
    .conditionLogic('1 OR 2')
    .toList();
```

### anyConditionMatching

When the [conditionLogic](#conditionlogic) is not specified, all conditions are joined using the `AND` operator by default.

To change the default condition logic, you can utilize the `anyConditionMatching` method, which joins conditions using the `OR` operator.

**Signature**

```apex
Queryable anyConditionMatching()
```

**Example**

```sql
SELECT Id
FROM Account
WHERE Name = 'Test' AND BillingCity = 'Krakow'
```
```apex
SOQL.of(Account.SObjectType)
    .whereAre(SOQL.Filter.with(Account.Name).equal('Test'))
    .whereAre(SOQL.Filter.with(Account.BillingCity).equal('Krakow'))
    .anyConditionMatching()
    .toList();
```

## GROUP BY

[GROUP BY](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_groupby.htm)

### groupBy

> You can use the `GROUP BY` option in a SOQL query to avoid iterating through individual query results. That is, you specify a group of records instead of processing many individual records.

**Signature**

```apex
Queryable groupBy(SObjectField field)
```

**Example**

```sql
SELECT LeadSource
FROM Lead
GROUP BY LeadSource
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .groupBy(Lead.LeadSource)
    .toAggregated();
```

### groupBy related

**Signature**

```apex
Queryable groupBy(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT COUNT(Name) count
FROM OpportunityLineItem
GROUP BY OpportunityLineItem.Opportunity.Account.Id
```
```apex
SOQL.of(OpportunityLineItem.SObjectType)
    .count(OpportunityLineItem.Name, 'count')
    .groupBy('OpportunityLineItem.Opportunity.Account', Account.Id)
    .toAggregated();
```

### groupByRollup

**Signature**

```apex
Queryable groupByRollup(SObjectField field)
```

**Example**

```sql
SELECT LeadSource, COUNT(Name) cnt
FROM Lead
GROUP BY ROLLUP(LeadSource)
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .count(Lead.Name, 'cnt')
    .groupByRollup(Lead.LeadSource)
    .toAggregated();
```

### groupByRollup related

**Signature**

```apex
Queryable groupByRollup(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT COUNT(Name) cnt
FROM Lead
GROUP BY ROLLUP(ConvertedOpportunity.StageName)
```
```apex
SOQL.of(Lead.SObjectType)
    .count(Lead.Name, 'cnt')
    .groupByRollup('ConvertedOpportunity', Opportunity.StageName)
    .toAggregated();
```

### groupByCube

**Signature**

```apex
Queryable groupByCube(SObjectField field)
```

**Example**

```sql
SELECT Type
FROM Account
GROUP BY CUBE(Type)
```
```apex
SOQL.of(Account.SObjectType)
    .with(Account.Type)
    .groupByCube(Account.Type)
    .toAggregated();
```

### groupByCube related

**Signature**

```apex
Queryable groupByCube(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT COUNT(Name) cnt
FROM Lead
GROUP BY CUBE(ConvertedOpportunity.StageName)
```
```apex
SOQL.of(Lead.SObjectType)
    .count(Lead.Name, 'cnt')
    .groupByCube('ConvertedOpportunity', Opportunity.StageName)
    .toAggregated();
```

## WITH DATA_CATEGORY

For more details check [SOQL.DataCategoryFilter](./soql-data-category-filter.md).

**Signature**

```apex
 Queryable withDataCategory(DataCategoryFilter dataCategoryFilter);
```

**Example**

```sql
SELECT Id, Title
FROM Knowledge__kav
WITH DATA CATEGORY Geography__c AT (Europe__c, North_America__c)
```

```apex
SOQL.of(Knowledge__kav.SObjectType)
    .with(Knowledge__kav.Id, Knowledge__kav.Title)
    .withDataCategory(SOQL.DataCategoryFilter.with('Geography__c').at(new List<String>{ 'Europe__c', 'North_America__c' }))
    .toList();
```

## HAVING

### have

[HAVING](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_having.htm)

> `HAVING` is an optional clause that can be used in a SOQL query to filter results that aggregate functions return.

For more details check [`SOQL.HavingFilterGroup`](soql-having-filter-group.md) and [`SOQL.HavingFilter`](soql-having-filter.md)

**Signature**

```apex
Queryable have(HavingFilterGroup havingFilterGroup)
Queryable have(HavingFilter havingFilter)
```

**Example**

```sql
SELECT LeadSource, COUNT(Name)
FROM Lead
GROUP BY LeadSource, City
HAVING COUNT(Name) > 100 AND City LIKE 'San%'
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .count(Lead.Name)
    .groupBy(Lead.LeadSource)
    .groupBy(Lead.City)
    .have(SOQL.HavingFilter.count(Lead.Name).greaterThan(100))
    .have(SOQL.HavingFilter.with(Lead.City).startsWith('San'))
    .toAggregated();
```

### having string

Execute having conditions passed as String.

**Signature**

```apex
Queryable have(String conditions)
```

**Example**

```sql
SELECT LeadSource, COUNT(Name)
FROM Lead
GROUP BY LeadSource
HAVING COUNT(Name) > 100 AND COUNT(Name) < 200
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .count(Lead.Name)
    .groupBy(Lead.LeadSource)
    .have('COUNT(Name) > 100 AND COUNT(Name) < 200')
    .toAggregated();
```

### havingConditionLogic

Set conditions order for SOQL HAVING clause. When not specify all conditions will be with `AND`.

**Signature**

```apex
Queryable havingConditionLogic(String order)
```

**Example**

```sql
SELECT LeadSource, COUNT(Name)
FROM Lead
GROUP BY LeadSource, City
HAVING COUNT(Name) > 100 OR City LIKE 'San%'
```
```apex
 SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .count(Lead.Name)
    .groupBy(Lead.LeadSource)
    .groupBy(Lead.City)
    .have(SOQL.HavingFilter.count(Lead.Name).greaterThan(100))
    .have(SOQL.HavingFilter.with(Lead.City).startsWith('San'))
    .havingConditionLogic('1 OR 2')
    .toAggregated();
```

### anyHavingConditionMatching

When the [havingConditionLogic](#havingconditionlogic) is not specified, all conditions are joined using the `AND` operator by default.

To change the default condition logic, you can utilize the `anyHavingConditionMatching` method, which joins conditions using the `OR` operator.

**Signature**

```apex
Queryable anyHavingConditionMatching()
```

**Example**

```sql
SELECT LeadSource, COUNT(Name)
FROM Lead
GROUP BY LeadSource, City
HAVING COUNT(Name) > 100 OR City LIKE 'San%'
```
```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .count(Lead.Name)
    .groupBy(Lead.LeadSource)
    .groupBy(Lead.City)
    .have(SOQL.HavingFilter.count(Lead.Name).greaterThan(100))
    .have(SOQL.HavingFilter.with(Lead.City).startsWith('San'))
    .anyHavingConditionMatching()
    .toAggregated();
```

## ORDER BY

[ORDER BY](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_orderby.htm)

### orderBy

> Use the optional `ORDER BY` in a `SELECT` statement of a SOQL query to control the order of the query results.

**Signature**

```apex
Queryable orderBy(SObjectField field)
Queryable orderBy(String field)
Queryable orderBy(String field, String direction)
```

**Example**

```sql
SELECT Id
FROM Account
ORDER BY Name DESC
```
```apex
SOQL.of(Account.SObjectType)
    .orderBy(Account.Name)
    .sortDesc()
    .toList();

SOQL.of(Account.SObjectType)
    .orderBy('Name')
    .sortDesc()
    .toList();

SOQL.of(Account.SObjectType)
    .orderBy('Name', 'DESC')
    .toList();
```

### orderBy related

Order SOQL query by parent field.

**Signature**

```apex
Queryable orderBy(String relationshipName, SObjectField field)
```

**Example**

```sql
SELECT Id
FROM Contact
ORDER BY Account.Name
```
```apex
SOQL.of(Contact.SObjectType)
    .orderBy('Account', Account.Name)
    .toList();
```

### orderBy COUNT

**Signature**

```apex
Queryable orderByCount(SObjectField field)
```

**Example**

```sql
SELECT Industry
FROM Account
GROUP BY Industry
ORDER BY COUNT(Industry) DESC NULLS LAST
```
```apex
SOQL.of(Account.SObjectType)
    .with(Account.Industry)
    .groupBy(Account.Industry)
    .orderByCount(Account.Industry).sortDesc().nullsLast()
    .toAggregated();
```

### sortDesc

Default order is ascending (`ASC`).

**Signature**

```apex
Queryable sortDesc()
```

**Example**

```sql
SELECT Id
FROM Account
ORDER BY Name DESC
```
```apex
SOQL.of(Account.SObjectType)
    .orderBy(Account.Name)
    .sortDesc()
    .toList();
```

### sort

Use ONLY for dynamic order.

**Signature**

```apex
Queryable sort(String direction)
```

**Example**

```sql
SELECT Id
FROM Account
ORDER BY Industry ASC NULLS FIRST
```
```apex
SOQL.of(Account.SObjectType)
    .orderBy('Industry')
    .sort('DESC')
    .toList();
```

### nullsLast

By default, null values are sorted first (`NULLS FIRST`).

**Signature**

```apex
Queryable nullsLast()
```

**Example**

```sql
SELECT Id
FROM Account
ORDER BY Name NULLS LAST
```
```apex
SOQL.of(Account.SObjectType)
    .orderBy(Account.Industry)
    .nullsLast()
    .toList();
```

### nulls order

To build dynamic order - use `nullsOrder` method.

**Signature**

```apex
Queryable nullsOrder(String order)
```

**Example**

```sql
SELECT Id
FROM Account
ORDER BY Name NULLS LAST
```
```apex
String order = 'LAST';

SOQL.of(Account.SObjectType)
    .orderBy(Account.Industry)
    .nullsOrder(order)
    .toList();
```

## LIMIT
### setLimit

- [LIMIT](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_limit.htm)

> `LIMIT` is an optional clause that can be added to a `SELECT` statement of a SOQL query to specify the maximum number of rows to return.

**Signature**

```apex
Queryable setLimit(Integer amount)
```

**Example**

```sql
SELECT Id
FROM Account
LIMIT 100
```
```apex
SOQL.of(Account.SObjectType)
    .setLimit(100)
    .toList();
```

## OFFSET
### offset

- [OFFSET](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_offset.htm)

> When expecting many records in a query’s results, you can display the results in multiple pages by using the `OFFSET` clause on a SOQL query.

**Signature**

```apex
Queryable offset(Integer startingRow)
```

**Example**

```sql
SELECT Id
FROM Account
OFFSET 10
```
```apex
SOQL.of(Account.SObjectType)
    .setOffset(10)
    .toList();
```

## FOR

- [FOR VIEW and FOR REFERENCE](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_for_view_for_reference.htm)
- [FOR UPDATE](https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_soql_select_for_update.htm)
### forReference

> Use to notify Salesforce when a record is referenced from a custom interface, such as in a mobile application or from a custom page.

**Signature**

```apex
Queryable forReference()
```

**Example**

```sql
SELECT Id
FROM Contact
FOR REFERENCE
```
```apex
SOQL.of(Contact.SObjectType)
    .forReference()
    .toList();
```

### forView

> Use to update objects with information about when they were last viewed.

**Signature**

```apex
Queryable forView()
```

**Example**

```sql
SELECT Id
FROM Contact
FOR VIEW
```
```apex
SOQL.of(Contact.SObjectType)
    .forView()
    .toList();
```

### forUpdate

> Use to lock sObject records while they’re being updated in order to prevent race conditions and other thread safety problems.

**Signature**

```apex
Queryable forUpdate()
```

**Example**

```sql
SELECT Id
FROM Contact
FOR UPDATE
```
```apex
SOQL.of(Contact.SObjectType)
    .forUpdate()
    .toList();
```

### allRows

> SOQL statements can use the ALL ROWS keywords to query all records in an organization, including deleted records and archived activities.

**Signature**

```apex
Queryable allRows()
```

**Example**

```sql
SELECT COUNT()
FROM Contact
ALL ROWS
```
```apex
SOQL.of(Contact.SObjectType)
    .count()
    .allRows()
    .toList();
```

## FIELD-LEVEL SECURITY

[AccessLevel Class](https://developer.salesforce.com/docs/atlas.en-us.apexref.meta/apexref/apex_class_System_AccessLevel.htm#apex_class_System_AccessLevel)

By default AccessLevel is set as `USER_MODE`.

More details you can find in [here](../advanced/fls.md)

### userMode

By default, all queries are executed `WITH USER_MODE`. However, developers can override this. For more details, check [Field-Level Security](../advanced/fls.md) and [Sharing Rules](../advanced/sharing.md).

The `userMode` method can be useful to override the `systemMode()` provided by the selector.

> Execution mode in which the object permissions, field-level security, and sharing rules of the current user are enforced.

**Signature**

```apex
Queryable userMode()
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .userMode()
    .toList();
```

### systemMode

> Execution mode in which the the object and field-level permissions of the current user are ignored, and the record sharing rules are controlled by the class sharing keywords.

**Signature**

```apex
Queryable systemMode()
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .systemMode()
    .toList();
```

### stripInaccessible

`USER_MODE` enforces not only object and field-level security but also sharing rules (`with sharing`). You may encounter situations where you need object and field-level security but want to ignore sharing rules (`without sharing`). To achieve this, use `.systemMode()`, `.withoutSharing()` and `.stripInaccessible()`.

Read more about `stripInaccessible` in [advanced](../advanced/fls.md#strip-inaccessible).

**Signature**

```apex
Queryable stripInaccessible()
Queryable stripInaccessible(AccessType accessType)
```

```apex
SOQL.of(Account.SObjectType)
    .systemMode()
    .withoutSharing()
    .stripInaccessible()
    .toList();
```

## SHARING MODE

[Using the with sharing, without sharing, and inherited sharing Keywords](https://developer.salesforce.com/docs/atlas.en-us.apexcode.meta/apexcode/apex_classes_keywords_sharing.htm)

More details you can find in [here](../advanced/sharing.md).

### withSharing

Execute query `with sharing`.

**Note!** System mode needs to be enabled by `.systemMode()`.

**Signature**

```apex
Queryable withSharing()
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .systemMode()
    .withSharing()
    .toList();
```

### withoutSharing

Execute query `without sharing`.

**Note!** System mode needs to be enabled by `.systemMode()`.

**Signature**

```apex
Queryable withoutSharing()
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .systemMode()
    .withoutSharing()
    .toList();
```

## MOCKING

### mockId

Query needs unique id that allows for mocking.

**Signature**

```apex
Queryable mockId(String queryIdentifier)
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .mockId('MyQuery')
    .toList();

// In Unit Test
SOQL.mock('MyQuery').thenReturn(new List<Account>{
    new Account(Name = 'MyAccount 1'),
    new Account(Name = 'MyAccount 2')
});
```

### record mock

**Signature**

```apex
SOQL.Mockable mock(String mockId).thenReturn(SObject record)
```

**Example**

```apex
SOQL.of(Account.sObjectType)
    .mockId('MyQuery')
    .toList();

// In Unit Test
SOQL.mock('MyQuery').thenReturn(new Account(Name = 'MyAccount 1'));
```

### list mock

**Signature**

```apex
SOQL.Mockable mock(String mockId).thenReturn(List<SObject> records)
```

**Example**

```apex
SOQL.of(Account.sObjectType)
    .mockId('MyQuery')
    .toList();

// In Unit Test
SOQL.mock('MyQuery').thenReturn(new List<Account>{
    new Account(Name = 'MyAccount 1'),
    new Account(Name = 'MyAccount 2')
});
```

### count mock

**Signature**

```apex
SOQL.Mockable mock(String mockId).thenReturn(Integer amount)
```

**Example**

```apex
SOQL.of(Account.sObjectType)
    .mockId('MyQuery')
    .count()
    .toInteger();

// In Unit Test
SOQL.mock('MyQuery).thenReturn(5);
```

### aggregateResult mock

**Signature**

```apex
SOQL.Mockable mock(String mockId).thenReturn(List<Map<String, Object>> mock);
SOQL.Mockable mock(String mockId).thenReturn(Map<String, Object> mock);
```

**Example**

```apex
List<Map<String, Object>> aggregateResults = new List<Map<String, Object>>{
    new Map<String, Object>{ 'LeadSource' => 'Web',  'total' => 10},
    new Map<String, Object>{ 'LeadSource' => 'Phone', 'total' => 5},
    new Map<String, Object>{ 'LeadSource' => 'Email', 'total' => 3}
};

SOQL.mock('mockingQuery').thenReturn(aggregateResults);

List<SOQL.AggregateResultProxy> result = SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .COUNT(Lead.Id, 'total')
    .groupBy(Lead.LeadSource)
    .mockId('mockingQuery')
    .toAggregatedProxy();
```

### SObjectType mock

Create a mock using SObjectType instead of a string identifier. This method automatically generates a hash-based mock ID from the SObjectType.

**Signature**

```apex
SOQL.Mockable mock(SObjectType ofObject)
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .with(Account.Id, Account.Name)
    .toList();

// In Unit Test - Mock records using SObjectType
SOQL.mock(Account.SObjectType).thenReturn(new List<Account>{
    new Account(Name = 'Test Account 1'),
    new Account(Name = 'Test Account 2')
});

// Mock single record using SObjectType  
SOQL.mock(Contact.SObjectType).thenReturn(
    new Contact(FirstName = 'John', LastName = 'Doe')
);

// Mock count using SObjectType
SOQL.mock(Lead.SObjectType).thenReturn(10);
```

**Note!** When using `mock(SObjectType)`, the library automatically generates a mock identifier based on the SObjectType's hash code. This is convenient when you don't need to specify custom mock IDs and want to mock all queries for a specific SObject type.

### exception mock

Mock a query exception with default message.

**Signature**

```apex
SOQL.Mockable mock(String mockId).throwException()
```

**Example**

```apex
// In Unit Test
SOQL.mock('MyQuery').throwException();

Test.startTest();
Exception error;
try {
    Account result = SOQL.of(Account.SObjectType)
        .mockId('MyQuery')
        .toObject();
} catch (Exception e) {
    error = e;
}
Test.stopTest();

Assert.isNotNull(error, 'The query exception should be thrown.');
```

### exception mock with message

Mock a query exception with custom error message.

**Signature**

```apex
SOQL.Mockable mock(String mockId).throwException(String message)
```

**Example**

```apex
// In Unit Test
String errorMessage = 'No such column \'InvalidField__c\' on entity \'Account\'.';
SOQL.mock('MyQuery').throwException(errorMessage);

Test.startTest();
Exception error;
try {
    Account result = SOQL.of(Account.SObjectType)
        .mockId('MyQuery')
        .toObject();
} catch (Exception e) {
    error = e;
}
Test.stopTest();

Assert.isNotNull(error, 'The query exception should be thrown.');
Assert.isTrue(error.getMessage().contains('InvalidField__c'));
```

## DEBUGGING
### preview

**Signature**

```apex
Queryable preview()
```

**Example**

```apex
SOQL.of(Account.SObjectType)
    .preview()
    .toList();
```

Query preview will be available in debug logs:

```
============ Query Preview ============
SELECT Name, AccountNumber, BillingCity, BillingCountry, BillingCountryCode
FROM Account
WHERE ((Id = :v1 OR Name LIKE :v2))
=======================================

============ Query Binding ============
{
  "v2" : "%Test%",
  "v1" : "0013V00000WNCw4QAH"
}
=======================================
```

## PREDEFINIED

For all predefined methods SOQL instance is returned so you can still adjust query before execution.
Add additional fields with [`.with`](#select).

### byId

**Signature**

```apex
Queryable byId(Id recordId)
Queryable byId(SObject record)
```

**Example**

```sql
SELECT Id
FROM Account
WHERE Id = '1234'
```
```apex
SOQL.of(Account.SObjectType)
    .byId('1234')
    .toObject();
```
```apex
Account account = [SELECT Id FROM Account LIMIT 1];
SOQL.of(Account.SObjectType)
    .byId(account)
    .toObject();
```

### byIds

**Signature**


```apex
Queryable byIds(Iterable<Id> recordIds)
Queryable byIds(List<SObject> records)
```

**Example**

```sql
SELECT Id
FROM Account
WHERE Id IN ('1234')
```

```apex
SOQL.of(Account.SObjectType)
    .byIds(new Set<Id>{ '1234' })
    .toList();
```

```apex
SOQL.of(Account.SObjectType)
    .byIds(new List<Id>{ '1234' })
    .toList();
```

```apex
List<Account> accounts = [SELECT Id FROM Account];
SOQL.of(Account.SObjectType)
    .byIds(accounts)
    .toList();
```

### byRecordType

Query record by `RecordType.DeveloperName`. To do that, you can use the `byRecordType` method.

**Signature**

```apex
Queryable byRecordType(String recordTypeDeveloperName)
```

**Example**

```sql
SELECT Id
FROM Account
WHERE RecordType.DeveloperName = 'Partner'
```

```apex
SOQL.of(Account.SObjectType)
    .byRecordType('Partner')
    .toList();
```

## RESULT

### toId

```apex
Id toId()
```

**Example**

```apex
Id adminProfileId = SOQL.of(Profile.SObjectType)
    .whereAre(SOQL.Filter.name().equal('System Administrator'))
    .toId();

new User (
    // ...
    ProfileId = adminProfileId
);
```

### toIds

Extract all record IDs from query result.

**Signature**

```apex
Set<Id> toIds()
```

**Example**

```apex
Set<Id> accountIds = SOQL.of(Account.SObjectType)
    .whereAre(SOQL.Filter.with(Account.Industry).equal('Technology'))
    .toIds();
```

### toIdsOf

Extract field values as Set of IDs from query result.
Field will be automatically added to the query fields.

**Signature**

```apex
Set<Id> toIdsOf(SObjectField field)
```

**Example**

```apex
Set<Id> ownerIds = SOQL.of(Account.SObjectType)
    .whereAre(SOQL.Filter.with(Account.Industry).equal('Technology'))
    .toIdsOf(Account.OwnerId);
```

### toIdsOf Related Field

**Signature**

```apex
Set<Id> toIdsOf(String relationshipName, SObjectField field)
```

**Example**

```apex
Set<Id> parentAccountIds = SOQL.of(Account.SObjectType)
    .whereAre(SOQL.Filter.with(Account.Industry).equal('Technology'))
    .toIdsOf('Parent', Account.Id);
```

### doExist

**Signature**

```apex
Boolean doExist()
```

**Example**

```apex
Boolean isRecordExist = SOQL.of(Account.SObjectType).byId('1234').doExist();
```

### toValueOf

Extract field value from query result.
Field will be automatically added to the query fields.

**Signature**

```apex
Object toValueOf(SObjectField fieldToExtract)
```

**Example**

```apex
String accountName = (String) SOQL.of(Account.SObjectType).byId('1234').toValueOf(Account.Name)
```

### toValuesOf

Extract field values from query result.
Field will be automatically added to the query fields.

SOQL Lib is using [Building a KeySet from any field](https://salesforce.stackexchange.com/questions/393308/get-a-list-of-one-column-from-a-soql-result) approach to get only one field.

Note! It does not work with Custom Metadata.

**Signature**

```apex
Set<String> toValuesOf(SObjectField fieldToExtract)
```

**Example**

```apex
Set<String> accountNames = SOQL.of(Account.SObjectType).byId('1234').toValuesOf(Account.Name)
```

### toValuesOf Releated Field

**Signature**

```apex
Set<String> toValuesOf(String relationshipName, SObjectField targetKeyField)
```

**Example**

```apex
Set<String> parentAccountNames = SOQL.of(Account.SObjectType)
    .byId('1234')
    .toValuesOf('Parent', Account.Name)
```

### toInteger

**Signature**

```apex
Integer toInteger()
```

**Example**

```sql
SELECT COUNT() FROM Account
```
```apex
SOQL.of(Account.SObjectType).count().toInteger();
```

### toObject

When the list of records contains more than one entry, the error `List has more than 1 row for assignment to SObject` will occur.

When there are no records to assign, the error `List has no rows for assignment to SObject` will **NOT** occur. This is automatically handled by the framework, and a `null` value will be returned instead.

**Signature**

```apex
sObject toObject()
```

**Example**

```apex
SOQL.of(Account.SObjectType).toObject();
```

### toList

**Signature**

```apex
List<sObject> toList()
```

**Example**

```apex
SOQL.of(Account.SObjectType).toList();
```

### toAggregated

**Signature**

```apex
List<AggregateResult> toAggregated()
```

**Example**


```sql
SELECT LeadSource
FROM Lead
GROUP BY LeadSource
```

```apex
SOQL.of(Lead.SObjectType)
    .with(Lead.LeadSource)
    .groupBy(Lead.LeadSource)
    .toAggregated()
```

### toMap

**Signature**

```apex
Map<Id, SObject> toMap()
```

**Example**

```apex
Map<Id, Account> idToAccount = (Map<Id, Account>) SOQL.of(Account.SObjectType).toMap();
```

### toMap with custom key

**Note!** To improve query performance, a condition checking if the keyField is not null (`WHERE keyField != null`) is automatically added to the query.

**Signature**

```apex
Map<String, SObject> toMap(SObjectField keyField)
```

**Example**

```apex
Map<String, Account> nameToAccount = (Map<String, Account>) SOQL.of(Account.SObjectType).toMap(Account.Name);
```

### toMap with custom relationship key

**Note!** To improve query performance, a condition checking if the targetKeyField is not null (`WHERE relationshipName.targetKeyField != null`) is automatically added to the query.

**Signature**

```apex
Map<String, SObject> toMap(String relationshipName, SObjectField targetKeyField)
```

**Example**

```apex
Map<String, Account> parentCreatedByEmailToAccount = (Map<String, Account>) SOQL.of(Account.SObjectType).toMap('Parent.CreatedBy', User.Email);
```

### toMap with custom key and value

**Note!** To improve query performance, a condition checking if the keyField is not null (`WHERE keyField != null`) is automatically added to the query.

**Signature**

```apex
Map<String, String> toMap(SObjectField keyField, , SObjectField valueField)
```

**Example**

```apex
Map<String, String> nameToAccount = SOQL.of(Account.SObjectType).toMap(Account.Name, Account.Industry);
```

### toAggregatedMap

**Note!** To improve query performance, a condition checking if the keyField is not null (`WHERE keyField != null`) is automatically added to the query.

**Signature**

```apex
Map<String, List<SObject>> toAggregatedMap(SObjectField keyField)
```

**Example**

```apex
Map<String, List<Account>> industryToAccounts = (Map<String, List<Account>>) SOQL.of(Account.SObjectType).toAggregatedMap(Account.Industry);
```

### toAggregatedMap with custom value

**Note!** To improve query performance, a condition checking if the keyField is not null (`WHERE keyField != null`) is automatically added to the query.

**Signature**

```apex
Map<String, List<String>> toAggregatedMap(SObjectField keyField, SObjectField valueField)
```

**Example**

```apex
Map<String, List<String>> industryToAccounts = SOQL.of(Account.SObjectType).toAggregatedMap(Account.Industry, Account.Name);
```

### toAggregatedMap with custom relationship key

**Note!** To improve query performance, a condition checking if the targetKeyField is not null (`WHERE relationshipName.targetKeyField != null`) is automatically added to the query.

**Signature**

```apex
Map<String, List<SObject>> toAggregatedMap(String relationshipName, SObjectField targetKeyField)
```

**Example**

```apex
Map<String, List<Account>> parentCreatedByEmailToAccounts = (Map<String, List<Account>>) SOQL.of(Account.SObjectType).toAggregatedMap('Parent.CreatedBy', User.Email);
```

### toIdMapBy

Creates a map where the key is the Id extracted from the specified field and the value is the SObject record.

**Note!** To improve query performance, a condition checking if the field is not null (`WHERE field != null`) is automatically added to the query.

**Signature**

```apex
Map<Id, SObject> toIdMapBy(SObjectField field)
```

**Example**

```apex
Map<Id, Account> ownerIdToAccount = (Map<Id, Account>) SOQL.of(Account.SObjectType).toIdMapBy(Account.OwnerId);
```

### toIdMapBy with relationship

Creates a map where the key is the Id extracted from the specified relationship field and the value is the SObject record.

**Note!** To improve query performance, a condition checking if the targetKeyField is not null (`WHERE relationshipName.targetKeyField != null`) is automatically added to the query.

**Signature**

```apex
Map<Id, SObject> toIdMapBy(String relationshipName, SObjectField targetKeyField)
```

**Example**

```apex
Map<Id, Account> parentIdToAccount = (Map<Id, Account>) SOQL.of(Account.SObjectType).toIdMapBy('Parent', Account.Id);
```

### toAggregatedIdMapBy

Creates a map where the key is the Id extracted from the specified field and the value is a list of SObject records grouped by that Id.

**Note!** To improve query performance, a condition checking if the keyField is not null (`WHERE keyField != null`) is automatically added to the query.

**Signature**

```apex
Map<Id, List<SObject>> toAggregatedIdMapBy(SObjectField keyField)
```

**Example**

```apex
Map<Id, List<Account>> ownerIdToAccounts = (Map<Id, List<Account>>) SOQL.of(Account.SObjectType).toAggregatedIdMapBy(Account.OwnerId);
```

### toAggregatedIdMapBy with relationship

Creates a map where the key is the Id extracted from the specified relationship field and the value is a list of SObject records grouped by that Id.

**Note!** To improve query performance, a condition checking if the targetKeyField is not null (`WHERE relationshipName.targetKeyField != null`) is automatically added to the query.

**Signature**

```apex
Map<Id, List<SObject>> toAggregatedIdMapBy(String relationshipName, SObjectField targetKeyField)
```

**Example**

```apex
Map<Id, List<Account>> parentIdToAccounts = (Map<Id, List<Account>>) SOQL.of(Account.SObjectType).toAggregatedIdMapBy('Parent', Account.Id);
```

### toQueryLocator

**Signature**

```apex
Database.QueryLocator toQueryLocator()
```

**Example**

```apex
SOQL.of(Account.SObjectType).toQueryLocator();
```

### toCursor

Returns a `Database.Cursor` for the query, which can be used for more efficient processing of large result sets with streaming capabilities.

**Signature**

```apex
Database.Cursor toCursor()
```

**Example**

```apex
Database.Cursor cursor = SOQL.of(Account.SObjectType)
    .with(Account.Id, Account.Name)
    .whereAre(SOQL.Filter.with(Account.Industry).equal('Technology'))
    .toCursor();
```
