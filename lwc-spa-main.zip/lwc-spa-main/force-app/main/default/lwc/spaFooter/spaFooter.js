import { LightningElement } from 'lwc';

export default class SpaFooter extends LightningElement {}