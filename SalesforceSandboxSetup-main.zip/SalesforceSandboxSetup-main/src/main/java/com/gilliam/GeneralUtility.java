package com.gilliam;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;


public class GeneralUtility {

    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }

        return destFile;
    }


    public static void copyFile(String originalFileName, String targetFileName) throws IOException {     
        Path copied = new File(targetFileName).toPath();
        Path originalPath = new File(originalFileName).toPath();

        File newFile = new File(targetFileName);
        newFile.createNewFile();
        FileOutputStream oFile = new FileOutputStream(newFile, false);
        oFile.close();

        Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
    }  

    public static void purgeDirectory(File directoryToCleanAsFile) throws IOException {
        for (File file: directoryToCleanAsFile.listFiles()) {
            if (file.isDirectory())
                purgeDirectory(file);
            file.delete();
        }
    }
}