package com.gilliam;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderHeaderAware;
import com.opencsv.CSVWriter;

import org.apache.commons.io.input.BOMInputStream;


public class CsvUtility {

    public static List<String> getCsvHeaderRow(String filePath) {
        
        List<List<String>> records = new ArrayList<List<String>>();
        
        try {
            //CSVReader csvReader = new CSVReader(new FileReader(filePath));
            InputStream inputStream = new FileInputStream(filePath);
            InputStreamReader inputStreamReader = new InputStreamReader(new BOMInputStream(inputStream),StandardCharsets.UTF_8);
            CSVReader csvReader = new CSVReader(inputStreamReader);
            String[] values = null;
            while ((values = csvReader.readNext()) != null) {
                for(int i = 0; i < values.length; i++) {
                    if(values[i].startsWith("ï»¿")) {
                        values[i] = values[i].substring(3);
                    }
                    if(values[i].startsWith("��")) {
                        values[i] = values[i].substring(2);
                    }
                }
                records.add(Arrays.asList(values));
                break;
            }
            csvReader.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

        return records.get(0);
    }

/*
    public static List<List<String>> getCsvRows(String filePath) {
        
        List<List<String>> records = new ArrayList<List<String>>();
        
        try {
            //CSVReader csvReader = new CSVReader(new FileReader(filePath));
            InputStream inputStream = new FileInputStream(filePath);
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream,StandardCharsets.UTF_8);
            CSVParser parser = new CSVParserBuilder().withSeparator('\t').withIgnoreQuotations(true).build();
            CSVReader csvReader = new CSVReaderBuilder(inputStreamReader).withCSVParser(parser).build();
            String[] values = null;
            while ((values = csvReader.readNext()) != null) {
                records.add(Arrays.asList(values));
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return records;
    }
*/

    public static List<Map<String, String>> getCsvRowsHeaderAware(String filePath) {
        
        List<Map<String, String>> records = new ArrayList<Map<String, String>>();
        
        try {
            //CSVReader csvReader = new CSVReader(new FileReader(filePath));
            InputStream inputStream = new FileInputStream(filePath);
            InputStreamReader inputStreamReader = new InputStreamReader(new BOMInputStream(inputStream),StandardCharsets.UTF_8);
            CSVReaderHeaderAware csvReaderHeaderAware = new CSVReaderHeaderAware(inputStreamReader);
            Map<String, String> values = null;
            while ((values = csvReaderHeaderAware.readMap()) != null) {
                records.add(values);
            }
            csvReaderHeaderAware.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

        for(Map<String, String> row : records) {
            for(Map.Entry<String, String> entry : row.entrySet()) {
                if(entry.getKey().startsWith("ï»¿")) {
                    String newKey = entry.getKey().replace("ï»¿ï»¿","");
                    row.put(newKey,entry.getValue());
                    row.remove(entry.getKey());
                }
            }
        }
        
        return records;
    }

/*
    public static List<Map<String, String>> convertRowsToMap(List<String> headerRow, List<List<String>> records) {

        for(String s : headerRow) {
            System.out.println("Header Field: " + s);
        }

        List<Map<String, String>> convertedRecords = new ArrayList<Map<String, String>>();

        for(Integer i = 1; i < records.size(); i++) {
            List<String> thisRow = records.get(i);
            System.out.println("thisRow.size(): " + thisRow.size());
            Map<String, String> thisRowMap = new HashMap<String, String>();
            for(Integer i2 = 0; i2 < thisRow.size(); i2++) {
                thisRowMap.put(headerRow.get(i2), thisRow.get(i2));
            }
            convertedRecords.add(thisRowMap);
        }
        return convertedRecords;
    }
*/

    public static void startCsv(File file, List<String> theHeaderRow) {
        try {
            FileWriter outputFile = new FileWriter(file, StandardCharsets.UTF_8);
            CSVWriter writer = new CSVWriter(outputFile);

            // adding header to csv
            String[] header = new String[theHeaderRow.size()];
            Integer counter = 0;
            for(String headerFieldName : theHeaderRow) {
                if(headerFieldName.startsWith("ï»¿")) {
                    headerFieldName = headerFieldName.substring(3);
                }
                if(headerFieldName.startsWith("��")) {
                    headerFieldName = headerFieldName.substring(2);
                }
                header[counter] = headerFieldName;
                counter++;
            }
            writer.writeNext(header);
            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    /*
    public static void startCsv(File file, TreeMap<String, String> theFirstLine) {
        try {
            FileWriter outputFile = new FileWriter(file, StandardCharsets.UTF_8);
            CSVWriter writer = new CSVWriter(outputFile);

            // adding header to csv
            String[] header = new String[theFirstLine.size()];
            Integer counter = 0;
            for(Map.Entry<String, String> entry : theFirstLine.entrySet()) {
                String entryKey = entry.getKey();
                if(entryKey.startsWith("ï»¿")) {
                    entryKey = entryKey.substring(3);
                }
                header[counter] = entryKey;
                counter++;
            }
            writer.writeNext(header);
            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    */


    public static void writeToCsv(String [] dataForRow, File file) {
        // first create file object for file placed at location
        // specified by filepath
        try {

            FileWriter outputFile = new FileWriter(file, true);
            CSVWriter writer = new CSVWriter(outputFile);

            // add data to csv
            writer.writeNext(dataForRow);
    
            // closing writer connection
            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void writeToCsv(Map<String, String> dataForRow, List<String> theHeaderRow, File file) {
        // first create file object for file placed at location
        // specified by filepath
        String[] dataForRowArray = new String[dataForRow.size()];
        int i = 0;
        for(String headerField : theHeaderRow) {
            dataForRowArray[i] = dataForRow.get(headerField);
            i++;
        }
        writeToCsv(dataForRowArray, file);
    }
    
}