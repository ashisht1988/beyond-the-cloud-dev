package com.gilliam;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.zip.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import com.sforce.soap.partner.*;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.gilliam.TextFileUtility;
import com.sforce.async.BatchInfo;
import com.sforce.async.BulkConnection;
import com.sforce.async.JobInfo;
import com.sforce.soap.metadata.*;
import com.sforce.soap.tooling.*;
import com.sforce.ws.ConnectionException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import net.lingala.zip4j.exception.ZipException;


public class Main {
    
    static Properties defaultProps;
    static Boolean DEPLOY = true;
    static Boolean contactEmailObfuscationOnly = false;
    static File contactUpdateFile = null;
    static File quoteUpdateFile = null;
    static String USERNAME = "";
    static String PASSWORD = "";
    public static PartnerConnection connection = null;
    public static MetadataConnection metadataConnection;
    public static ToolingConnection toolingConnection;
    public static String runDateTime;
    public static String logFileName;
    public static String sandboxChar;

    public static String mainPackageXmlPath = "resources/package.xml";
    public static String dupeRulesPackageXmlPath = "resources/package - DupeRules.xml";

    public static String instanceId = "";

    public static String outboundMessageUrl = "";
    public static String endpointAuthAppendix = "";
    public static String rocketSupportRoutingAddress = "";
    public static String caseAttachmentSettingsDeleteAttachmentUrl = "";
    public static String caseAttachmentSettingsEmail2CaseUploadUrl = "";
    //public static String rSearchInstanceProduction = ""; // Don't see this custom setting???
    public static String systemSettingsNa = "";
    public static String downloadSettingsName = "";
    public static String downloadSettingsPdlMiddlewareUrl = "";
    public static String downloadSettingsAdpMiddlewareUrl = "";
    public static String downloadSettingsHost = "";
    public static String downloadSettingsInstance = ""; // Need to query up the Instance ID
    public static String rCCommunityAPIEndpointUrl = "";
    public static String rCCommunityAPIUsername = "";
    public static String rCCommunityAPIConsumerKey = ""; // Setting to blank.  Could get the Consumer Key with API, but not the Consumer Secret, so we'll manually set both.
    public static String sffilesUrl = "";
    public static String downloadRsUrl = "";
    public static String pivsfdcUrl = "";
    public static String rocketrackUrl = "";
    public static String caseAlertEmailAddress = "";
    public static String orgSpecficUrl = "";
    public static String dsButtonPassThruBaseURL = "";
    public static String dsClmAccountId = "";
    public static String dsCLMv2ApiEndpoint = "";
    public static String dsDataCenter = "";
    public static String dsDSAccountID = "";
    public static String dsDSUserName = "";
    public static String dsRequestAuthDomain = "";
    public static String dsRequestAuthEndpoint  = "";   

    public static String stageOutboundMessageUrl = "https://sf-erpstg-ws.rocketsoftware.com/";
    public static String stageEndpointAuthAppendix = ";boomi_auth=cm9ja2V0c29mdHdhcmUtTjY3TFBIOjc0MDk5OGUwLTQ4MzktNDA4Zi05MWMyLTIwNGZlMWVmMGM2OQ==";
    public static String stageRocketSupportRoutingAddress = "support-sfstage@rocketsoftware.com";
    public static String stageCaseAttachmentSettingsDeleteAttachmentUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentUploadProxy/delete?";
    public static String stageCaseAttachmentSettingsEmail2CaseUploadUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentUploadProxy/eput";
    //public static String stageRSearchInstanceProduction = "https://rsearchsf-stg.rocketsoftware.com/indexes/sfm/docs/"; // Don't see this custom setting???
    public static String stageSystemSettingsNa = "Stage";
    public static String stageDownloadSettingsName = "Stage";
    public static String stageDownloadSettingsPdlMiddlewareUrl = "https://sffiles-stg.rocketsoftware.com/AkamaiRequestEncryptor/get";
    public static String stageDownloadSettingsAdpMiddlewareUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentDownloadProxy";
    public static String stageDownloadSettingsHost = "download-eu-stg.rocketsoftware.com";
    public static String stageDownloadSettingsInstance = ""; // Need to query up the Instance ID
    public static String stageRCCommunityAPIEndpointUrl = "https://rocketsoftware--stage.my.salesforce.com";
    public static String stageRCCommunityAPIUsername = "boomi@rocketsoftware.com.stage";
    public static String stageRCCommunityAPIConsumerKey = ""; // Setting to blank.  Could get the Consumer Key with API, but not the Consumer Secret, so we'll manually set both.
    public static String stageSffilesUrl = "https://sffiles-stg.rocketsoftware.com";
    public static String stageDownloadRsUrl = "https://download-eu-stg.rocketsoftware.com";
    public static String stagePivsfdcUrl = "http://pivotalsfdc-stg.rocketsoftware.com";
    public static String stageRocketrackUrl = "https://rocketrack-stage.rocketsoftware.com";
    public static String stageCaseAlertEmailAddress = "support-sfstage@rocketsoftware.com";
    public static String stageOrgSpecificUrl = "https://rocketsoftware--stage.my.salesforce.com";
    public static String stageDsButtonPassThruBaseURL = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsClmAccountId = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsCLMv2ApiEndpoint = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsDataCenter = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsDSAccountID = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsDSUserName = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsRequestAuthDomain = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.
    public static String stageDsRequestAuthEndpoint  = ""; // Leave blank for Stage, as we DO NOT have a DocuSign test environment to pair with the Stage sandbox.   

    public static String uatOutboundMessageUrl = "https://sf-erpuat-ws.rocketsoftware.com/";
    public static String uatEndpointAuthAppendix = ";boomi_auth=cm9ja2V0c29mdHdhcmUtTjY3TFBIOmY1ZTMyY2VhLTk2OTgtNDZjYi1hNGQ3LWZiOGU3NjUxYTZlNQ==";
    public static String uatRocketSupportRoutingAddress = "support-sfuat@rocketsoftware.com";
    public static String uatCaseAttachmentSettingsDeleteAttachmentUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentUploadProxy-uat/delete?";
    public static String uatCaseAttachmentSettingsEmail2CaseUploadUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentUploadProxy-uat/eput";
    //public static String uatRSearchInstanceProduction = "https://sfrsearch-uat.rocketsoftware.com/indexes/sfm/docs/"; // Don't see this custom setting???
    public static String uatSystemSettingsNa = "UAT";
    public static String uatDownloadSettingsName = "UAT";
    public static String uatDownloadSettingsPdlMiddlewareUrl = "https://sffiles-stg.rocketsoftware.com/AkamaiRequestEncryptor-uat/get";
    public static String uatDownloadSettingsAdpMiddlewareUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentDownloadProxy-uat";
    public static String uatDownloadSettingsHost = "download-eu-stg.rocketsoftware.com";
    public static String uatDownloadSettingsInstance = ""; // Need to query up the Instance ID
    public static String uatRCCommunityAPIEndpointUrl = "https://rocketsoftware--uat.my.salesforce.com";
    public static String uatRCCommunityAPIUsername = "boomi@rocketsoftware.com.uat";
    public static String uatRCCommunityAPIConsumerKey = ""; // Setting to blank.  Could get the Consumer Key with API, but not the Consumer Secret, so we'll manually set both.
    public static String uatSffilesUrl = "https://sffiles-stg.rocketsoftware.com";
    public static String uatDownloadRsUrl = "https://download-eu-stg.rocketsoftware.com";
    public static String uatPivsfdcUrl = "http://pivotalsfdc-uat.rocketsoftware.com ";
    public static String uatRocketrackUrl = "https://www.rocketrack-uat.rocketsoftware.com";
    public static String uatCaseAlertEmailAddress = "support-sfuat@rocketsoftware.com";
    public static String uatOrgSpecificUrl = "https://rocketsoftware--uat.my.salesforce.com";
    public static String uatDsButtonPassThruBaseURL = "https://uatna11.springcm.com";
    public static String uatDsClmAccountId = "14816";
    public static String uatDsCLMv2ApiEndpoint = "https://apiuatna11.springcm.com/v2/";
    public static String uatDsDataCenter = "uatna11";
    public static String uatDsDSAccountID = "807a8501-1607-4cae-b672-64a9eb652956";
    public static String uatDsDSUserName = "08cf3116-1af6-4dfa-90a1-8b4c71001fab";
    public static String uatDsRequestAuthDomain = "account-d.docusign.com";
    public static String uatDsRequestAuthEndpoint  = "https://account-d.docusign.com/oauth/token";   

    public static String devOutboundMessageUrl = "https://sf-erpstg-ws.rocketsoftware.com/";
    public static String devEndpointAuthAppendix = ";boomi_auth=cm9ja2V0c29mdHdhcmUtTjY3TFBIOjU1ZWUzYWFkLTM3N2YtNDYwOC1iZjUzLWZiNGU2OTY2NzM1Yw==";
    public static String devRocketSupportRoutingAddress = "support-sfdev@rocketsoftware.com";
    public static String devCaseAttachmentSettingsDeleteAttachmentUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentUploadProxy-dev/delete?";
    public static String devCaseAttachmentSettingsEmail2CaseUploadUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentUploadProxy-dev/eput";
    //public static String devRSearchInstanceProduction = "https://rsearchsf-dev.rocketsoftware.com/indexes/sfm/docs/"; // Don't see this custom setting???
    public static String devSystemSettingsNa = "Dev";
    public static String devDownloadSettingsName = "Dev";
    public static String devDownloadSettingsPdlMiddlewareUrl = "https://sffiles-stg.rocketsoftware.com/AkamaiRequestEncryptor-dev/get";
    public static String devDownloadSettingsAdpMiddlewareUrl = "https://sffiles-stg.rocketsoftware.com/AttachmentDownloadProxy-dev";
    public static String devDownloadSettingsHost = "download-eu-stg.rocketsoftware.com";
    public static String devDownloadSettingsInstance = ""; // Need to query up the Instance ID
    public static String devRCCommunityAPIEndpointUrl = "https://rocketsoftware--dev.my.salesforce.com";
    public static String devRCCommunityAPIUsername = "boomi@rocketsoftware.com.dev";
    public static String devRCCommunityAPIConsumerKey = ""; // Setting to blank.  Could get the Consumer Key with API, but not the Consumer Secret, so we'll manually set both.
    public static String devSffilesUrl = "https://sffiles-stg.rocketsoftware.com";
    public static String devDownloadRsUrl = "https://download-eu-stg.rocketsoftware.com";
    public static String devPivsfdcUrl = "http://pivotalsfdc-dev.rocketsoftware.com";
    public static String devRocketrackUrl = "https://rocketrack-dev.rocketsoftware.com";
    public static String devCaseAlertEmailAddress = "support-sfdev@rocketsoftware.com";
    public static String devOrgSpecificUrl = "https://rocketsoftware--dev.my.salesforce.com";
    public static String devDsButtonPassThruBaseURL = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsClmAccountId = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsCLMv2ApiEndpoint = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsDataCenter = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsDSAccountID = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsDSUserName = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsRequestAuthDomain = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.
    public static String devDsRequestAuthEndpoint  = ""; // Leave blank for Dev, as we DO NOT have a DocuSign test environment to pair with the Dev sandbox.   
    

    public static String ulsEndpointUrl = "https://uls-stage.rocketsoftware.com/newref.php?refid=";

    public static void main(String[] args) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH_mmss");  
        LocalDateTime now = LocalDateTime.now();
        runDateTime = dtf.format(now);
        logFileName = "log_" + runDateTime; 
        TextFileUtility.createLogFile(logFileName);

        // Get app properties...
        setUpProperties();

        System.out.println("Enter the letter corresponding to the sandbox (Stage = S; UAT = U, Dev = D): ");
        sandboxChar = System.console().readLine();

        if(!sandboxChar.equals("S") && !sandboxChar.equals("U") && !sandboxChar.equals("D")) {
            TextFileUtility.writetoLogFile("The character indicated is not a valid sandbox designation.  Terminating program.", Main.logFileName);
            System.exit(0);
        }
        else {
            TextFileUtility.writetoLogFile("SANDBOX SELECTED: " + sandboxChar, Main.logFileName);
            String sandboxUsername = "";
            if(Main.sandboxChar.equals("D")) {
                sandboxUsername = defaultProps.getProperty("dev.user");
            }
            else if(Main.sandboxChar.equals("U")) {
                sandboxUsername = defaultProps.getProperty("uat.user");
            }
            else if(Main.sandboxChar.equals("S")) {
                sandboxUsername = defaultProps.getProperty("stage.user");
            }
            else {
                TextFileUtility.writetoLogFile("ERROR IN SALESFORCE AUTHENTICATION - INVALID SANDBOX CHAR", Main.logFileName);
                System.exit(0);
            }
            TextFileUtility.writetoLogFile("SANDBOX USERNAME: " + sandboxUsername, Main.logFileName);
        }

        System.out.println("Email Only? (Enter \"Y\" for Yes or \"N\" for No): ");
        String emailOnlyString = System.console().readLine();
        if(emailOnlyString.equals("Y")) {
            contactEmailObfuscationOnly = true;
            TextFileUtility.writetoLogFile("EMAIL MODE SELECTED: Y", Main.logFileName);
        }
        else if(emailOnlyString.equals("N")) {
            contactEmailObfuscationOnly = false;
            TextFileUtility.writetoLogFile("EMAIL MODE SELECTED: N", Main.logFileName);
        }
        else {
            TextFileUtility.writetoLogFile("The character indicated is not valid.  Terminating program.", Main.logFileName);
            System.exit(0);            
        }

        if(sandboxChar.equals("S")) {
            outboundMessageUrl = stageOutboundMessageUrl;
            endpointAuthAppendix = stageEndpointAuthAppendix;
            rocketSupportRoutingAddress = stageRocketSupportRoutingAddress;
            caseAttachmentSettingsDeleteAttachmentUrl = stageCaseAttachmentSettingsDeleteAttachmentUrl;
            caseAttachmentSettingsEmail2CaseUploadUrl = stageCaseAttachmentSettingsEmail2CaseUploadUrl;
            // rSearchInstanceProduction = stageRSearchInstanceProduction; // Don't see this custom setting???
            systemSettingsNa = stageSystemSettingsNa;
            downloadSettingsName = stageDownloadSettingsName;
            downloadSettingsPdlMiddlewareUrl = stageDownloadSettingsPdlMiddlewareUrl;
            downloadSettingsAdpMiddlewareUrl = stageDownloadSettingsAdpMiddlewareUrl;
            downloadSettingsHost = stageDownloadSettingsHost;
            downloadSettingsInstance = stageDownloadSettingsInstance;
            rCCommunityAPIEndpointUrl = stageRCCommunityAPIEndpointUrl;
            rCCommunityAPIUsername = stageRCCommunityAPIUsername;
            rCCommunityAPIConsumerKey = stageRCCommunityAPIConsumerKey;
            sffilesUrl = stageSffilesUrl;
            downloadRsUrl = stageDownloadRsUrl;
            pivsfdcUrl = stagePivsfdcUrl;
            rocketrackUrl = stageRocketrackUrl;
            caseAlertEmailAddress = stageCaseAlertEmailAddress;
            orgSpecficUrl = stageOrgSpecificUrl;    
            dsButtonPassThruBaseURL = stageDsButtonPassThruBaseURL;
            dsClmAccountId = stageDsClmAccountId;
            dsCLMv2ApiEndpoint = stageDsCLMv2ApiEndpoint;
            dsDataCenter = stageDsDataCenter;
            dsDSAccountID = stageDsDSAccountID;
            dsDSUserName = stageDsDSUserName;
            dsRequestAuthDomain = stageDsRequestAuthDomain;
            dsRequestAuthEndpoint = stageDsRequestAuthEndpoint;
        }
        else if(sandboxChar.equals("U")) {
            outboundMessageUrl = uatOutboundMessageUrl;
            endpointAuthAppendix = uatEndpointAuthAppendix;
            rocketSupportRoutingAddress = uatRocketSupportRoutingAddress;
            caseAttachmentSettingsDeleteAttachmentUrl = uatCaseAttachmentSettingsDeleteAttachmentUrl;
            caseAttachmentSettingsEmail2CaseUploadUrl = uatCaseAttachmentSettingsEmail2CaseUploadUrl;
            //rSearchInstanceProduction = uatRSearchInstanceProduction; // Don't see this custom setting???
            systemSettingsNa = uatSystemSettingsNa;
            downloadSettingsName = uatDownloadSettingsName;
            downloadSettingsPdlMiddlewareUrl = uatDownloadSettingsPdlMiddlewareUrl;
            downloadSettingsAdpMiddlewareUrl = uatDownloadSettingsAdpMiddlewareUrl;
            downloadSettingsHost = uatDownloadSettingsHost;
            downloadSettingsInstance = uatDownloadSettingsInstance;
            rCCommunityAPIEndpointUrl = uatRCCommunityAPIEndpointUrl;
            rCCommunityAPIUsername = uatRCCommunityAPIUsername;
            rCCommunityAPIConsumerKey = uatRCCommunityAPIConsumerKey;
            sffilesUrl = uatSffilesUrl;
            downloadRsUrl = uatDownloadRsUrl;
            pivsfdcUrl = uatPivsfdcUrl;
            rocketrackUrl = uatRocketrackUrl;
            caseAlertEmailAddress = uatCaseAlertEmailAddress;
            orgSpecficUrl = uatOrgSpecificUrl;
            dsButtonPassThruBaseURL = uatDsButtonPassThruBaseURL;
            dsClmAccountId = uatDsClmAccountId;
            dsCLMv2ApiEndpoint = uatDsCLMv2ApiEndpoint;
            dsDataCenter = uatDsDataCenter;
            dsDSAccountID = uatDsDSAccountID;
            dsDSUserName = uatDsDSUserName;
            dsRequestAuthDomain = uatDsRequestAuthDomain;
            dsRequestAuthEndpoint = uatDsRequestAuthEndpoint;
        }
        else if(sandboxChar.equals("D")) {
            outboundMessageUrl = devOutboundMessageUrl;
            endpointAuthAppendix = devEndpointAuthAppendix;
            rocketSupportRoutingAddress = devRocketSupportRoutingAddress; 
            caseAttachmentSettingsDeleteAttachmentUrl = devCaseAttachmentSettingsDeleteAttachmentUrl;
            caseAttachmentSettingsEmail2CaseUploadUrl = devCaseAttachmentSettingsEmail2CaseUploadUrl;
            //rSearchInstanceProduction = devRSearchInstanceProduction; // Don't see this custom setting???
            systemSettingsNa = devSystemSettingsNa;
            downloadSettingsName = devDownloadSettingsName;
            downloadSettingsPdlMiddlewareUrl = devDownloadSettingsPdlMiddlewareUrl;
            downloadSettingsAdpMiddlewareUrl = devDownloadSettingsAdpMiddlewareUrl;
            downloadSettingsHost = devDownloadSettingsHost;
            downloadSettingsInstance = devDownloadSettingsInstance;
            rCCommunityAPIEndpointUrl = devRCCommunityAPIEndpointUrl;
            rCCommunityAPIUsername = devRCCommunityAPIUsername;
            rCCommunityAPIConsumerKey = devRCCommunityAPIConsumerKey;
            sffilesUrl = devSffilesUrl;
            downloadRsUrl = devDownloadRsUrl;
            pivsfdcUrl = devPivsfdcUrl;
            rocketrackUrl = devRocketrackUrl;
            caseAlertEmailAddress = devCaseAlertEmailAddress;
            orgSpecficUrl = devOrgSpecificUrl;
            dsButtonPassThruBaseURL = devDsButtonPassThruBaseURL;
            dsClmAccountId = devDsClmAccountId;
            dsCLMv2ApiEndpoint = devDsCLMv2ApiEndpoint;
            dsDataCenter = devDsDataCenter;
            dsDSAccountID = devDsDSAccountID;
            dsDSUserName = devDsDSUserName;
            dsRequestAuthDomain = devDsRequestAuthDomain;
            dsRequestAuthEndpoint = devDsRequestAuthEndpoint; 
        }

        // Authenticate for Salesforce Parter API connection and Metadata API connection.
        connection = SalesforceAuthenticator.auth();
        metadataConnection = SalesforceAuthenticator.authMetadataApi(connection);

        if(!contactEmailObfuscationOnly) {
            // Get org's instanceId
            String queryInstanceId = "SELECT InstanceName FROM Organization LIMIT 1";
            List<SObject> organizationRecords = SalesforceUtility.querySf(connection, queryInstanceId);    
            for(SObject so : organizationRecords) {
                instanceId = so.getSObjectField("InstanceName").toString();
            }

            // Create a list of SObjects for the custom setting records we'll be updating...
            List<SObject> customSettingRecordsForUpdate = new ArrayList<SObject>();

            // Prepare the Case Attachment custom setting values...
            String queryCaseAttachmentSettings = "SELECT Id, Delete_Attachment_URL__c, Email2Case_Upload_URL__c FROM Case_Attachment_Settings__c";
            List<SObject> caseAttachmentRecords = SalesforceUtility.querySf(connection, queryCaseAttachmentSettings);
            for(SObject so : caseAttachmentRecords) {
                SObject tempCaseAttachmentRecord = new SObject();
                tempCaseAttachmentRecord.setId(so.getId());
                tempCaseAttachmentRecord.setType("Case_Attachment_Settings__c");
                tempCaseAttachmentRecord.setSObjectField("Delete_Attachment_URL__c", caseAttachmentSettingsDeleteAttachmentUrl);
                tempCaseAttachmentRecord.setSObjectField("Email2Case_Upload_URL__c", caseAttachmentSettingsEmail2CaseUploadUrl);
                customSettingRecordsForUpdate.add(tempCaseAttachmentRecord);
            }

            // Prepare the System Settings custom setting values...
            String querySystemSettings = "SELECT Id, Name FROM csSystem_Settings__c";
            List<SObject> systemSettingsRecords = SalesforceUtility.querySf(connection, querySystemSettings);
            for(SObject so : systemSettingsRecords) {
                SObject tempSystemSettingRecord = new SObject();
                tempSystemSettingRecord.setId(so.getId());
                tempSystemSettingRecord.setType("csSystem_Settings__c");
                tempSystemSettingRecord.setSObjectField("Name", systemSettingsNa);
                customSettingRecordsForUpdate.add(tempSystemSettingRecord);
            }

            // Prepare the Download Settings custom setting values...
            String queryDownloadSettings = "SELECT Id, Name, PDL_Middleware_URL__c, ADP_Middleware_URL__c, host__c, sf_instance__c FROM Download_Settings__c";
            List<SObject> downloadSettingsRecords = SalesforceUtility.querySf(connection, queryDownloadSettings);
            for(SObject so : downloadSettingsRecords) {
                SObject tempDownloadSettingRecord = new SObject();
                tempDownloadSettingRecord.setId(so.getId());
                tempDownloadSettingRecord.setType("Download_Settings__c");
                tempDownloadSettingRecord.setSObjectField("Name", downloadSettingsName);
                tempDownloadSettingRecord.setSObjectField("PDL_Middleware_URL__c", downloadSettingsPdlMiddlewareUrl);
                tempDownloadSettingRecord.setSObjectField("ADP_Middleware_URL__c", downloadSettingsAdpMiddlewareUrl);
                tempDownloadSettingRecord.setSObjectField("host__c", downloadSettingsHost);
                tempDownloadSettingRecord.setSObjectField("sf_instance__c", instanceId);
                customSettingRecordsForUpdate.add(tempDownloadSettingRecord);
            }

            // Prepare the RCCommunityAPI custom setting values...
            String queryRCCommunityAPISettings = "SELECT Id, EndpointURL__c, Username__c, ConsumerKey__c, ConsumerSecret__c FROM RCCommunityAPI__c";
            List<SObject> rCCommunityAPISettingsRecords = SalesforceUtility.querySf(connection, queryRCCommunityAPISettings);
            for(SObject so : rCCommunityAPISettingsRecords) {
                SObject tempRCCommunitySettingRecord = new SObject();
                tempRCCommunitySettingRecord.setId(so.getId());
                tempRCCommunitySettingRecord.setType("RCCommunityAPI__c");
                tempRCCommunitySettingRecord.setSObjectField("EndpointURL__c", rCCommunityAPIEndpointUrl);
                tempRCCommunitySettingRecord.setSObjectField("Username__c", rCCommunityAPIUsername);
                tempRCCommunitySettingRecord.setSObjectField("ConsumerKey__c", rCCommunityAPIConsumerKey);
                customSettingRecordsForUpdate.add(tempRCCommunitySettingRecord);
            }

            // Update all the custom setting records we set up above...
            SalesforceUtility.updateSObjs(connection, customSettingRecordsForUpdate);


            // Clean out the files directory
            File filesDirForClean = new File("files");
            for(File file: filesDirForClean.listFiles()) {
                file.delete();
            }
            try {
                GeneralUtility.purgeDirectory(filesDirForClean);
            }
            catch(IOException ioe) {
                ioe.printStackTrace();
            }


            String retrievalFilename = "retrieveResults.zip";
            try {
                SalesforceUtility.retrieveMetadata(metadataConnection, mainPackageXmlPath, retrievalFilename);
            }
            catch(Exception e) {
                e.printStackTrace();
            }

            String fileZip = "files/" + retrievalFilename;
            File destDir = new File("files/unzippedRetrieveResults");
            byte[] buffer = new byte[1024];
            

            try {
                FileInputStream fileZipFileInputStream = new FileInputStream(fileZip);
                try (ZipInputStream zis = new ZipInputStream(fileZipFileInputStream)){
                    ZipEntry zipEntry;
                    while ((zipEntry = zis.getNextEntry()) != null) {
                        File newFile = GeneralUtility.newFile(destDir, zipEntry);
                        if (zipEntry.isDirectory()) {
                            if (!newFile.isDirectory() && !newFile.mkdirs()) {
                                throw new IOException("Failed to create directory " + newFile);
                            }
                        } else {
                            // fix for Windows-created archives
                            File parent = newFile.getParentFile();
                            if (!parent.isDirectory() && !parent.mkdirs()) {
                                throw new IOException("Failed to create directory " + parent);
                            }
                            
                            // write file content
                            FileOutputStream fos = new FileOutputStream(newFile);
                            int len;
                            while ((len = zis.read(buffer)) > 0) {
                                fos.write(buffer, 0, len);
                            }
                            fos.close();
                        }
                        zis.closeEntry();
                    }
                    zis.close();
                }
                catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
            catch (FileNotFoundException fnfe) {
                fnfe.printStackTrace();
            }
            

            // Build directories for the updated package
            String PATH = "files";
            String directoryName1 = PATH.concat("/updatedPackage");
            String directoryName2 = directoryName1.concat("/unpackaged");
            String directoryName3 = directoryName2.concat("/workflows");
            String directoryName4 = directoryName2.concat("/settings");
            String directoryName5 = directoryName2.concat("/connectedApps");
            String directoryName6 = directoryName2.concat("/remoteSiteSettings");
            String directoryName7 = directoryName2.concat("/customMetadata");
            List<String> directoryNames = new ArrayList<String>();
            directoryNames.add(directoryName1);
            directoryNames.add(directoryName2);
            directoryNames.add(directoryName3);
            directoryNames.add(directoryName4);
            directoryNames.add(directoryName5);
            directoryNames.add(directoryName6);
            directoryNames.add(directoryName7);
            for(String directoryName : directoryNames) {
                File directory = new File(directoryName);
                if(!directory.exists()) {
                    directory.mkdir();
                }
            }


            // Loop through outbound message workflows and create updated files.
            File folder = new File("files/unzippedRetrieveResults/unpackaged/workflows");
            File[] listOfFiles = folder.listFiles();
            for( int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile()) {
                    TextFileUtility.writetoLogFile("File: " + listOfFiles[i].getPath(), logFileName);
                    TextFileUtility.writetoLogFile("Starting " + listOfFiles[i].getName(), logFileName);
                    if(!listOfFiles[i].getName().equals("Case.workflow")) {
                        updateOutboundMessage(listOfFiles[i].getPath(), listOfFiles[i].getName());
                    }
                }
            }


            // Loop through Settings files (though there's only one in our package at present) and create updated files.
            File folderCaseSettings = new File("files/unzippedRetrieveResults/unpackaged/settings");
            File[] listOfFilesCaseSettings = folderCaseSettings.listFiles();
            for( int i = 0; i < listOfFilesCaseSettings.length; i++) {
                if (listOfFilesCaseSettings[i].isFile()) {
                    TextFileUtility.writetoLogFile("File: " + listOfFilesCaseSettings[i].getPath(), logFileName);
                    TextFileUtility.writetoLogFile("Starting " + listOfFilesCaseSettings[i].getName(), logFileName);
                    updateCaseSettings(listOfFilesCaseSettings[i].getPath(), listOfFilesCaseSettings[i].getName());
                }
            }


            // Loop through Remote Site Settings files and create updated files.
            File folderRemoteSiteSettings = new File("files/unzippedRetrieveResults/unpackaged/remoteSiteSettings");
            File[] listOfFilesRemoteSiteSettings = folderRemoteSiteSettings.listFiles();
            for( int i = 0; i < listOfFilesRemoteSiteSettings.length; i++) {
                if (listOfFilesRemoteSiteSettings[i].isFile()) {
                    TextFileUtility.writetoLogFile("File: " + listOfFilesRemoteSiteSettings[i].getPath(), logFileName);
                    TextFileUtility.writetoLogFile("Starting " + listOfFilesRemoteSiteSettings[i].getName(), logFileName);
                    updateRemoteSiteSettings(listOfFilesRemoteSiteSettings[i].getPath(), listOfFilesRemoteSiteSettings[i].getName());
                }
            }        


            // Loop through ConnectedApp files and create updated files.
            File folderConnectedApps = new File("files/unzippedRetrieveResults/unpackaged/connectedApps");
            File[] listOfFilesConnectedApps = folderConnectedApps.listFiles();
            for( int i = 0; i < listOfFilesConnectedApps.length; i++) {
                if (listOfFilesConnectedApps[i].isFile()) {
                    TextFileUtility.writetoLogFile("File: " + listOfFilesConnectedApps[i].getPath(), logFileName);
                    TextFileUtility.writetoLogFile("Starting " + listOfFilesConnectedApps[i].getName(), logFileName);
                    updateConnectedApps(listOfFilesConnectedApps[i].getPath(), listOfFilesConnectedApps[i].getName());
                }
            }
            
            
            // Update Case object email alerts with Case-related sender.
            List<File> emailAlertUpdateFiles = new ArrayList<File>();
            File folderCaseAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/Case.workflow");
            emailAlertUpdateFiles.add(folderCaseAlert);
            File folderCommentAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/Comment__c.workflow");
            emailAlertUpdateFiles.add(folderCommentAlert);
            File folderEscalationAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/Escalation__c.workflow");
            emailAlertUpdateFiles.add(folderEscalationAlert);
            //File folderHowToAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/How_To__kav.workflow");
            //emailAlertUpdateFiles.add(folderHowToAlert);
            File folderLicenseKeyAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/License_Key__c.workflow");
            emailAlertUpdateFiles.add(folderLicenseKeyAlert);
            File folderCommentEmailQueueAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/RCCommentEmailQueue__c.workflow");
            emailAlertUpdateFiles.add(folderCommentEmailQueueAlert);
            File folderRocketContactAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/Rocket_Contact__c.workflow");
            emailAlertUpdateFiles.add(folderRocketContactAlert);
            //File folderTechNoteAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/Tech_Note__kav.workflow");
            //emailAlertUpdateFiles.add(folderTechNoteAlert);
            //File folderTroubleshootingAlert = new File("files/unzippedRetrieveResults/unpackaged/workflows/Troubleshooting__kav.workflow");
            //emailAlertUpdateFiles.add(folderTroubleshootingAlert);   
            for(File f : emailAlertUpdateFiles) {
                TextFileUtility.writetoLogFile("File: " + f.getPath(), logFileName);
                TextFileUtility.writetoLogFile("Starting " + f.getName(), logFileName);
                updateCaseEmailAlerts(f.getPath(), f.getName());
            }


            // Loop through CustomMetadata files and create updated files.
            File folderCustomMetadata = new File("files/unzippedRetrieveResults/unpackaged/customMetadata");
            File[] listOfFilesCustomMetadata = folderCustomMetadata.listFiles();
            for( int i = 0; i < listOfFilesCustomMetadata.length; i++) {
                if (listOfFilesCustomMetadata[i].isFile()) {
                    TextFileUtility.writetoLogFile("File: " + listOfFilesCustomMetadata[i].getPath(), logFileName);
                    TextFileUtility.writetoLogFile("Starting " + listOfFilesCustomMetadata[i].getName(), logFileName);
                    updateCustomMetadata(listOfFilesCustomMetadata[i].getPath(), listOfFilesCustomMetadata[i].getName());
                }
            }


            // Copy package.xml
            String destinationForPackageCopy = "files/updatedPackage/unpackaged/package.xml";
            
            try {
                GeneralUtility.copyFile(mainPackageXmlPath, destinationForPackageCopy);
            }
            catch(IOException ioe) {
                ioe.printStackTrace();
            }


            // Zip updated files
            String dirToZip = "files/updatedPackage/unpackaged";
            String destinationFilePath = "files/updatedPackageZip.zip";
            net.lingala.zip4j.ZipFile zippedOutboundMessagePackage = ZipUtility.zip(dirToZip, destinationFilePath, null);
            try {
                zippedOutboundMessagePackage.addFile(new File("files/updatedPackage/unpackaged/package.xml"));
            }
            catch(ZipException ze) {
                ze.printStackTrace();
            }
            
            File zipFileToDeploy = new File("files/updatedPackageZip.zip");
            
            try {
                if(DEPLOY) {
                    SalesforceUtility.deployZip(metadataConnection, zipFileToDeploy);
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        // START CONTACT EMAIL OBFUSCATION #################################################################################

        String retrievalDupeRulesFilename = "retrieveDupeRulesResults.zip";
        try {
            SalesforceUtility.retrieveMetadata(metadataConnection, dupeRulesPackageXmlPath, retrievalDupeRulesFilename);
        }
        catch(Exception e) {
            e.printStackTrace();
        }

        String fileZip = "files/" + retrievalDupeRulesFilename;
        File destDir = new File("files/unzippedDupeRulesRetrieveResults");
        byte[] buffer = new byte[1024];
        

        try {
            FileInputStream fileZipFileInputStream = new FileInputStream(fileZip);
            try (ZipInputStream zis = new ZipInputStream(fileZipFileInputStream)){
                ZipEntry zipEntry;
                while ((zipEntry = zis.getNextEntry()) != null) {
                    File newFile = GeneralUtility.newFile(destDir, zipEntry);
                    if (zipEntry.isDirectory()) {
                        if (!newFile.isDirectory() && !newFile.mkdirs()) {
                            throw new IOException("Failed to create directory " + newFile);
                        }
                    } else {
                        // fix for Windows-created archives
                        File parent = newFile.getParentFile();
                        if (!parent.isDirectory() && !parent.mkdirs()) {
                            throw new IOException("Failed to create directory " + parent);
                        }
                        
                        // write file content
                        FileOutputStream fos = new FileOutputStream(newFile);
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                        fos.close();
                    }
                    zis.closeEntry();
                }
                zis.close();
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
        catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        }

        // Build directories for the updated package
        String PATH = "files";
        String directoryName1 = PATH.concat("/dupeRulesPackage");
        String directoryName2 = directoryName1.concat("/unpackaged");
        String directoryName3 = directoryName2.concat("/duplicateRules");
        String directoryName4 = directoryName2.concat("/settings");
        List<String> directoryNames = new ArrayList<String>();
        directoryNames.add(directoryName1);
        directoryNames.add(directoryName2);
        directoryNames.add(directoryName3);
        directoryNames.add(directoryName4);
        for(String directoryName : directoryNames) {
            File directory = new File(directoryName);
            if(!directory.exists()) {
                directory.mkdir();
            }
        }

        
        // SET UP SF DEPLOYMENT

        // Copy package.xml
        String destinationForDupeRulesPackageCopy = "files/dupeRulesPackage/unpackaged/package.xml";

        try {
            GeneralUtility.copyFile(dupeRulesPackageXmlPath, destinationForDupeRulesPackageCopy);
        }
        catch(IOException ioe) {
            ioe.printStackTrace();
        }
       obfuscateContactEmailAddresses(connection);
       obfuscateQuoteRecipient1EmailAddresses(connection);
       obfuscateQuoteRecipient2EmailAddresses(connection); 
    }


    public static void updateOutboundMessage(String path, String filename) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

            if(filename.equals("Opportunity.workflow")) {
                NodeList list = doc.getElementsByTagName("outboundMessages");

                for (int temp = 0; temp < list.getLength(); temp++) {
                    Node node = list.item(temp);

                    TextFileUtility.writetoLogFile("node info: " + node.getNodeName(), logFileName);
                    NodeList listOfOutboundMessagesElements = ((Element)node).getElementsByTagName("*");


                    String whichOutboundMessage = "";
                    Node node2;
                    for(int temp2 = 0; temp2 < listOfOutboundMessagesElements.getLength(); temp2++) {
                        node2 = listOfOutboundMessagesElements.item(temp2);
                        if(node2.getNodeName().equals("fullName") && node2.getTextContent().equals("OA_Project_Sync")) {
                           whichOutboundMessage = "OA_Project_Sync";
                        }
                        else if(node2.getNodeName().equals("fullName") && node2.getTextContent().equals("OpportunityPivotalExport")) {
                            whichOutboundMessage = "OpportunityPivotalExport";
                        }
                    }

                    if(whichOutboundMessage.equals("OA_Project_Sync")) {
                        NodeList omsChildNodes = node.getChildNodes();
                        for(int temp3 = 0; temp3 < omsChildNodes.getLength(); temp3++) {
                            Node node3 = omsChildNodes.item(temp3);
                            if(node3.getNodeName().equals("endpointUrl")) {
                                Element element = (Element) node3;
        
                                String endpointUrl = element.getTextContent();
                                TextFileUtility.writetoLogFile(endpointUrl, logFileName);
        
                                Integer dotComSlashIndex = endpointUrl.indexOf(".com/");
    
                                endpointUrl = outboundMessageUrl + endpointUrl.substring(dotComSlashIndex + 5);
    
                                Integer lastSemiColonIndex = endpointUrl.lastIndexOf(";");
    
                                endpointUrl = endpointUrl.substring(0, lastSemiColonIndex) + endpointAuthAppendix;
        
                                element.setTextContent(endpointUrl);
                            }
                        }
                    }
                    else if(whichOutboundMessage.equals("OpportunityPivotalExport")) {
                        NodeList omsChildNodes = node.getChildNodes();
                        for(int temp3 = 0; temp3 < omsChildNodes.getLength(); temp3++) {
                            Node node3 = omsChildNodes.item(temp3);
                            if(node3.getNodeName().equals("endpointUrl")) {
                                Element element = (Element) node3;
        
                                String endpointUrl = element.getTextContent();
                                TextFileUtility.writetoLogFile(endpointUrl, logFileName);
        
                                Integer dotComSlashIndex = endpointUrl.indexOf(".com/");
    
                                endpointUrl = outboundMessageUrl + endpointUrl.substring(dotComSlashIndex + 5);
        
                                element.setTextContent(endpointUrl);
                            }
                        }
                    } 
                }
            }
            else {                 
                NodeList list = doc.getElementsByTagName("endpointUrl");

                for (int temp = 0; temp < list.getLength(); temp++) {
                    Node node = list.item(temp);

                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                        Element element = (Element) node;

                        String endpointUrl = element.getTextContent();
                        TextFileUtility.writetoLogFile(endpointUrl, logFileName);

                        Integer dotComSlashIndex = endpointUrl.indexOf(".com/");

                        if(filename.equals("OrderItem.workflow")) {
                            endpointUrl = ulsEndpointUrl;

                            element.setTextContent(endpointUrl);
                        }
                        else {
                            endpointUrl = outboundMessageUrl + endpointUrl.substring(dotComSlashIndex + 5);

                            Integer lastSemiColonIndex = endpointUrl.lastIndexOf(";");

                            endpointUrl = endpointUrl.substring(0, lastSemiColonIndex) + endpointAuthAppendix;
    
                            element.setTextContent(endpointUrl);
                        }
                    }
                }
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/updatedPackage/unpackaged/workflows/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }        
    }


    public static void updateCaseSettings(String path, String filename) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

          
            NodeList list = doc.getElementsByTagName("routingAddresses");

            for (int temp = list.getLength() - 1; temp >= 0; temp--) {
                Node node = list.item(temp);
                NodeList childrenForRoutingAddress = node.getChildNodes();
                Boolean isRocketSupportRoutingAddress = false;
                for(int temp2 = 0; temp2 < childrenForRoutingAddress.getLength(); temp2++) {
                    if(childrenForRoutingAddress.item(temp2).getNodeName().equals("routingName") && childrenForRoutingAddress.item(temp2).getTextContent().equals("Rocket Support")) {
                        isRocketSupportRoutingAddress = true;
                    }
                }
                if(isRocketSupportRoutingAddress) {
                    for(int temp2 = 0; temp2 < childrenForRoutingAddress.getLength(); temp2++) {
                        if(childrenForRoutingAddress.item(temp2).getNodeName().equals("emailAddress")) {
                            Element element = (Element) childrenForRoutingAddress.item(temp2);
                            element.setTextContent(rocketSupportRoutingAddress);
                        }
                    }                    
                }
                else {
                    // Delete the element if it's not "Rocket Support" so we don't deploy redundant routing addresses.
                    node.getParentNode().removeChild(node);                    
                }
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/updatedPackage/unpackaged/settings/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }        
    }


    public static void updateRemoteSiteSettings(String path, String filename) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

          
            NodeList list = doc.getElementsByTagName("url");

            for (int temp = list.getLength() - 1; temp >= 0; temp--) {
                Node node = list.item(temp);
                Element element = (Element) node;
                if(filename.equals("sffiles.remoteSite")) {
                    element.setTextContent(sffilesUrl);
                }
                else if(filename.equals("download_rs.remoteSite")) {
                    element.setTextContent(downloadRsUrl);
                }
                else if(filename.equals("Pivsfdc.remoteSite")) {
                    element.setTextContent(pivsfdcUrl);
                }
                else if(filename.equals("Rocketrack.remoteSite")) {
                    element.setTextContent(rocketrackUrl);
                }
                else if(filename.equals("Rocket_SFDC_front_door.remoteSite")) {
                    element.setTextContent(orgSpecficUrl);
                }
                else if(filename.equals("Salesforce_Side_Panel.remoteSite")) {
                    element.setTextContent(orgSpecficUrl);
                }
                else if(filename.equals("SF.remoteSite")) {
                    element.setTextContent(orgSpecficUrl);
                }
                else if(filename.equals("SFDC_Content.remoteSite")) {
                    element.setTextContent("https://rocketsoftware--c." + instanceId + ".content.force.com");
                }                
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/updatedPackage/unpackaged/remoteSiteSettings/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }        
    }


    public static void updateConnectedApps(String path, String filename) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

            NodeList list = doc.getElementsByTagName("canvasUrl");

            for (int temp = list.getLength() - 1; temp >= 0; temp--) {
                Node node = list.item(temp);
                Element element = (Element) node;
                TextFileUtility.writetoLogFile("element.getTextContent() is: " + element.getTextContent(), logFileName);
                String textToCheck = element.getTextContent();
                element.setTextContent(textToCheck.replaceAll("(.*)//(.*)\\.com",sffilesUrl));

            }

            NodeList list2 = doc.getElementsByTagName("callbackUrl");

            for (int temp = list2.getLength() - 1; temp >= 0; temp--) {
                Node node = list2.item(temp);
                Element element = (Element) node;
                TextFileUtility.writetoLogFile("element.getTextContent() is: " + element.getTextContent(), logFileName);
                String textToCheck = element.getTextContent();
                element.setTextContent(textToCheck.replaceAll("(.*)//(.*)\\.com",sffilesUrl));

            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/updatedPackage/unpackaged/connectedApps/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }        
    }


    public static void updateCaseEmailAlerts(String path, String filename) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

            
            NodeList list = doc.getElementsByTagName("alerts");

            for (int temp = 0; temp < list.getLength(); temp++) {
                Node node = list.item(temp);

                TextFileUtility.writetoLogFile("node info: " + node.getNodeName(), logFileName);
 
                NodeList alertsChildNodes = node.getChildNodes();
                for(int temp2 = 0; temp2 < alertsChildNodes.getLength(); temp2++) {
                    Node node2 = alertsChildNodes.item(temp2);
                    if(node2.getNodeName().equals("senderAddress")) {
                        Element element = (Element) node2;
                        element.setTextContent(caseAlertEmailAddress);
                    }
                }
            }
            

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/updatedPackage/unpackaged/workflows/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }        
    }


    public static void updateCustomMetadata(String path, String filename) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

            
            NodeList list = doc.getElementsByTagName("values");

            for (int temp = 0; temp < list.getLength(); temp++) {
                Node node = list.item(temp);

                TextFileUtility.writetoLogFile("node info: " + node.getNodeName(), logFileName);
 
                NodeList alertsChildNodes = node.getChildNodes();
                for(int temp2 = 0; temp2 < alertsChildNodes.getLength(); temp2++) {
                    Node node2 = alertsChildNodes.item(temp2);
                    if(node2.getNodeName().equals("value")) {
                        Element element = (Element) node2;
                        if(filename.equals("DocuSignRESTSettings.ButtonPassThruBaseURL.md")) {
                            element.setTextContent(dsButtonPassThruBaseURL);
                        }
                        if(filename.equals("DocuSignRESTSettings.ClmAccountId.md")) {
                            element.setTextContent(dsClmAccountId);
                        }
                        if(filename.equals("DocuSignRESTSettings.CLMv2ApiEndpoint.md")) {
                            element.setTextContent(dsCLMv2ApiEndpoint);
                        }
                        if(filename.equals("DocuSignRESTSettings.DataCenter.md")) {
                            element.setTextContent(dsDataCenter);
                        }
                        if(filename.equals("DocuSignRESTSettings.DSAccountID.md")) {
                            element.setTextContent(dsDSAccountID);
                        }
                        if(filename.equals("DocuSignRESTSettings.DSUserName.md")) {
                            element.setTextContent(dsDSUserName);
                        }
                        if(filename.equals("DocuSignRESTSettings.RequestAuthDomain.md")) {
                            element.setTextContent(dsRequestAuthDomain);
                        }
                        if(filename.equals("DocuSignRESTSettings.RequestAuthEndpoint.md")) {
                            element.setTextContent(dsRequestAuthEndpoint);
                        }
                    }
                }
            }
            

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/updatedPackage/unpackaged/customMetadata/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }        
    }


    public static void obfuscateContactEmailAddresses(PartnerConnection pc) {
        
        List<String> filenamesToReactivate = deactivateDuplicateRules();

        File contactLoadFile;
        if(contactUpdateFile==null) {
            contactLoadFile = createContactEmailUpdateFile(pc);
        }
        else {
            contactLoadFile = contactUpdateFile;
        }

        long lines = 0;
        try {
            lines = Files.lines(contactLoadFile.toPath()).count();
        } 
        catch(Exception e) {
            e.printStackTrace();
        }

        if(lines>1) {
            bulkContactUpdate(pc, contactLoadFile);
        }

        reactivateDuplicateRules(filenamesToReactivate);
    }


    private static File createContactEmailUpdateFile(PartnerConnection pc) {


        File contactLoadFile = new File("loadFiles/ContactLoadFile_" + runDateTime + ".csv");
        List<String> headerRowFields = new ArrayList<String>();
        headerRowFields.add("ID");
        headerRowFields.add("Email");
        CsvUtility.startCsv(contactLoadFile, headerRowFields);

        String queryContacts = "SELECT Id, Email FROM Contact WHERE Email <> null AND (NOT Email LIKE '%=%example.com%')";
            
        try {
            // Set query batch size
            pc.setQueryOptions(200);
            
            // Make the query call and get the query results
            QueryResult qr = pc.query(queryContacts);
            
            boolean done = false;

            int totalContactsQueried = qr.getSize();
            TextFileUtility.writetoLogFile("TOTAL CONTACTS SELECTED: " + totalContactsQueried, logFileName);
            int recordsQueriedCounter = 0;
            int thisLoopStartCount = 1;
            // Loop through the batches of returned results
            while (!done) {
                SObject[] records = qr.getRecords();
                recordsQueriedCounter += records.length;
                String startingMessage = "Adding Contacts to Update CSV: " + thisLoopStartCount + " - " + recordsQueriedCounter + " of " + totalContactsQueried;
                thisLoopStartCount += records.length;
                TextFileUtility.writetoLogFile(startingMessage, logFileName);

                for(int i=0; i < records.length; i++) {
                    SObject contactForLoop = records[i];
                    if(contactForLoop!=null) {
                        if(contactForLoop.getSObjectField("Email")!=null) {
                            String contactEmail = contactForLoop.getSObjectField("Email").toString();
                            if(contactEmail!=null && contactEmail!="") {
                                //TextFileUtility.writetoLogFile("STARTING EMAIL: " + contactEmail, logFileName);
                                if(!contactEmail.contains("=") && !contactEmail.contains("@example.com")) {
                                    contactEmail = contactEmail.replace("@","=");
                                    contactEmail = contactEmail + "@example.com";
                                    //TextFileUtility.writetoLogFile("ENDING EMAIL: " + contactEmail, logFileName);
                                    String[] dataForRow = new String[]{contactForLoop.getId(), contactEmail};
                                    CsvUtility.writeToCsv(dataForRow, contactLoadFile);
                                }
                            }
                        }
                    }
                }

                if (qr.isDone()) {
                    done = true;
                } else {
                    qr = pc.queryMore(qr.getQueryLocator());
                }

            }
        } catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return contactLoadFile;
    }
    //For updating Quote email address
    public static void obfuscateQuoteRecipient1EmailAddresses(PartnerConnection pc) {
        
        List<String> filenamesToReactivate = deactivateDuplicateRules();

        File quoteLoadFile;
        if(quoteUpdateFile==null) {
            quoteLoadFile = createRecipient1UpdateFile(pc);
        }
        else {
            quoteLoadFile = quoteUpdateFile;
        }

        long lines = 0;
        try {
            lines = Files.lines(quoteLoadFile.toPath()).count();
        } 
        catch(Exception e) {
            e.printStackTrace();
        }

        if(lines>1) {
            bulkQuoteUpdate(pc, quoteLoadFile);
        }

        reactivateDuplicateRules(filenamesToReactivate);
    }
    private static File createRecipient1UpdateFile(PartnerConnection pc) {
        File quoteLoadFile = new File("loadFiles/QuoteLoadFile_" + runDateTime + ".csv");
        List<String> headerRowFields = new ArrayList<String>();
        headerRowFields.add("ID");
        headerRowFields.add("Additional_Quote_Recipient_1__c");
        CsvUtility.startCsv(quoteLoadFile, headerRowFields);

        String queryQuotes = "Select Id,Additional_Quote_Recipient_1__c from SBQQ__Quote__c where Additional_Quote_Recipient_1__c <> null AND (NOT Additional_Quote_Recipient_1__c LIKE '%=%example.com%')";
            
        try {
            // Set query batch size
            pc.setQueryOptions(200);
            
            // Make the query call and get the query results
            QueryResult qr = pc.query(queryQuotes);
            
            boolean done = false;

            int totalContactsQueried = qr.getSize();
            TextFileUtility.writetoLogFile("TOTAL QUOTES SELECTED: " + totalContactsQueried, logFileName);
            int recordsQueriedCounter = 0;
            int thisLoopStartCount = 1;
            // Loop through the batches of returned results
            while (!done) {
                SObject[] records = qr.getRecords();
                recordsQueriedCounter += records.length;
                String startingMessage = "Adding Contacts to Update CSV: " + thisLoopStartCount + " - " + recordsQueriedCounter + " of " + totalContactsQueried;
                thisLoopStartCount += records.length;
                TextFileUtility.writetoLogFile(startingMessage, logFileName);

                for(int i=0; i < records.length; i++) {
                    SObject contactForLoop = records[i];
                    if(contactForLoop!=null) {
                        if(contactForLoop.getSObjectField("Additional_Quote_Recipient_1__c")!=null) {
                            String Recipient1Email = contactForLoop.getSObjectField("Additional_Quote_Recipient_1__c").toString();
                            if(Recipient1Email != null && Recipient1Email != "") {
                                //TextFileUtility.writetoLogFile("STARTING EMAIL: " + contactEmail, logFileName);
                                if(!Recipient1Email.contains("=") && !Recipient1Email.contains("@example.com")) {
                                    Recipient1Email = Recipient1Email.replace("@","=");
                                    Recipient1Email = Recipient1Email + "@example.com";
                                    //TextFileUtility.writetoLogFile("ENDING EMAIL: " + contactEmail, logFileName);
                                    String[] dataForRow = new String[]{contactForLoop.getId(), Recipient1Email};
                                    CsvUtility.writeToCsv(dataForRow, quoteLoadFile);
                                }
                            }
                        }
                        }
                    }

                if (qr.isDone()) {
                    done = true;
                } else {
                    qr = pc.queryMore(qr.getQueryLocator());
                }
            }
        } catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return quoteLoadFile;      
    }
    public static void obfuscateQuoteRecipient2EmailAddresses(PartnerConnection pc) {
        
        List<String> filenamesToReactivate = deactivateDuplicateRules();

        File quoteLoadFile;
        if(quoteUpdateFile==null) {
            quoteLoadFile = createRecipient2UpdateFile(pc);
        }
        else {
            quoteLoadFile = quoteUpdateFile;
        }

        long lines = 0;
        try {
            lines = Files.lines(quoteLoadFile.toPath()).count();
        } 
        catch(Exception e) {
            e.printStackTrace();
        }

        if(lines>1) {
            bulkQuoteUpdate(pc, quoteLoadFile);
        }

        reactivateDuplicateRules(filenamesToReactivate);
    }
    private static File createRecipient2UpdateFile(PartnerConnection pc) {
        File quoteLoadFile = new File("loadFiles/QuoteLoadFile_" + runDateTime + ".csv");
        List<String> headerRowFields = new ArrayList<String>();
        headerRowFields.add("ID");
        headerRowFields.add("Additional_Quote_Recipient_2__c");
        CsvUtility.startCsv(quoteLoadFile, headerRowFields);

        String queryQuotes = "Select Id,Additional_Quote_Recipient_2__c from SBQQ__Quote__c where Additional_Quote_Recipient_2__c <> null AND (NOT Additional_Quote_Recipient_2__c LIKE '%=%example.com%')";
            
        try {
            // Set query batch size
            pc.setQueryOptions(200);
            
            // Make the query call and get the query results
            QueryResult qr = pc.query(queryQuotes);
            
            boolean done = false;

            int totalContactsQueried = qr.getSize();
            TextFileUtility.writetoLogFile("TOTAL QUOTES SELECTED: " + totalContactsQueried, logFileName);
            int recordsQueriedCounter = 0;
            int thisLoopStartCount = 1;
            // Loop through the batches of returned results
            while (!done) {
                SObject[] records = qr.getRecords();
                recordsQueriedCounter += records.length;
                String startingMessage = "Adding Contacts to Update CSV: " + thisLoopStartCount + " - " + recordsQueriedCounter + " of " + totalContactsQueried;
                thisLoopStartCount += records.length;
                TextFileUtility.writetoLogFile(startingMessage, logFileName);

                for(int i=0; i < records.length; i++) {
                    SObject contactForLoop = records[i];
                    if(contactForLoop!=null) {
                        if(contactForLoop.getSObjectField("Additional_Quote_Recipient_2__c")!=null) {
                            String Recipient2Email = contactForLoop.getSObjectField("Additional_Quote_Recipient_2__c").toString();
                            if(Recipient2Email != null && Recipient2Email != "") {
                                //TextFileUtility.writetoLogFile("STARTING EMAIL: " + contactEmail, logFileName);
                                if(!Recipient2Email.contains("=") && !Recipient2Email.contains("@example.com")) {
                                    Recipient2Email = Recipient2Email.replace("@","=");
                                    Recipient2Email = Recipient2Email + "@example.com";
                                    //TextFileUtility.writetoLogFile("ENDING EMAIL: " + contactEmail, logFileName);
                                    String[] dataForRow = new String[]{contactForLoop.getId(), Recipient2Email};
                                    CsvUtility.writeToCsv(dataForRow, quoteLoadFile);
                                }
                            }
                        }
                        }
                    }

                if (qr.isDone()) {
                    done = true;
                } else {
                    qr = pc.queryMore(qr.getQueryLocator());
                }
            }
        } catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return quoteLoadFile;      
    }
    private static void bulkContactUpdate(PartnerConnection pc, File contactLoadFile) {
        try {
            BulkConnection bulkConnection = SalesforceUtility.getBulkConnection(pc);
            JobInfo job = SalesforceUtility.createJob("Contact", bulkConnection, "update");
            List<BatchInfo> batchInfoList = SalesforceUtility.createBatchesFromCSVFile(bulkConnection, job, contactLoadFile.getPath());
            SalesforceUtility.closeJob(bulkConnection, job.getId());
            SalesforceUtility.awaitCompletion(bulkConnection, job, batchInfoList);
            SalesforceUtility.checkResults(bulkConnection, job, batchInfoList);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    private static void bulkQuoteUpdate(PartnerConnection pc, File quoteLoadFile) {
        try {
            BulkConnection bulkConnection = SalesforceUtility.getBulkConnection(pc);
            JobInfo job = SalesforceUtility.createJob("SBQQ__Quote__c", bulkConnection, "update");
            List<BatchInfo> batchInfoList = SalesforceUtility.createBatchesFromCSVFile(bulkConnection, job, quoteLoadFile.getPath());
            SalesforceUtility.closeJob(bulkConnection, job.getId());
            SalesforceUtility.awaitCompletion(bulkConnection, job, batchInfoList);
            SalesforceUtility.checkResults(bulkConnection, job, batchInfoList);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    
    public static List<String> deactivateDuplicateRules() {
        List<String> filenamesToReactivate = new ArrayList<String>();
        // Loop through DuplicateRules files and create updated files.
        File folderDuplicateRules = new File("files/unzippedDupeRulesRetrieveResults/unpackaged/duplicateRules");
        File[] listOfFilesDuplicateRules = folderDuplicateRules.listFiles();
        for( int i = 0; i < listOfFilesDuplicateRules.length; i++) {
            if (listOfFilesDuplicateRules[i].isFile()) {
                TextFileUtility.writetoLogFile("File: " + listOfFilesDuplicateRules[i].getPath(), logFileName);
                TextFileUtility.writetoLogFile("Starting " + listOfFilesDuplicateRules[i].getName(), logFileName);
                filenamesToReactivate.add(updateDuplicateRules(listOfFilesDuplicateRules[i].getPath(), listOfFilesDuplicateRules[i].getName(),"INACTIVATE"));
            }
        }

        communitySettingsUpdate("files/unzippedDupeRulesRetrieveResults/unpackaged/settings/Communities.settings", "Communities.settings", "ACTIVATE");

        // Zip updated files
        String dirToZip = "files/dupeRulesPackage/unpackaged";
        String destinationFilePath = "files/dupeRulesPackageZip.zip";
        net.lingala.zip4j.ZipFile zippedOutboundMessagePackage = ZipUtility.zip(dirToZip, destinationFilePath, null);
        try {
            zippedOutboundMessagePackage.addFile(new File("files/dupeRulesPackage/unpackaged/package.xml"));
        }
        catch(ZipException ze) {
            ze.printStackTrace();
        }
        
        File zipFileToDeploy = new File("files/dupeRulesPackageZip.zip");
        
        try {
            if(DEPLOY) {
                SalesforceUtility.deployZip(metadataConnection, zipFileToDeploy);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return filenamesToReactivate;
    }


    public static String updateDuplicateRules(String path, String filename, String action) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        String filenameToReturn = "";

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

            
            NodeList list = doc.getElementsByTagName("DuplicateRule");

            for (int temp = 0; temp < list.getLength(); temp++) {
                Node node = list.item(temp);

                TextFileUtility.writetoLogFile("node info: " + node.getNodeName(), logFileName);
 
                NodeList childNodes = node.getChildNodes();
                for(int temp2 = 0; temp2 < childNodes.getLength(); temp2++) {
                    Node node2 = childNodes.item(temp2);
                    TextFileUtility.writetoLogFile("node2.getNodeName(): " + node2.getNodeName(), logFileName);
                    if(node2.getNodeName().equals("isActive")) {
                        Element element = (Element) node2;
                        if(action.equals("INACTIVATE") && element.getTextContent().equals("true")) {
                            element.setTextContent("false");
                            filenameToReturn = filename; // Returning filenames to reactivate...
                        }
                        if(action.equals("ACTIVATE") && element.getTextContent().equals("false")) {
                            element.setTextContent("true");
                        }
                    }
                }
            }
            

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/dupeRulesPackage/unpackaged/duplicateRules/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }
        return filenameToReturn;  
    }


    public static void reactivateDuplicateRules(List<String> filenamesToReactivate) {
        // Loop through DuplicateRules files and create updated files.
        File folderDuplicateRules = new File("files/unzippedDupeRulesRetrieveResults/unpackaged/duplicateRules");
        File[] listOfFilesDuplicateRules = folderDuplicateRules.listFiles();
        for( int i = 0; i < listOfFilesDuplicateRules.length; i++) {
            if (listOfFilesDuplicateRules[i].isFile() && filenamesToReactivate.contains(listOfFilesDuplicateRules[i].getName())) {
                TextFileUtility.writetoLogFile("File: " + listOfFilesDuplicateRules[i].getPath(), logFileName);
                TextFileUtility.writetoLogFile("Starting " + listOfFilesDuplicateRules[i].getName(), logFileName);
                updateDuplicateRules(listOfFilesDuplicateRules[i].getPath(), listOfFilesDuplicateRules[i].getName(), "ACTIVATE");
            }
        }

        communitySettingsUpdate("files/unzippedDupeRulesRetrieveResults/unpackaged/settings/Communities.settings", "Communities.settings", "INACTIVATE");

        // Zip updated files
        String dirToZip = "files/dupeRulesPackage/unpackaged";
        String destinationFilePath = "files/dupeRulesPackageZip.zip";
        net.lingala.zip4j.ZipFile zippedOutboundMessagePackage = ZipUtility.zip(dirToZip, destinationFilePath, null);
        try {
            zippedOutboundMessagePackage.addFile(new File("files/dupeRulesPackage/unpackaged/package.xml"));
        }
        catch(ZipException ze) {
            ze.printStackTrace();
        }
        
        File zipFileToDeploy = new File("files/dupeRulesPackageZip.zip");
        
        try {
            if(DEPLOY) {
                SalesforceUtility.deployZip(metadataConnection, zipFileToDeploy);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void communitySettingsUpdate(String path, String filename, String action) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(path));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            TextFileUtility.writetoLogFile("Root Element: " + doc.getDocumentElement().getNodeName(), logFileName);
            TextFileUtility.writetoLogFile("------", logFileName);

            
            NodeList list = doc.getElementsByTagName("CommunitiesSettings");

            for (int temp = 0; temp < list.getLength(); temp++) {
                Node node = list.item(temp);

                TextFileUtility.writetoLogFile("node info: " + node.getNodeName(), logFileName);
 
                NodeList childNodes = node.getChildNodes();
                for(int temp2 = 0; temp2 < childNodes.getLength(); temp2++) {
                    Node node2 = childNodes.item(temp2);
                    TextFileUtility.writetoLogFile("node2.getNodeName(): " + node2.getNodeName(), logFileName);
                    if(node2.getNodeName().equals("enableOotbProfExtUserOpsEnable")) {
                        Element element = (Element) node2;
                        if(action.equals("INACTIVATE") && element.getTextContent().equals("true")) {
                            element.setTextContent("false");
                        }
                        if(action.equals("ACTIVATE") && element.getTextContent().equals("false")) {
                            element.setTextContent("true");
                        }
                    }
                }
            }
            

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(new File("files/dupeRulesPackage/unpackaged/settings/" + filename));
            Source input = new DOMSource(doc);

            transformer.transform(input, output);

        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }
    }


        private static void setUpProperties() {
        // create and load default properties
        defaultProps = new Properties();
        FileInputStream in = null;
        try {
            in = new FileInputStream("defaultProperties");
            defaultProps.load(in);
            in.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }
}
