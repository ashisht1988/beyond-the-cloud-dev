package com.gilliam;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class TextFileUtility {

    public static void createLogFile(String fileNameString) {
        try {
            File myObj = new File("logs/" + fileNameString + ".txt");
            FileWriter writer = new FileWriter(myObj);
            writer.write("START LOG FILE - " + LocalDateTime.now() + "\r\n");
            writer.close();
          } catch (IOException e) {
            System.out.println("An error occurred creating the log file.");
            e.printStackTrace();
          }        
    }

    public static void writetoLogFile(String logFileEntry, String fileNameString) {
      DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
      LocalDateTime now = LocalDateTime.now();
      String logDateTime = dtf.format(now);  
      try {
            FileWriter myWriter = new FileWriter("logs/" + fileNameString + ".txt", true);
            myWriter.write("[" + logDateTime + "]  " + logFileEntry+"\r\n");
            myWriter.close();
            System.out.println(" [" + logDateTime + "]   " + logFileEntry);
          } catch (IOException e) {
            System.out.println("An error occurred writing to the log file.");
            e.printStackTrace();
          }        
    }
    
}