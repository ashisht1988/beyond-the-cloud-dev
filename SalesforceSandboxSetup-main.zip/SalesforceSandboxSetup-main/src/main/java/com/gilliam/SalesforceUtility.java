package com.gilliam;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.input.BOMInputStream;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sforce.soap.partner.*;
import com.sforce.soap.partner.Error;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;
import com.opencsv.CSVReader;
import com.sforce.async.AsyncApiException;
import com.sforce.async.BatchInfo;
import com.sforce.async.BatchStateEnum;
import com.sforce.async.BulkConnection;
import com.sforce.async.ContentType;
import com.sforce.async.JobInfo;
import com.sforce.async.JobStateEnum;
import com.sforce.async.OperationEnum;
import com.sforce.soap.metadata.AsyncResult;
import com.sforce.soap.metadata.CodeCoverageWarning;
import com.sforce.soap.metadata.DeployDetails;
import com.sforce.soap.metadata.DeployMessage;
import com.sforce.soap.metadata.DeployOptions;
import com.sforce.soap.metadata.DeployResult;
import com.sforce.soap.metadata.MetadataConnection;
import com.sforce.soap.metadata.RetrieveMessage;
import com.sforce.soap.metadata.RetrieveRequest;
import com.sforce.soap.metadata.RetrieveResult;
import com.sforce.soap.metadata.RetrieveStatus;
import com.sforce.soap.metadata.RunTestFailure;
import com.sforce.soap.metadata.RunTestsResult;
import com.sforce.soap.metadata.PackageTypeMembers;


public class SalesforceUtility {

    public static final double API_VERSION = 50.0;
    //public static final String MANIFEST_FILE= "resources/package.xml";
    // one second in milliseconds
    private static final long ONE_SECOND = 1000;
    // maximum number of attempts to retrieve the results
    private static final int MAX_NUM_POLL_REQUESTS = 50;
    static BufferedReader rdr = new BufferedReader(new InputStreamReader(System.in));


    
    public static List<SObject> querySf(PartnerConnection pc, String soqlQuery) {    
        
        List<SObject> sObjs = new ArrayList<SObject>();
        
        try {
            // Set query batch size
            pc.setQueryOptions(250);
            
            // Make the query call and get the query results
            QueryResult qr = pc.query(soqlQuery);
            
            boolean done = false;
            int loopCount = 0;
            // Loop through the batches of returned results
            while (!done) {
                TextFileUtility.writetoLogFile("Records in results set " + loopCount++, Main.logFileName);
                SObject[] records = qr.getRecords();
                Collections.addAll(sObjs,records);

                if (qr.isDone()) {
                    done = true;
                } else {
                    qr = pc.queryMore(qr.getQueryLocator());
                }
            }
        } catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        TextFileUtility.writetoLogFile("\nQuery execution completed.", Main.logFileName);
        return sObjs;       
    }
    

    public static void updateSObjs(PartnerConnection pc, List<SObject> sObjList) {
        try {
            // Create an sObject of type contact
            SObject[] sObjArray = new SObject[sObjList.size()];
            sObjArray = sObjList.toArray(sObjArray);
      
            // Make the update call by passing an array containingnthe objects. 
            SaveResult[] saveResults = pc.update(sObjArray);

            // Iterate through the results and write the ID of 
            // the updated contacts to the console.
            // If the result is not successful, write the errors
            // to the console.
            for (int j = 0; j < saveResults.length; j++) {
                //TextFileUtility.writetoLogFile("\nItem: " + j, Main.logFileName);
                if (saveResults[j].isSuccess()) {
                    //TextFileUtility.writetoLogFile("Record with an ID of " + saveResults[j].getId() + " was updated.", Main.logFileName);
                }
                else {                        
                  // There were errors during the update call,
                  // go through the errors array and write
                  // them to the console.
                  for (int i = 0; i < saveResults[j].getErrors().length; i++) {
                    Error err = saveResults[j].getErrors()[i];
                    TextFileUtility.writetoLogFile("Errors were found on item " + j, Main.logFileName);
                    TextFileUtility.writetoLogFile("Error code: " + err.getStatusCode().toString(), Main.logFileName);
                    TextFileUtility.writetoLogFile("Error message: " + err.getMessage(), Main.logFileName);
                  }
                }      
            }      
        } catch (ConnectionException ce) {
            ce.printStackTrace();
        }
    }    


    public static void retrieveMetadata(MetadataConnection mc, String manifestFile, String retrievalFilename) throws RemoteException, Exception {
        RetrieveRequest retrieveRequest = new RetrieveRequest();
        // The version in package.xml overrides the version in RetrieveRequest
        retrieveRequest.setApiVersion(API_VERSION);
        setUnpackaged(retrieveRequest, manifestFile);

        // Start the retrieve operation
        AsyncResult asyncResult = mc.retrieve(retrieveRequest);
        String asyncResultId = asyncResult.getId();
    
        // Wait for the retrieve to complete
        int poll = 0;
        long waitTimeMilliSecs = ONE_SECOND;
        RetrieveResult result = null;
        do {
            Thread.sleep(waitTimeMilliSecs);
            // Double the wait time for the next iteration
            waitTimeMilliSecs *= 2;
            if (poll++ > MAX_NUM_POLL_REQUESTS) {
                throw new Exception("Request timed out.  If this is a large set " +
                "of metadata components, check that the time allowed " +
                "by MAX_NUM_POLL_REQUESTS is sufficient.");
            }
            result = mc.checkRetrieveStatus(
                    asyncResultId, true);
            TextFileUtility.writetoLogFile("Retrieve Status: " + result.getStatus(), Main.logFileName);
        } while (!result.isDone());

        if (result.getStatus() == RetrieveStatus.Failed) {
            throw new Exception(result.getErrorStatusCode() + " msg: " +
                    result.getErrorMessage());
        } else if (result.getStatus() == RetrieveStatus.Succeeded) {      
            // Print out any warning messages
            StringBuilder buf = new StringBuilder();
            if (result.getMessages() != null) {
                for (RetrieveMessage rm : result.getMessages()) {
                    buf.append(rm.getFileName() + " - " + rm.getProblem());
                }
            }
            if (buf.length() > 0) {
                TextFileUtility.writetoLogFile("Retrieve warnings:\n" + buf, Main.logFileName);
            }

            // Write the zip to the file system
            TextFileUtility.writetoLogFile("Writing results to zip file", Main.logFileName);
            ByteArrayInputStream bais = new ByteArrayInputStream(result.getZipFile());
            File resultsFile = new File("files/" + retrievalFilename);
            FileOutputStream os = new FileOutputStream(resultsFile);
            try {
                ReadableByteChannel src = Channels.newChannel(bais);
                FileChannel dest = os.getChannel();
                copy(src, dest);
                
                TextFileUtility.writetoLogFile("Results written to " + resultsFile.getAbsolutePath(), Main.logFileName);
            } finally {
                os.close();
            }
        }
    }


    public static void setUnpackaged(RetrieveRequest request, String manifestFile) throws Exception
    {
        // Edit the path, if necessary, if your package.xml file is located elsewhere
        File unpackedManifest = new File(manifestFile);
        TextFileUtility.writetoLogFile("Manifest file: " + unpackedManifest.getAbsolutePath(), Main.logFileName);
        
        if (!unpackedManifest.exists() || !unpackedManifest.isFile())
            throw new Exception("Should provide a valid retrieve manifest " +
                    "for unpackaged content. " +
                    "Looking for " + unpackedManifest.getAbsolutePath());
 
        // Note that we populate the _package object by parsing a manifest file here.
        // You could populate the _package based on any source for your
        // particular application.
        com.sforce.soap.metadata.Package p = parsePackage(unpackedManifest);
        request.setUnpackaged(p);
    }    


    public static com.sforce.soap.metadata.Package parsePackage(File file) throws Exception {
        try {
            InputStream is = new FileInputStream(file);
            List<PackageTypeMembers> pd = new ArrayList<PackageTypeMembers>();
            DocumentBuilder db =
                DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Element d = db.parse(is).getDocumentElement();
            for (Node c = d.getFirstChild(); c != null; c = c.getNextSibling()) {
                if (c instanceof Element) {
                    Element ce = (Element)c;
                    //
                    NodeList namee = ce.getElementsByTagName("name");
                    if (namee.getLength() == 0) {
                        // not
                        continue;
                    }
                    String name = namee.item(0).getTextContent();
                    NodeList m = ce.getElementsByTagName("members");
                    List<String> members = new ArrayList<String>();
                    for (int i = 0; i < m.getLength(); i++) {
                        Node mm = m.item(i);
                        members.add(mm.getTextContent());
                    }
                    PackageTypeMembers pdi = new PackageTypeMembers();
                    pdi.setName(name);
                    pdi.setMembers(members.toArray(new String[members.size()]));
                    pd.add(pdi);
                }
            }
            com.sforce.soap.metadata.Package r = new com.sforce.soap.metadata.Package();
            r.setTypes(pd.toArray(new PackageTypeMembers[pd.size()]));
            r.setVersion(API_VERSION + "");
            return r;
        } catch (ParserConfigurationException pce) {
            throw new Exception("Cannot create XML parser", pce);
        } catch (IOException ioe) {
            throw new Exception(ioe);
        } catch (SAXException se) {
            throw new Exception(se);
        }
    }


    /**
     * Helper method to copy from a readable channel to a writable channel,
     * using an in-memory buffer.
     */
    public static void copy(ReadableByteChannel src, WritableByteChannel dest)
        throws IOException
    {
        // Use an in-memory byte buffer
        ByteBuffer buffer = ByteBuffer.allocate(8092);
        while (src.read(buffer) != -1) {
            buffer.flip();
            while(buffer.hasRemaining()) {
                dest.write(buffer);
            }
            buffer.clear();
        }
    }


    public static void deployZip(MetadataConnection mc, File zipFile) throws Exception {
        byte zipBytes[] = readZipFile(zipFile);
        DeployOptions deployOptions = new DeployOptions();
        deployOptions.setPerformRetrieve(false);
        deployOptions.setRollbackOnError(true);
        AsyncResult asyncResult = mc.deploy(zipBytes, deployOptions);
        DeployResult result = waitForDeployCompletion(mc, asyncResult.getId());
        if (!result.isSuccess()) {
            printErrors(result, "Final list of failures:\n");
            throw new Exception("The files were not successfully deployed");
        }
        TextFileUtility.writetoLogFile("The file " + zipFile + " was successfully deployed\n", Main.logFileName);
    }


   /*
    * Read the zip file contents into a byte array.
    */
    private static byte[] readZipFile(File zipFile) throws Exception {
        byte[] result = null;
        // We assume here that you have a deploy.zip file.
        // See the retrieve sample for how to retrieve a zip file.
        if (!zipFile.exists() || !zipFile.isFile()) {
            throw new Exception("Cannot find the zip file for deploy() on path:"
                + zipFile.getAbsolutePath());
        }
 
        FileInputStream fileInputStream = new FileInputStream(zipFile);
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int bytesRead = 0;
            while (-1 != (bytesRead = fileInputStream.read(buffer))) {
                bos.write(buffer, 0, bytesRead);
            }
 
            result = bos.toByteArray();
        } finally {
            fileInputStream.close();
        }
        return result;
    }


    private static DeployResult waitForDeployCompletion(MetadataConnection mc, String asyncResultId) throws Exception {
        int poll = 0;
        long waitTimeMilliSecs = ONE_SECOND;
        DeployResult deployResult;
        boolean fetchDetails;
        do {
            Thread.sleep(waitTimeMilliSecs);
            // double the wait time for the next iteration
 
            waitTimeMilliSecs *= 2;
            if (poll++ > MAX_NUM_POLL_REQUESTS) {
                throw new Exception(
                    "Request timed out. If this is a large set of metadata components, " +
                    "ensure that MAX_NUM_POLL_REQUESTS is sufficient.");
            }
            // Fetch in-progress details once for every 3 polls
            fetchDetails = (poll % 3 == 0);
 
            deployResult = mc.checkDeployStatus(asyncResultId, fetchDetails);
            TextFileUtility.writetoLogFile("Status is: " + deployResult.getStatus(), Main.logFileName);
            if (!deployResult.isDone() && fetchDetails) {
                printErrors(deployResult, "Failures for deployment in progress:\n");
            }
        }
        while (!deployResult.isDone());
 
        if (!deployResult.isSuccess() && deployResult.getErrorStatusCode() != null) {
            throw new Exception(deployResult.getErrorStatusCode() + " msg: " +
                    deployResult.getErrorMessage());
        }
        
        if (!fetchDetails) {
            // Get the final result with details if we didn't do it in the last attempt.
            deployResult = mc.checkDeployStatus(asyncResultId, true);
        }
        
        return deployResult;
    }


    /*
    * Print out any errors, if any, related to the deploy.
    * @param result - DeployResult
    */
    private static void printErrors(DeployResult result, String messageHeader) {
        DeployDetails details = result.getDetails();
        StringBuilder stringBuilder = new StringBuilder();
        if (details != null) {
            DeployMessage[] componentFailures = details.getComponentFailures();
            for (DeployMessage failure : componentFailures) {
                String loc = "(" + failure.getLineNumber() + ", " + failure.getColumnNumber();
                if (loc.length() == 0 && !failure.getFileName().equals(failure.getFullName()))
                {
                    loc = "(" + failure.getFullName() + ")";
                }
                stringBuilder.append(failure.getFileName() + loc + ":" 
                    + failure.getProblem()).append('\n');
            }
            RunTestsResult rtr = details.getRunTestResult();
            if (rtr.getFailures() != null) {
                for (RunTestFailure failure : rtr.getFailures()) {
                    String n = (failure.getNamespace() == null ? "" :
                        (failure.getNamespace() + ".")) + failure.getName();
                    stringBuilder.append("Test failure, method: " + n + "." +
                            failure.getMethodName() + " -- " + failure.getMessage() + 
                            " stack " + failure.getStackTrace() + "\n\n");
                }
            }
            if (rtr.getCodeCoverageWarnings() != null) {
                for (CodeCoverageWarning ccw : rtr.getCodeCoverageWarnings()) {
                    stringBuilder.append("Code coverage issue");
                    if (ccw.getName() != null) {
                        String n = (ccw.getNamespace() == null ? "" :
                        (ccw.getNamespace() + ".")) + ccw.getName();
                        stringBuilder.append(", class: " + n);
                    }
                    stringBuilder.append(" -- " + ccw.getMessage() + "\n");
                }
            }
        }
        if (stringBuilder.length() > 0) {
            stringBuilder.insert(0, messageHeader);
            TextFileUtility.writetoLogFile(stringBuilder.toString(), Main.logFileName);
        }
    }


    public static BulkConnection getBulkConnection(PartnerConnection pc)
            throws ConnectionException, AsyncApiException {
        
        ConnectorConfig partnerConfig = pc.getConfig();
        // When PartnerConnection is instantiated, a login is implicitly
        // executed and, if successful,
        // a valid session is stored in the ConnectorConfig instance.
        // Use this key to initialize a BulkConnection:
        ConnectorConfig config = new ConnectorConfig();
        config.setSessionId(partnerConfig.getSessionId());
        // The endpoint for the Bulk API service is the same as for the normal
        // SOAP uri until the /Soap/ part. From here it's '/async/versionNumber'
        String soapEndpoint = partnerConfig.getServiceEndpoint();
        String apiVersion = "53.0";
        String restEndpoint = soapEndpoint.substring(0, soapEndpoint.indexOf("Soap/"))
            + "async/" + apiVersion;
        config.setRestEndpoint(restEndpoint);
        // This should only be false when doing debugging.
        config.setCompression(true);
        // Set this to true to see HTTP requests and responses on stdout
        config.setTraceMessage(false);
        BulkConnection connection = new BulkConnection(config);
        return connection;
    }


    /**
     * Create a new job using the Bulk API.
     * 
     * @param sobjectType
     *            The object type being loaded, such as "Account"
     * @param connection
     *            BulkConnection used to create the new job.
     * @return The JobInfo for the new job.
     * @throws AsyncApiException
     */
    public static JobInfo createJob(String sobjectType, BulkConnection connection, String operation)
          throws AsyncApiException {
        JobInfo job = new JobInfo();
        job.setObject(sobjectType);
        if(operation.equals("update")) {
            job.setOperation(OperationEnum.update);
        }
        else if(operation.equals("insert")) {
            job.setOperation(OperationEnum.insert);
        }
        job.setContentType(ContentType.CSV);
        job = connection.createJob(job);
        TextFileUtility.writetoLogFile(job.toString(), Main.logFileName);
        return job;
    }


    /**
     * Create and upload batches using a CSV file.
     * The file into the appropriate size batch files.
     * 
     * @param connection
     *            Connection to use for creating batches
     * @param jobInfo
     *            Job associated with new batches
     * @param csvFileName
     *            The source file for batch data
     */
    public static List<BatchInfo> createBatchesFromCSVFile(BulkConnection connection, JobInfo jobInfo, String csvFileName)
            throws IOException, AsyncApiException {
        List<BatchInfo> batchInfos = new ArrayList<BatchInfo>();
        BufferedReader rdr = new BufferedReader(
            new InputStreamReader(new FileInputStream(csvFileName))
        );
        // read the CSV header row
        byte[] headerBytes = (rdr.readLine() + "\n").getBytes("UTF-8");
        int headerBytesLength = headerBytes.length;
        File tmpFile = File.createTempFile("bulkAPIInsert", ".csv");

        // Split the CSV file into multiple batches
        try {
            FileOutputStream tmpOut = new FileOutputStream(tmpFile);
            int maxBytesPerBatch = 10000000; // 10 million bytes per batch
            int maxRowsPerBatch = 10000; // 10 thousand rows per batch
            int currentBytes = 0;
            int currentLines = 0;
            String nextLine;
            while ((nextLine = rdr.readLine()) != null) {
                byte[] bytes = (nextLine + "\n").getBytes("UTF-8");
                // Create a new batch when our batch size limit is reached
                if (currentBytes + bytes.length > maxBytesPerBatch
                  || currentLines > maxRowsPerBatch) {
                    createBatch(tmpOut, tmpFile, batchInfos, connection, jobInfo);
                    currentBytes = 0;
                    currentLines = 0;
                }
                if (currentBytes == 0) {
                    tmpOut = new FileOutputStream(tmpFile);
                    tmpOut.write(headerBytes);
                    currentBytes = headerBytesLength;
                    currentLines = 1;
                }
                tmpOut.write(bytes);
                currentBytes += bytes.length;
                currentLines++;
            }
            // Finished processing all rows
            // Create a final batch for any remaining data
            if (currentLines > 1) {
                createBatch(tmpOut, tmpFile, batchInfos, connection, jobInfo);
            }
        } finally {
            tmpFile.delete();
        }
        return batchInfos;
    }


    /**
     * Create a batch by uploading the contents of the file.
     * This closes the output stream.
     * 
     * @param tmpOut
     *            The output stream used to write the CSV data for a single batch.
     * @param tmpFile
     *            The file associated with the above stream.
     * @param batchInfos
     *            The batch info for the newly created batch is added to this list.
     * @param connection
     *            The BulkConnection used to create the new batch.
     * @param jobInfo
     *            The JobInfo associated with the new batch.
     */
    public static void createBatch(FileOutputStream tmpOut, File tmpFile,
      List<BatchInfo> batchInfos, BulkConnection connection, JobInfo jobInfo)
              throws IOException, AsyncApiException {
        tmpOut.flush();
        tmpOut.close();
        FileInputStream tmpInputStream = new FileInputStream(tmpFile);
        try {
            BatchInfo batchInfo =
              connection.createBatchFromStream(jobInfo, tmpInputStream);
            TextFileUtility.writetoLogFile(batchInfo.toString(), Main.logFileName);
            batchInfos.add(batchInfo);

        } finally {
            tmpInputStream.close();
        }
    }


    public static void closeJob(BulkConnection connection, String jobId)
          throws AsyncApiException {
        JobInfo job = new JobInfo();
        job.setId(jobId);
        job.setState(JobStateEnum.Closed);
        connection.updateJob(job);
    }


    /**
     * Wait for a job to complete by polling the Bulk API.
     * 
     * @param connection
     *            BulkConnection used to check results.
     * @param job
     *            The job awaiting completion.
     * @param batchInfoList
     *            List of batches for this job.
     * @throws AsyncApiException
     */
    public static void awaitCompletion(BulkConnection connection, JobInfo job, List<BatchInfo> batchInfoList)
            throws AsyncApiException {
        long sleepTime = 0L;
        Set<String> incomplete = new HashSet<String>();
        for (BatchInfo bi : batchInfoList) {
            incomplete.add(bi.getId());
        }
        while (!incomplete.isEmpty()) {
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {}
            TextFileUtility.writetoLogFile("Awaiting results..." + incomplete.size(), Main.logFileName);
            sleepTime = 10000L;
            BatchInfo[] statusList =
              connection.getBatchInfoList(job.getId()).getBatchInfo();
            for (BatchInfo b : statusList) {
                if (b.getState() == BatchStateEnum.Completed
                  || b.getState() == BatchStateEnum.Failed) {
                    if (incomplete.remove(b.getId())) {
                        TextFileUtility.writetoLogFile("BATCH STATUS:\n" + b, Main.logFileName);
                    }
                }
            }
        }
    }


    /**
     * Gets the results of the operation and checks for errors.
     */
    public static void checkResults(BulkConnection connection, JobInfo job, List<BatchInfo> batchInfoList)
            throws AsyncApiException, IOException {
        // batchInfoList was populated when batches were created and submitted
        for (BatchInfo b : batchInfoList) {
            try {
                InputStream inputStream = connection.getBatchResultStream(job.getId(), b.getId());
                InputStreamReader inputStreamReader = new InputStreamReader(new BOMInputStream(inputStream),StandardCharsets.UTF_8);
                CSVReader rdr = new CSVReader(inputStreamReader);
                String[] resultHeader = rdr.readNext();
                int resultCols = resultHeader.length;

                String[] row;
                while ((row = rdr.readNext()) != null) {
                    Map<String, String> resultInfo = new HashMap<String, String>();
                    for (int i = 0; i < resultCols; i++) {
                        resultInfo.put(resultHeader[i], row[i]);
                    }
                    boolean success = Boolean.valueOf(resultInfo.get("Success"));
                    boolean created = Boolean.valueOf(resultInfo.get("Created"));
                    String id = resultInfo.get("Id");
                    String error = resultInfo.get("Error");
                    if (success && created) {
                        TextFileUtility.writetoLogFile("Created row with id " + id, Main.logFileName);
                        
                    } else if (!success) {
                        TextFileUtility.writetoLogFile("Failed with error: " + error, Main.logFileName);
                    }
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
}