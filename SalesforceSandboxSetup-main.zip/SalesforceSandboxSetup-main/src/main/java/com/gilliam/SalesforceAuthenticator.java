package com.gilliam;

import com.sforce.soap.partner.*;
import com.sforce.soap.partner.LoginResult;
import com.sforce.soap.tooling.ToolingConnection;
import com.sforce.soap.metadata.*;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;


public class SalesforceAuthenticator {

    public static LoginResult lr;


    public static PartnerConnection auth() {

        try {

            ConnectorConfig config = new ConnectorConfig();
            String env = "";
            if(Main.sandboxChar.equals("D")) {
                env = "dev";
            }
            else if(Main.sandboxChar.equals("U")) {
                env = "uat";
            }
            else if(Main.sandboxChar.equals("S")) {
                env = "stage";
            }
            else {
                TextFileUtility.writetoLogFile("ERROR IN SALESFORCE AUTHENTICATION - INVALID SANDBOX CHAR", Main.logFileName);
                System.exit(0);
            }
                        
            config.setUsername(Main.defaultProps.getProperty(env + ".user"));
            config.setPassword(Main.defaultProps.getProperty(env + ".password") + Main.defaultProps.getProperty(env + ".token"));
            config.setAuthEndpoint(Main.defaultProps.getProperty(env + ".authEndpoint"));
            config.setServiceEndpoint(Main.defaultProps.getProperty(env + ".authEndpoint"));
            PartnerConnection partnerConnection = new PartnerConnection(config);

            // display some current settings
            System.out.println("Auth EndPoint: " + partnerConnection.getConfig().getAuthEndpoint());
            System.out.println("Service EndPoint: " + partnerConnection.getConfig().getServiceEndpoint());
            System.out.println("Username: " + partnerConnection.getConfig().getUsername());
            System.out.println("SessionId: " + partnerConnection.getConfig().getSessionId());

            return partnerConnection;
        }
        catch(ConnectionException e1) {
            e1.printStackTrace();
        }
        return null;
    }


    @SuppressWarnings("unused")
    public static MetadataConnection authMetadataApi(PartnerConnection pc) {

        String env = "";
        if(Main.sandboxChar.equals("D")) {
            env = "dev";
        }
        else if(Main.sandboxChar.equals("U")) {
            env = "uat";
        }
        else if(Main.sandboxChar.equals("S")) {
            env = "stage";
        }
        else {
            TextFileUtility.writetoLogFile("ERROR IN SALESFORCE AUTHENTICATION - INVALID SANDBOX CHAR", Main.logFileName);
            System.exit(0);
        }

        String username = Main.defaultProps.getProperty(env + ".user");
        String password = Main.defaultProps.getProperty(env + ".password") + Main.defaultProps.getProperty(env + ".token");
        try {
            LoginResult lr = pc.login(username, password);
            ConnectorConfig cc = new ConnectorConfig();
            cc.setUsername(username);
            cc.setPassword(password);
            cc.setSessionId(lr.getSessionId());
            cc.setServiceEndpoint(lr.getMetadataServerUrl());
            cc.setManualLogin(false);
            MetadataConnection connection = com.sforce.soap.metadata.Connector.newConnection(cc);
            return connection;
        }
        catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return null;
    }


    public static ToolingConnection authToolingApi(PartnerConnection pc) {
        try {
            ConnectorConfig toolingConfig = new ConnectorConfig();
            toolingConfig.setSessionId(pc.getConfig().getSessionId());
            toolingConfig.setServiceEndpoint(pc.getConfig().getServiceEndpoint().replace('u', 'T'));
            ToolingConnection toolingConnection = com.sforce.soap.tooling.Connector.newConnection(toolingConfig);
            return toolingConnection;
        }
        catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return null;
    }

}