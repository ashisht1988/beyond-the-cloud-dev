package com.gilliam;

import java.io.File;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.*;
import net.lingala.zip4j.ZipFile;  


public class ZipUtility {
    
    public static ZipFile zip (String targetPath, String destinationFilePath, String password) {
        try {
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(CompressionMethod.DEFLATE);
            parameters.setCompressionLevel(CompressionLevel.NORMAL);

            ZipFile zipFile = new ZipFile(destinationFilePath);

            if (password!=null && password.length() > 0) {
                parameters.setEncryptFiles(true);
                parameters.setEncryptionMethod(EncryptionMethod.AES);
                parameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);

                char[] passwordChars = new char[password.length()];
                for(int i = 0; i < password.length(); i++) {
                    passwordChars[i] = password.charAt(i);
                }
                zipFile.setPassword(passwordChars);
            }
               
            File targetFile = new File(targetPath);
            if (targetFile.isFile()) {
                zipFile.addFile(targetFile, parameters);
            } else if (targetFile.isDirectory()) {
                zipFile.addFolder(targetFile, parameters);
            } else {
                //neither file nor directory
            }
            return zipFile;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
        
    public static void unzip(String targetZipFilePath, String destinationFolderPath, String password) {
        try {
            ZipFile zipFile = new ZipFile(targetZipFilePath);
            if (zipFile.isEncrypted()) {
                char[] passwordChars = new char[password.length()];
                for(int i = 0; i < password.length(); i++) {
                    passwordChars[i] = password.charAt(i);
                }
                zipFile.setPassword(passwordChars);
            }
            zipFile.extractAll(destinationFolderPath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    /**/ /// for test
    public static void main(String[] args) {
        
        String targetPath = "target\\file\\or\\folder\\path";
        String zipFilePath = "zip\\file\\Path"; 
        String unzippedFolderPath = "destination\\folder\\path";
        String password = "your_password"; // keep it EMPTY<""> for applying no password protection
            
        ZipUtility.zip(targetPath, zipFilePath, password);
        ZipUtility.unzip(zipFilePath, unzippedFolderPath, password);
    }/**/
}
