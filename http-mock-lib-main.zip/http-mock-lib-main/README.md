<div align="center">
  <a href="https://apexfluently.beyondthecloud.dev/libraries/http-mock-lib.html">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="./website/public/logo.png">
      <img alt="HTTP Mock Lib logo" src="./website/public/logo.png" height="98">
    </picture>
  </a>
  <h1>HTTP Mock Lib</h1>

<a href="https://beyondthecloud.dev"><img alt="Beyond The Cloud logo" src="https://img.shields.io/badge/MADE_BY_BEYOND_THE_CLOUD-555?style=for-the-badge"></a>

<img alt="API version" src="https://img.shields.io/badge/api-v65.0-blue?style=for-the-badge">
<a href="https://github.com/beyond-the-cloud-dev/soql-lib/blob/main/LICENSE"><img alt="License" src="https://img.shields.io/badge/license-mit-green?style=for-the-badge"></a>
<img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/beyond-the-cloud-dev/http-mock-lib?style=for-the-badge&logo=github&color=blue">
<img alt="GitHub Release" src="https://img.shields.io/github/v/release/beyond-the-cloud-dev/http-mock-lib?display_name=tag&style=for-the-badge&color=blue">
</div>

# Getting Started

HTTP Mock inspired by Robert Sösemann’s [Apex Http Mock](https://github.com/rsoesemann/apex-httpmock).

HTTP Mock Lib is part of [Apex Fluently](https://apexfluently.beyondthecloud.dev/), a suite of production-ready Salesforce libraries by Beyond the Cloud.

❌❌❌

```java
@isTest
global class MockHttpResponseGenerator implements HttpCalloutMock {
    global HTTPResponse respond(HTTPRequest req) {
        HttpResponse res = new HttpResponse();
        res.setHeader('Content-Type', 'application/json');
        res.setBody('{"example":"test"}');
        res.setStatusCode(200);
        return res;
    }
}

Test.setMock(HttpCalloutMock.class, new MockHttpResponseGenerator());
```

✅✅✅

```java
new HttpMock()
  .whenGetOn('/api/v1/authorize').body('{"example":"test"}').statusCodeOk()
  .mock();
```

## Example

```java
@IsTest
private class MyTest {
  @IsTest
  static void calloutTest() {
    new HttpMock()
      .whenGetOn('/api/v1/authorize').body('{ "token": "aZ3Xb7Qk" }').statusCodeOk()
      .whenPostOn('/api/v1/create').body('{ "success": true, "message": null }').statusCodeOk()
      .mock();

    Test.startTest();
    new CalloutService().makeCallout();
    Test.stopTest();

    // Asserts
    Assert.areEqual(..., ...);
  }
}
```

## API

```java
public interface HttpMockLib {
    HttpMock whenGetOn(String endpointToMock);
    HttpMock whenPostOn(String endpointToMock);
    HttpMock whenPutOn(String endpointToMock);
    HttpMock whenPatchOn(String endpointToMock);
    HttpMock whenDeleteOn(String endpointToMock);
    HttpMock whenTraceOn(String endpointToMock);
    HttpMock whenHeadOn(String endpointToMock);
    // Body
    HttpMock body(Object body);
    HttpMock body(String body);
    HttpMock body(Blob body);
    // Content-Type
    HttpMock contentTypePlainText(); // text/plain
    HttpMock contentTypeHtml(); // text/html
    HttpMock contentTypeCsv(); // text/csv
    HttpMock contentTypeJson(); // application/json
    HttpMock contentTypeXml(); // application/xml
    HttpMock contentTypePdf(); // application/pdf
    HttpMock contentTypeFormUrlencoded(); // application/x-www-form-urlencoded
    HttpMock contentType(String contentType);
    // Status Code
    HttpMock statusCodeOk(); // 200
    HttpMock statusCodeCreated(); // 201
    HttpMock statusCodeAccepted(); // 202
    HttpMock statusCodeNoContent(); // 204
    HttpMock statusCodeBadRequest(); // 400
    HttpMock statusCodeUnauthorized(); // 401
    HttpMock statusCodeForbidden(); // 403
    HttpMock statusCodeNotFound(); // 404
    HttpMock statusCodeMethodNotAllowed(); // 405
    HttpMock statusCodeInternalServerError(); // 500
    HttpMock statusCodeNotImplemented(); // 501
    HttpMock statusCodeBadGateway(); // 502
    HttpMock statusCodeServiceUnavailable(); // 503
    HttpMock statusCodeGatewayTimeout(); // 504
    HttpMock statusCode(Integer statusCode);
    // Headers
    HttpMock header(String key, String value);
    // Mock
    void mock();
}
```

## Documentation

Visit the [documentation](https://httpmock.beyondthecloud.dev/) to view the full documentation.

## Contributors

<a href="https://github.com/beyond-the-cloud-dev/http-mock-lib/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=beyond-the-cloud-dev/http-mock-lib" />
</a>

## License notes:

- For proper license management each repository should contain LICENSE file similar to this one.
- each original class should contain copyright mark: © Copyright 2025, Beyond The Cloud Sp. z o.o. (BeyondTheCloud.Dev)
