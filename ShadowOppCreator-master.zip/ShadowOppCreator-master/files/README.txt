The files directory is where the Shadow Opportunity file to be uploaded must be placed.  
That file should have the name:  ShadowOpportunity.csv