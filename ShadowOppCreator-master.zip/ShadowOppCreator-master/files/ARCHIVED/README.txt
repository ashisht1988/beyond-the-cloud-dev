The files/ARCHIVED directory is a location to store Shadow Opportunity files from previous runs.  
Please keep all such CSVs from your previous runs in this directory, renamed with a date string
at the end of the original "ShadowOpportunity.csv" name, like:  ShadowOpportunity_mmddyy.csv