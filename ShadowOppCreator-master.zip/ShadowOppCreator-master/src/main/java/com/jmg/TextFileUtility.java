package com.jmg;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;


public class TextFileUtility {

    public static void createLogFile(String fileNameString) {
        try {
            File myObj = new File("logs/" + fileNameString + ".txt");
            FileWriter writer = new FileWriter(myObj);
            writer.write("START LOG FILE - " + LocalDateTime.now() + "\r\n");
            writer.close();
          } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }        
    }

    public static void writetoLogFile(String logFileEntry, String fileNameString) {
        try {
            FileWriter myWriter = new FileWriter("logs/" + fileNameString + ".txt", true);
            myWriter.write(logFileEntry+"\r\n");
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
          } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }        
    }
    
}