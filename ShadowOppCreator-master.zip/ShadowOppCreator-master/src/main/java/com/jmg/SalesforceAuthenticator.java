package com.jmg;

import com.sforce.soap.partner.*;
import com.sforce.soap.partner.LoginResult;
import com.sforce.soap.tooling.ToolingConnection;
import com.sforce.soap.metadata.*;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;


public class SalesforceAuthenticator {

    public static LoginResult lr;


    public static PartnerConnection auth() {

        try {

            ConnectorConfig config = new ConnectorConfig();
            //config.setUsername(username);
            //config.setPassword(password);
            //config.setAuthEndpoint(authEndpoint);
            //config.setServiceEndpoint(authEndpoint);
                        
            config.setUsername(ShadowOppCreator.defaultProps.getProperty("force.user"));
            config.setPassword(ShadowOppCreator.defaultProps.getProperty("force.password") + ShadowOppCreator.defaultProps.getProperty("force.token"));
            config.setAuthEndpoint(ShadowOppCreator.defaultProps.getProperty("force.authEndpoint"));
            config.setServiceEndpoint(ShadowOppCreator.defaultProps.getProperty("force.authEndpoint"));
            PartnerConnection partnerConnection = new PartnerConnection(config);

            // display some current settings
            System.out.println("Auth EndPoint: " + partnerConnection.getConfig().getAuthEndpoint());
            System.out.println("Service EndPoint: " + partnerConnection.getConfig().getServiceEndpoint());
            System.out.println("Username: " + partnerConnection.getConfig().getUsername());
            System.out.println("SessionId: " + partnerConnection.getConfig().getSessionId());

            return partnerConnection;
        }
        catch(ConnectionException e1) {
            e1.printStackTrace();
        }
        return null;
    }

    @SuppressWarnings("unused")
    public static MetadataConnection authMetadataApi(PartnerConnection pc) {
        try {
            LoginResult lr = pc.login(ShadowOppCreator.defaultProps.getProperty("force.user"), ShadowOppCreator.defaultProps.getProperty("force.password") + ShadowOppCreator.defaultProps.getProperty("force.token"));
            ConnectorConfig cc = new ConnectorConfig();
            cc.setUsername(ShadowOppCreator.defaultProps.getProperty("force.user"));
            cc.setPassword(ShadowOppCreator.defaultProps.getProperty("force.password") + ShadowOppCreator.defaultProps.getProperty("force.token"));
            cc.setSessionId(pc.getConfig().getSessionId());
            cc.setServiceEndpoint(pc.getConfig().getServiceEndpoint());
            cc.setManualLogin(false);
            MetadataConnection connection = com.sforce.soap.metadata.Connector.newConnection(cc);
            return connection;
        }
        catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return null;
    }


    public static ToolingConnection authToolingApi(PartnerConnection pc) {
        try {
            ConnectorConfig toolingConfig = new ConnectorConfig();
            toolingConfig.setSessionId(pc.getConfig().getSessionId());
            toolingConfig.setServiceEndpoint(pc.getConfig().getServiceEndpoint().replace('u', 'T'));
            ToolingConnection toolingConnection = com.sforce.soap.tooling.Connector.newConnection(toolingConfig);
            return toolingConnection;
        }
        catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return null;
    }

}
