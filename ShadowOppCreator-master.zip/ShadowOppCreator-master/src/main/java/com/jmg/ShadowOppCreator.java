package com.jmg;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.sforce.async.BatchInfo;
import com.sforce.async.BulkConnection;
import com.sforce.async.JobInfo;
import com.sforce.soap.metadata.MetadataConnection;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.soap.tooling.ToolingConnection;
import com.sforce.ws.ConnectionException;


public class ShadowOppCreator {
    static Properties defaultProps;
    static Properties appProperties;
    public static PartnerConnection pc = null;
    public static MetadataConnection metadataConnection;
    public static ToolingConnection tc;
    public static String runDateTime;
    public static String verboseLogFileName;
    public static String errorLogFileName;
    public static String totalBookingValueLogFileName;
    public static String secondBookingValueLogFileName;

    public static String shadowOppFile = "files/ShadowOpportunity.csv";
    public static Integer startRow;
    public static String crmIdToProcess;
    public static List<Map<String,String>> processOnlyTheseRows;

    public static void main( String[] args )
    {       
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH_mmss");  
        LocalDateTime now = LocalDateTime.now();
        runDateTime = dtf.format(now);
        verboseLogFileName = "log_" + runDateTime;
        errorLogFileName = "error_" + runDateTime;
        totalBookingValueLogFileName = "tbv_" + runDateTime;
        secondBookingValueLogFileName = "sbv_" + runDateTime;
        
        // *** START - JOB PARAMETERS ***
        startRow = 2;
        crmIdToProcess = ""; // If populated, the job will run for ONLY this ASG Opportunity ID
        String processOnlyTheseFile = "files/ProcessOnlyThese.csv"; // If there are ASG CRM IDs in this file, the job will run only for those.
       // *** END - JOB PARAMETERS ***
        
        processOnlyTheseRows = CsvUtility.getCsvRowsHeaderAware(processOnlyTheseFile);
        
        if(processOnlyTheseRows.size()>0 && !crmIdToProcess.equals("")) {
            System.out.println("crmIdToProcess IS NOT BLANK AND processOnlyTheseRows.size() > 0 - EXITING APPLICATION");
            System.exit(0);
        }


        TextFileUtility.createLogFile(verboseLogFileName);
        TextFileUtility.createLogFile(errorLogFileName);
        TextFileUtility.createLogFile(totalBookingValueLogFileName);
        TextFileUtility.createLogFile(secondBookingValueLogFileName);
        setUpProperties();

        pc = SalesforceAuthenticator.auth();

        // Set up SKU info...
        Set<String> skuIdSet = new HashSet<String>();
        Map<String, String> skuNameToIdMap = new HashMap<String, String>();
        String querySkus = "SELECT Id, Name FROM Product2 WHERE Brand__r.Name = 'Rocket ASG' AND ProductCode LIKE 'ACQ-%'";
        List<SObject> querySkusResults = SalesforceUtility.querySf(pc, querySkus);
        if(querySkusResults.size()>0 && querySkusResults.get(0)!=null) {
            for(SObject prod : querySkusResults) {
                skuIdSet.add(prod.getId());
                skuNameToIdMap.put(prod.getSObjectField("Name").toString(), prod.getId());
            }
        }
        else {
            // Stop the app if no SKUs found; something has gone wrong.
            TextFileUtility.writetoLogFile("NO SKUS FOUND!  EXITING APPLICATION.", verboseLogFileName);
            return;
        }

        String cpsSkuId = "";
        String cpspSkuId = "";
        String cypPLSkuId = "";
        String cypMSkuId = "";
        String cypTLSkuId = "";
        String diPLSkuId = "";
        String diMSkuId = "";
        String diTLSkuId = "";
        String dipsSkuId = "";
        String dipspSkuId = "";
        String mobiusPLSkuId = "";
        String mobiusMSkuId = "";
        String mobiusTLSkuId = "";
        String othPLSkuId = "";
        String othMSkuId = "";
        String othTLSkuId = "";
        String spsSkuId = "";
        String spspSkuId = "";
        String tmonPLSkuId = "";
        String tmonMSkuId = "";
        String tmonTLSkuId = "";
        String zekePLSkuId = "";
        String zekeMSkuId = "";
        String zekeTLSkuId = "";
        String zenaPLSkuId = "";
        String zenaMSkuId = "";
        String zenaTLSkuId = "";

        for(Map.Entry<String, String> entry : skuNameToIdMap.entrySet()) {
            if(entry.getKey().equals("Content Professional Services")) {
                cpsSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Content Professional Services Package")) {
                cpspSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Cypress - Maintenance")) {
                cypMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Cypress - Perpetual License")) {
                cypPLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Cypress - Term License")) {
                cypTLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Data Intelligence - Maintenance")) {
                diMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Data Intelligence - Perpetual License")) {
                diPLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Data Intelligence - Term License")) {
                diTLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Data Intelligence Professional Services")) {
                dipsSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Data Intelligence Professional Services Package")) {
                dipspSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Mobius - Maintenance")) {
                mobiusMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Mobius - Perpetual License")) {
                mobiusPLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Mobius - Term License")) {
                mobiusTLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Other Systems - Maintenance")) {
                othMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Other Systems - Perpetual License")) {
                othPLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Other Systems - Term License")) {
                othTLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Systems Professional Services")) {
                spsSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Systems Professional Services Package")) {
                spspSkuId = entry.getValue();
            }
            if(entry.getKey().equals("TMON - Maintenance")) {
                tmonMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("TMON - Perpetual License")) {
                tmonPLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("TMON - Term License")) {
                tmonTLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Zeke - Maintenance")) {
                zekeMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Zeke - Perpetual License")) {
                zekePLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Zeke - Term License")) {
                zekeTLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Zena - Maintenance")) {
                zenaMSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Zena - Perpetual License")) {
                zenaPLSkuId = entry.getValue();
            }
            if(entry.getKey().equals("Zena - Term License")) {
                zenaTLSkuId = entry.getValue();
            }
        }

        // Get Pricebook Entries...
        Map<String,Map<String, String>> pbeMap = new HashMap<String, Map<String, String>>();
        String queryPbes = "SELECT Id, CurrencyIsoCode, Product2Id FROM PricebookEntry WHERE Product2.Brand__r.Name = 'Rocket ASG' AND ProductCode LIKE 'ACQ-%' AND Pricebook2.Name = 'CPQ Pricebook'";
        List<SObject> queryPbesResults = SalesforceUtility.querySf(pc, queryPbes);
        if(queryPbesResults.size()>0) {
            for(String prodId : skuIdSet) {
                Map<String, String> currencyToPbeId = new HashMap<String, String>();
                for(SObject sObj : queryPbesResults) {
                    if(prodId.equals(sObj.getSObjectField("Product2Id"))) {
                        currencyToPbeId.put(sObj.getSObjectField("CurrencyIsoCode").toString(), sObj.getId());
                    }
                }
                pbeMap.put(prodId,currencyToPbeId);
            }
        }
        else {
            // If no PBEs, exit app; there's a problem
            TextFileUtility.writetoLogFile("NO PRICEBOOK ENTRIES. EXITING APPLICATION.", verboseLogFileName);
            return;
        }

        List<Map<String,String>> tempOppRows = CsvUtility.getCsvRowsHeaderAware(shadowOppFile);
        List<Map<String,String>> oppRows = CsvUtility.getCsvRowsHeaderAware(shadowOppFile);
        if(crmIdToProcess.equals("") && processOnlyTheseRows.size()==0) {
            System.out.println("BLOCK 1");
            for(int i=tempOppRows.size()-1; i>=0; i--) {
                if(i<=startRow-3) {
                    System.out.println("INDEX " + i + ": " + oppRows.get(i).get("ASG Opportunity ID").toString());
                    oppRows.remove(i);
                }
            }
        }
        else if(!crmIdToProcess.equals("")) {
            System.out.println("BLOCK 2");
            for(int i=tempOppRows.size()-1; i>=0; i--) {
                System.out.println("ASG Opportunity ID: " + tempOppRows.get(i).get("ASG Opportunity ID").toString() + " | crmIdToProcess: " + crmIdToProcess);
                if(!tempOppRows.get(i).get("ASG Opportunity ID").toString().equals(crmIdToProcess)) {
                    // System.out.println("REMOVING: " + tempOppRows.get(i).get("ASG Opportunity ID").toString()); // FOR DEBUGGING
                    oppRows.remove(i);
                }
            }
            /* 
            //FOR DEBUGGING
            for(int i = 0; i<oppRows.size(); i++) {
                System.out.println("A ROW STILL IN SHEET: " + oppRows.get(i).get("ASG Opportunity ID").toString());
            }
            */
        }
        else if(processOnlyTheseRows.size()>0) {
            System.out.println("BLOCK 3");
            List<String> processOnlyTheseRowsList = new ArrayList<String>();
            for(Map<String,String> row : processOnlyTheseRows) {
                processOnlyTheseRowsList.add(row.get("AsgCrmId"));
            }
            
            for(int i=tempOppRows.size()-1; i>=0; i--) {
                System.out.println("ASG Opportunity ID: " + tempOppRows.get(i).get("ASG Opportunity ID").toString() + " | crmIdToProcess: " + crmIdToProcess);
                Boolean asgOppIdInProcessOnlyList = false;
                if(processOnlyTheseRowsList.contains(tempOppRows.get(i).get("ASG Opportunity ID").toString())) {
                    asgOppIdInProcessOnlyList = true;
                }
                if(!asgOppIdInProcessOnlyList) {
                     System.out.println("REMOVING: " + tempOppRows.get(i).get("ASG Opportunity ID").toString()); // FOR DEBUGGING
                    oppRows.remove(i);
                }
            }
         
            //FOR DEBUGGING
            for(int i = 0; i<oppRows.size(); i++) {
                System.out.println("A ROW STILL IN SHEET: " + oppRows.get(i).get("ASG Opportunity ID").toString());
            }
      
        }
        else {
            System.out.println("EXITING WITHOUT PRUNING oppRows");
            System.exit(0); 
        }
        System.out.println("oppRows.size(): " + oppRows.size());

        for(Map<String, String> row : oppRows) {
            // Opp variables
            String oppName = "";
            String asgOppId = "";
            String asgCrmSiteId = "";
            String thisAccountId = "";
            String asgCrmPartnerSiteId = "";
            String thePartnerAccountId = "";
            String salesRepRocketEmail = "";
            String salesRepUserId = "";
            String directIndirect = "";
            String supportTerm = "";
            String rocketContractingEntity = "";
            String stage = "";
            String closeDateString = "";
            Date closeDate = null;
            String currency = "";
            String recordTypeId = "";

            // Line Item variables
            String cps_SalesPrice = "";
            String cps_Quantity = "";
            String cps_LineDesc = "";
            String cpsp_SalesPrice = "";
            String cpsp_Quantity = "";
            String cpsp_LineDesc = "";
            String cypPL_SalesPrice = "";
            String cypPL_Quantity = "";
            String cypPL_LineDesc = "";
            String cypM_SalesPrice = "";
            String cypM_Quantity = "";
            String cypM_LineDesc = "";
            String cypTL_SalesPrice = "";
            String cypTL_Quantity = "";
            String cypTL_LineDesc = "";
            String diPL_SalesPrice = "";
            String diPL_Quantity = "";
            String diPL_LineDesc = "";
            String diM_SalesPrice = "";
            String diM_Quantity = "";
            String diM_LineDesc = "";
            String diTL_SalesPrice = "";
            String diTL_Quantity = "";
            String diTL_LineDesc = "";
            String dips_SalesPrice = "";
            String dips_Quantity = "";
            String dips_LineDesc = "";
            String dipsp_SalesPrice = "";
            String dipsp_Quantity = "";
            String dipsp_LineDesc = "";
            String mobiusPL_SalesPrice = "";
            String mobiusPL_Quantity = "";
            String mobiusPL_LineDesc = "";
            String mobiusM_SalesPrice = "";
            String mobiusM_Quantity = "";
            String mobiusM_LineDesc = "";
            String mobiusTL_SalesPrice = "";
            String mobiusTL_Quantity = "";
            String mobiusTL_LineDesc = "";
            String othPL_SalesPrice = "";
            String othPL_Quantity = "";
            String othPL_LineDesc = "";
            String othM_SalesPrice = "";
            String othM_Quantity = "";
            String othM_LineDesc = "";
            String othTL_SalesPrice = "";
            String othTL_Quantity = "";
            String othTL_LineDesc = "";
            String sps_SalesPrice = "";
            String sps_Quantity = "";
            String sps_LineDesc = "";
            String spsp_SalesPrice = "";
            String spsp_Quantity = "";
            String spsp_LineDesc = "";
            String tmonPL_SalesPrice = "";
            String tmonPL_Quantity = "";
            String tmonPL_LineDesc = "";
            String tmonM_SalesPrice = "";
            String tmonM_Quantity = "";
            String tmonM_LineDesc = "";
            String tmonTL_SalesPrice = "";
            String tmonTL_Quantity = "";
            String tmonTL_LineDesc = "";
            String zekePL_SalesPrice = "";
            String zekePL_Quantity = "";
            String zekePL_LineDesc = "";
            String zekeM_SalesPrice = "";
            String zekeM_Quantity = "";
            String zekeM_LineDesc = "";
            String zekeTL_SalesPrice = "";
            String zekeTL_Quantity = "";
            String zekeTL_LineDesc = "";
            String zenaPL_SalesPrice = "";
            String zenaPL_Quantity = "";
            String zenaPL_LineDesc = "";
            String zenaM_SalesPrice = "";
            String zenaM_Quantity = "";
            String zenaM_LineDesc = "";
            String zenaTL_SalesPrice = "";
            String zenaTL_Quantity = "";
            String zenaTL_LineDesc = "";
            
            // Set Opportunity variables
            if(row.get("Opportunity Name")!=null && !row.get("Opportunity Name").equals("")) {
                oppName = row.get("Opportunity Name");
            }
            if(row.get("ASG Opportunity ID")!=null && !row.get("ASG Opportunity ID").equals("")) {
                asgOppId = row.get("ASG Opportunity ID");
            }
            else {
                continue;
            }
            TextFileUtility.writetoLogFile("### START ASG OPP: " + asgOppId + " ###", verboseLogFileName);
            if(row.get("ASG CRM Account SITE ID")!=null && !row.get("ASG CRM Account SITE ID").equals("")) {
                asgCrmSiteId = row.get("ASG CRM Account SITE ID");
            }
            if(row.get("Partner Site ID")!=null && !row.get("Partner Site ID").equals("")) {
                asgCrmPartnerSiteId = row.get("Partner Site ID");
            }
            if(row.get("Sales Rep Rocket Email")!=null && !row.get("Sales Rep Rocket Email").equals("")) {
                salesRepRocketEmail = row.get("Sales Rep Rocket Email");
            }
            if(row.get("Direct/Indirect")!=null && !row.get("Direct/Indirect").equals("")) {
                directIndirect = row.get("Direct/Indirect");
            }
            if(row.get("Support Term (Acquisition Billing Period)")!=null && !row.get("Support Term (Acquisition Billing Period)").equals("")) {
                supportTerm = row.get("Support Term (Acquisition Billing Period)");
            }
            if(row.get("Rocket Contracting Entity")!=null && !row.get("Rocket Contracting Entity").equals("")) {
                rocketContractingEntity = row.get("Rocket Contracting Entity");
            }
            if(row.get("Stage")!=null && !row.get("Stage").equals("")) {
                stage = row.get("Stage");
            }
            if(row.get("Close Date")!=null && !row.get("Close Date").equals("")) {
                closeDateString = row.get("Close Date");
                try {
                    closeDate = new SimpleDateFormat("MM/dd/yyyy").parse(closeDateString);
                }
                catch(Exception e) {
                    e.printStackTrace();
                    TextFileUtility.writetoLogFile("CLOSE DATE FORMATTING FAILED!", verboseLogFileName);
                }
            }
            if(row.get("Currency")!=null && !row.get("Currency").equals("")) {
                currency = row.get("Currency").substring(0, 3);
            }

            // Query out Account ID for the SITE_ID.
            String queryAcqInfo = "SELECT Id, Account__c FROM Acquisition_Info__c WHERE Acquisition_Name__c = 'ASG' AND Source_System__c = 'ASG CRM' AND Source_System_Field__c = 'SITE_ID' AND (Source_System_Id__c = '" + row.get("ASG CRM Account SITE ID") + "' OR Source_System_Id__c = '" + row.get("ASG CRM Account SITE ID") + "-End-User')";
            List<SObject> queryAcqInfoResults = SalesforceUtility.querySf(pc, queryAcqInfo);
            if(queryAcqInfoResults.size()>1) {
                TextFileUtility.writetoLogFile("WARNING: Row not processed due to multiple Account matches (Slash Accounts/Partner/End User) ASG CRM Account ID: " + asgCrmSiteId, verboseLogFileName);
                TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | WARNING: Row not processed due to multiple Account matches (Slash Accounts/Partner/End User) ASG CRM Account ID: " + asgCrmSiteId, errorLogFileName);
                continue;
            }
            else if(queryAcqInfoResults.size()>0 && queryAcqInfoResults.get(0)!=null && !queryAcqInfoResults.get(0).getSObjectField("Account__c").equals("")) {
                thisAccountId = queryAcqInfoResults.get(0).getSObjectField("Account__c").toString();
            }
            else {
                // If we DO NOT find an Account ID for the SITE_ID, log that the record was not handled due to missing Account
                TextFileUtility.writetoLogFile("WARNING: Row not processed due to missing Account, ASG CRM Account ID: " + asgCrmSiteId, verboseLogFileName);
                TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | WARNING: Row not processed due to missing Account, ASG CRM Account ID: " + asgCrmSiteId, errorLogFileName);
                continue;
            }

            // Query out Account ID for the PARTNER Account's SITE_ID.
            if(asgCrmPartnerSiteId!=null && !asgCrmPartnerSiteId.equals("")) {
                String queryAcqInfoForPartner = "SELECT Id, Account__c FROM Acquisition_Info__c WHERE Acquisition_Name__c = 'ASG' AND Source_System__c = 'ASG CRM' AND Source_System_Field__c = 'SITE_ID' AND (Source_System_Id__c = '" + asgCrmPartnerSiteId + "' OR Source_System_Id__c = '" + asgCrmPartnerSiteId + "-Partner') LIMIT 1";
                List<SObject> queryAcqInfoForPartnerResults = SalesforceUtility.querySf(pc, queryAcqInfoForPartner);
                if(queryAcqInfoForPartnerResults.size()>0 && queryAcqInfoForPartnerResults.get(0)!=null && !queryAcqInfoForPartnerResults.get(0).getSObjectField("Account__c").equals("")) {
                    thePartnerAccountId = queryAcqInfoForPartnerResults.get(0).getSObjectField("Account__c").toString();
                }
                else {
                    // If we DO NOT find an Account ID for the PARTNER Account SITE_ID, just log that, and continue on.
                    TextFileUtility.writetoLogFile("WARNING: Did not find the Partner Account for " + asgCrmSiteId + ". Partner SITE_ID: " + asgCrmPartnerSiteId, verboseLogFileName);
                    TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | WARNING: Did not find the Partner Account for " + asgCrmSiteId + ". Partner SITE_ID: " + asgCrmPartnerSiteId, errorLogFileName);
                }
            }
            else {
                TextFileUtility.writetoLogFile("Partner Site ID was null or blank.", verboseLogFileName);
            }

            // Query out User ID with Email Address
            String queryUser = "SELECT Id FROM User WHERE Email = '" + salesRepRocketEmail + "' AND UserType = 'Standard' AND IsActive = true LIMIT 1";
            List<SObject> queryUserResults = SalesforceUtility.querySf(pc, queryUser);
            if(queryUserResults.size()>0 && queryUserResults.get(0)!=null) {
                salesRepUserId = queryUserResults.get(0).getId();
            }
            else {
                TextFileUtility.writetoLogFile("USER NOT FOUND", verboseLogFileName);
            }

            // Query out RecordTypeId for Opportunity's Acquisition Opportunity Record Type.
            String queryRecType = "SELECT Id FROM RecordType WHERE SobjectType = 'Opportunity' AND DeveloperName = 'Acquisition_Opportunity' LIMIT 1";
            List<SObject> queryRecTypeResults = SalesforceUtility.querySf(pc, queryRecType);
            if(queryRecTypeResults.size()>0 && queryRecTypeResults.get(0)!=null && !queryRecTypeResults.get(0).getSObjectField("Id").equals("")) {
                recordTypeId = queryRecTypeResults.get(0).getId();
            }
            
            
            // Set Line Item variables
            if(row.get("Content Professional Services -Sales Price")!=null && !row.get("Content Professional Services -Sales Price").equals("")) {
                cps_SalesPrice = row.get("Content Professional Services -Sales Price");
            }
            if(row.get("Content Professional Services - Quantity")!=null && !row.get("Content Professional Services - Quantity").equals("")) {
                cps_Quantity = row.get("Content Professional Services - Quantity");
            }
            if(row.get("Content Professional Services - Line Description")!=null && !row.get("Content Professional Services - Line Description").equals("")) {
                cps_LineDesc = row.get("Content Professional Services - Line Description");
            }
            if(row.get("Content Professional Services Package - Sales Price")!=null && !row.get("Content Professional Services Package - Sales Price").equals("")) {
                cpsp_SalesPrice = row.get("Content Professional Services Package - Sales Price");
            }
            if(row.get("Content Professional Services Package - Quantity")!=null && !row.get("Content Professional Services Package - Quantity").equals("")) {
                cpsp_Quantity = row.get("Content Professional Services Package - Quantity");
            }
            if(row.get("Content Professional Services Package - Line Description")!=null && !row.get("Content Professional Services Package - Line Description").equals("")) {
                cpsp_LineDesc = row.get("Content Professional Services Package - Line Description");
            }
            if(row.get("Cypress Perpetual License - Sales Price")!=null && !row.get("Cypress Perpetual License - Sales Price").equals("")) {
                cypPL_SalesPrice = row.get("Cypress Perpetual License - Sales Price");
            }
            if(row.get("Cypress - Perpetual License - Quantity")!=null && !row.get("Cypress - Perpetual License - Quantity").equals("")) {
                cypPL_Quantity = row.get("Cypress - Perpetual License - Quantity");
            }
            if(row.get("Cypress - Perpetual License - Line Description")!=null && !row.get("Cypress - Perpetual License - Line Description").equals("")) {
                cypPL_LineDesc = row.get("Cypress - Perpetual License - Line Description");
            }
            if(row.get("Cypress - Maintenance - Sales Price")!=null && !row.get("Cypress - Maintenance - Sales Price").equals("")) {
                cypM_SalesPrice = row.get("Cypress - Maintenance - Sales Price");
            }
            if(row.get("Cypress - Maintenance - Quantity")!=null && !row.get("Cypress - Maintenance - Quantity").equals("")) {
                cypM_Quantity = row.get("Cypress - Maintenance - Quantity");
            }
            if(row.get("Cypress - Maintenance - Line Description")!=null && !row.get("Cypress - Maintenance - Line Description").equals("")) {
                cypM_LineDesc = row.get("Cypress - Maintenance - Line Description");
            }
            if(row.get("Cypress - Term License - Sales Price")!=null && !row.get("Cypress - Term License - Sales Price").equals("")) {
                cypTL_SalesPrice = row.get("Cypress - Term License - Sales Price");
            }
            if(row.get("Cypress - Term License - Quantity")!=null && !row.get("Cypress - Term License - Quantity").equals("")) {
                cypTL_Quantity = row.get("Cypress - Term License - Quantity");
            }
            if(row.get("Cypress - Term License - Line Description")!=null && !row.get("Cypress - Term License - Line Description").equals("")) {
                cypTL_LineDesc = row.get("Cypress - Term License - Line Description");
            }
            if(row.get("Data Intelligence - Perpetual License - Sales Price")!=null && !row.get("Data Intelligence - Perpetual License - Sales Price").equals("")) {
                diPL_SalesPrice = row.get("Data Intelligence - Perpetual License - Sales Price");
            }
            if(row.get("Data Intelligence - Perpetual License - Quantity")!=null && !row.get("Data Intelligence - Perpetual License - Quantity").equals("")) {
                diPL_Quantity = row.get("Data Intelligence - Perpetual License - Quantity");
            }
            if(row.get("Data Intelligence - Perpetual License - Line Description")!=null && !row.get("Data Intelligence - Perpetual License - Line Description").equals("")) {
                diPL_LineDesc = row.get("Data Intelligence - Perpetual License - Line Description");
            }                                                    
            if(row.get("Data Intelligence- Maintenance - Sales Price")!=null && !row.get("Data Intelligence- Maintenance - Sales Price").equals("")) {
                diM_SalesPrice = row.get("Data Intelligence- Maintenance - Sales Price");
            }
            if(row.get("Data Intelligence- Maintenance - Quantity")!=null && !row.get("Data Intelligence- Maintenance - Quantity").equals("")) {
                diM_Quantity = row.get("Data Intelligence- Maintenance - Quantity");
            }
            if(row.get("Data Intelligence - Maintenance - Line Description")!=null && !row.get("Data Intelligence - Maintenance - Line Description").equals("")) {
                diM_LineDesc = row.get("Data Intelligence - Maintenance - Line Description");
            }
            if(row.get("Data Intelligence - Term License - Sales Price")!=null && !row.get("Data Intelligence - Term License - Sales Price").equals("")) {
                diTL_SalesPrice = row.get("Data Intelligence - Term License - Sales Price");
            }
            if(row.get("Data Intelligence - Term License - Quantity")!=null && !row.get("Data Intelligence - Term License - Quantity").equals("")) {
                diTL_Quantity = row.get("Data Intelligence - Term License - Quantity");
            }
            if(row.get("Data Intelligence - Term License - Line Description")!=null && !row.get("Data Intelligence - Term License - Line Description").equals("")) {
                diTL_LineDesc = row.get("Data Intelligence - Term License - Line Description");
            }
            if(row.get("Data Intelligence Professional Services  - Sales Price")!=null && !row.get("Data Intelligence Professional Services  - Sales Price").equals("")) {
                dips_SalesPrice = row.get("Data Intelligence Professional Services  - Sales Price");
            }
            if(row.get("Data Intelligence Professional Services - Quantity")!=null && !row.get("Data Intelligence Professional Services - Quantity").equals("")) {
                dips_Quantity = row.get("Data Intelligence Professional Services - Quantity");
            }
            if(row.get("Data Intelligence Professional Services - Line Description")!=null && !row.get("Data Intelligence Professional Services - Line Description").equals("")) {
                dips_LineDesc = row.get("Data Intelligence Professional Services - Line Description");
            } 
            if(row.get("Data Intelligence Professional Services Package - Sales Price")!=null && !row.get("Data Intelligence Professional Services Package - Sales Price").equals("")) {
                dipsp_SalesPrice = row.get("Data Intelligence Professional Services Package - Sales Price");
            }
            if(row.get("Data Intelligence Professional Services Package - Quantity")!=null && !row.get("Data Intelligence Professional Services Package - Quantity").equals("")) {
                dipsp_Quantity = row.get("Data Intelligence Professional Services Package - Quantity");
            }
            if(row.get("Data Intelligence Professional Services Package - Line Description")!=null && !row.get("Data Intelligence Professional Services Package - Line Description").equals("")) {
                dipsp_LineDesc = row.get("Data Intelligence Professional Services Package - Line Description");
            }
            if(row.get("Mobius - Perpetual License - Sales Price")!=null && !row.get("Mobius - Perpetual License - Sales Price").equals("")) {
                mobiusPL_SalesPrice = row.get("Mobius - Perpetual License - Sales Price");
            }
            if(row.get("Mobius - Perpetual License - Quantity")!=null && !row.get("Mobius - Perpetual License - Quantity").equals("")) {
                mobiusPL_Quantity = row.get("Mobius - Perpetual License - Quantity");
            }
            if(row.get("Mobius - Perpetual License - Line Description")!=null && !row.get("Mobius - Perpetual License - Line Description").equals("")) {
                mobiusPL_LineDesc = row.get("Mobius - Perpetual License - Line Description");
            }
            if(row.get("Mobius - Maintenance - Sales Price")!=null && !row.get("Mobius - Maintenance - Sales Price").equals("")) {
                mobiusM_SalesPrice = row.get("Mobius - Maintenance - Sales Price");
            }
            if(row.get("Mobius - Maintenance - Quantity")!=null && !row.get("Mobius - Maintenance - Quantity").equals("")) {
                mobiusM_Quantity = row.get("Mobius - Maintenance - Quantity");
            }
            if(row.get("Mobius - Maintenance - Line Description")!=null && !row.get("Mobius - Maintenance - Line Description").equals("")) {
                mobiusM_LineDesc = row.get("Mobius - Maintenance - Line Description");
            }
            if(row.get("Mobius - Term License - Sales Price")!=null && !row.get("Mobius - Term License - Sales Price").equals("")) {
                mobiusTL_SalesPrice = row.get("Mobius - Term License - Sales Price");
            }
            if(row.get("Mobius - Term License - Quantity")!=null && !row.get("Mobius - Term License - Quantity").equals("")) {
                mobiusTL_Quantity = row.get("Mobius - Term License - Quantity");
            }
            if(row.get("Mobius - Term License - Line Description")!=null && !row.get("Mobius - Term License - Line Description").equals("")) {
                mobiusTL_LineDesc = row.get("Mobius - Term License - Line Description");
            }
            if(row.get("Other Systems - Perpetual License - Sales Price")!=null && !row.get("Other Systems - Perpetual License - Sales Price").equals("")) {
                othPL_SalesPrice = row.get("Other Systems - Perpetual License - Sales Price");
            }
            if(row.get("Other Systems - Perpetual License - Quantity")!=null && !row.get("Other Systems - Perpetual License - Quantity").equals("")) {
                othPL_Quantity = row.get("Other Systems - Perpetual License - Quantity");
            }
            if(row.get("Other Systems - Perpetual License - Line Description")!=null && !row.get("Other Systems - Perpetual License - Line Description").equals("")) {
                othPL_LineDesc = row.get("Other Systems - Perpetual License - Line Description");
            }
            if(row.get("Other Systems - Maintenance - Sales Price")!=null && !row.get("Other Systems - Maintenance - Sales Price").equals("")) {
                othM_SalesPrice = row.get("Other Systems - Maintenance - Sales Price");
            }
            if(row.get("Other Systems - Maintenance - Quantity")!=null && !row.get("Other Systems - Maintenance - Quantity").equals("")) {
                othM_Quantity = row.get("Other Systems - Maintenance - Quantity");
            }
            if(row.get("Other Systems - Maintenance - Line Description")!=null && !row.get("Other Systems - Maintenance - Line Description").equals("")) {
                othM_LineDesc = row.get("Other Systems - Maintenance - Line Description");
            }
            if(row.get("Other Systems - Term License - Sales Price")!=null && !row.get("Other Systems - Term License - Sales Price").equals("")) {
                othTL_SalesPrice = row.get("Other Systems - Term License - Sales Price");
            }
            if(row.get("Other Systems - Term License - Quantity")!=null && !row.get("Other Systems - Term License - Quantity").equals("")) {
                othTL_Quantity = row.get("Other Systems - Term License - Quantity");
            }
            if(row.get("Other Systems - Term License - Line Description")!=null && !row.get("Other Systems - Term License - Line Description").equals("")) {
                othTL_LineDesc = row.get("Other Systems - Term License - Line Description");
            }
            if(row.get("Systems Professional Services - Sales Price")!=null && !row.get("Systems Professional Services - Sales Price").equals("")) {
                sps_SalesPrice = row.get("Systems Professional Services - Sales Price");
            }
            if(row.get("Systems Professional Services - Quantity")!=null && !row.get("Systems Professional Services - Quantity").equals("")) {
                sps_Quantity = row.get("Systems Professional Services - Quantity");
            }
            if(row.get("Systems Professional Services - Line Description")!=null && !row.get("Systems Professional Services - Line Description").equals("")) {
                sps_LineDesc = row.get("Systems Professional Services - Line Description");
            }
            if(row.get("Systems Professional Services Package - Sales Price")!=null && !row.get("Systems Professional Services Package - Sales Price").equals("")) {
                spsp_SalesPrice = row.get("Systems Professional Services Package - Sales Price");
            }
            if(row.get("Systems Professional Services Package - Quantity")!=null && !row.get("Systems Professional Services Package - Quantity").equals("")) {
                spsp_Quantity = row.get("Systems Professional Services Package - Quantity");
            }
            if(row.get("Systems Professional Services Package - Line Description")!=null && !row.get("Systems Professional Services Package - Line Description").equals("")) {
                spsp_LineDesc = row.get("Systems Professional Services Package - Line Description");
            }
            if(row.get("TMON - Perpetual License - Sales Price")!=null && !row.get("TMON - Perpetual License - Sales Price").equals("")) {
                tmonPL_SalesPrice = row.get("TMON - Perpetual License - Sales Price");
            }
            if(row.get("TMON - Perpetual License - Quantity")!=null && !row.get("TMON - Perpetual License - Quantity").equals("")) {
                tmonPL_Quantity = row.get("TMON - Perpetual License - Quantity");
            }
            if(row.get("TMON - Perpetual License - Line Description")!=null && !row.get("TMON - Perpetual License - Line Description").equals("")) {
                tmonPL_LineDesc = row.get("TMON - Perpetual License - Line Description");
            }
            if(row.get("TMON - Maintenance - Sales Price")!=null && !row.get("TMON - Maintenance - Sales Price").equals("")) {
                tmonM_SalesPrice = row.get("TMON - Maintenance - Sales Price");
            }
            if(row.get("TMON - Maintenance - Quantity")!=null && !row.get("TMON - Maintenance - Quantity").equals("")) {
                tmonM_Quantity = row.get("TMON - Maintenance - Quantity");
            }
            if(row.get("TMON - Maintenance - Line Description")!=null && !row.get("TMON - Maintenance - Line Description").equals("")) {
                tmonM_LineDesc = row.get("TMON - Maintenance - Line Description");
            }
            if(row.get("TMON - Term License - Sales Price")!=null && !row.get("TMON - Term License - Sales Price").equals("")) {
                tmonTL_SalesPrice = row.get("TMON - Term License - Sales Price");
            }
            if(row.get("TMON - Term License - Quantity")!=null && !row.get("TMON - Term License - Quantity").equals("")) {
                tmonTL_Quantity = row.get("TMON - Term License - Quantity");
            }
            if(row.get("TMON - Term License - Line Description")!=null && !row.get("TMON - Term License - Line Description").equals("")) {
                tmonTL_LineDesc = row.get("TMON - Term License - Line Description");
            }
            if(row.get("Zeke - Perpetual License - Sales Price")!=null && !row.get("Zeke - Perpetual License - Sales Price").equals("")) {
                zekePL_SalesPrice = row.get("Zeke - Perpetual License - Sales Price");
            }
            if(row.get("Zeke - Perpetual License - Quantity")!=null && !row.get("Zeke - Perpetual License - Quantity").equals("")) {
                zekePL_Quantity = row.get("Zeke - Perpetual License - Quantity");
            }
            if(row.get("Zeke - Perpetual License - Line Description")!=null && !row.get("Zeke - Perpetual License - Line Description").equals("")) {
                zekePL_LineDesc = row.get("Zeke - Perpetual License - Line Description");
            }
            if(row.get("Zeke - Maintenance - Sales Price")!=null && !row.get("Zeke - Maintenance - Sales Price").equals("")) {
                zekeM_SalesPrice = row.get("Zeke - Maintenance - Sales Price");
            }
            if(row.get("Zeke - Maintenance - Quantity")!=null && !row.get("Zeke - Maintenance - Quantity").equals("")) {
                zekeM_Quantity = row.get("Zeke - Maintenance - Quantity");
            }
            if(row.get("Zeke - Maintenance - Line Description")!=null && !row.get("Zeke - Maintenance - Line Description").equals("")) {
                zekeM_LineDesc = row.get("Zeke - Maintenance - Line Description");
            }
            if(row.get("Zeke - Term License - Sales Price")!=null && !row.get("Zeke - Term License - Sales Price").equals("")) {
                zekeTL_SalesPrice = row.get("Zeke - Term License - Sales Price");
            }
            if(row.get("Zeke - Term License - Quantity")!=null && !row.get("Zeke - Term License - Quantity").equals("")) {
                zekeTL_Quantity = row.get("Zeke - Term License - Quantity");
            }
            if(row.get("Zeke - Term License - Line Description")!=null && !row.get("Zeke - Term License - Line Description").equals("")) {
                zekeTL_LineDesc = row.get("Zeke - Term License - Line Description");
            }
            if(row.get("Zena - Perpetual License - Sales Price")!=null && !row.get("Zena - Perpetual License - Sales Price").equals("")) {
                zenaPL_SalesPrice = row.get("Zena - Perpetual License - Sales Price");
            }
            if(row.get("Zena - Perpetual License - Quantity")!=null && !row.get("Zena - Perpetual License - Quantity").equals("")) {
                zenaPL_Quantity = row.get("Zena - Perpetual License - Quantity");
            }
            if(row.get("Zena - Perpetual License - Line Description")!=null && !row.get("Zena - Perpetual License - Line Description").equals("")) {
                zenaPL_LineDesc = row.get("Zena - Perpetual License - Line Description");
            }
            if(row.get("Zena - Maintenance - Sales Price")!=null && !row.get("Zena - Maintenance - Sales Price").equals("")) {
                zenaM_SalesPrice = row.get("Zena - Maintenance - Sales Price");
            }
            if(row.get("Zena - Maintenance - Quantity")!=null && !row.get("Zena - Maintenance - Quantity").equals("")) {
                zenaM_Quantity = row.get("Zena - Maintenance - Quantity");
            }
            if(row.get("Zena - Maintenance - Line Description")!=null && !row.get("Zena - Maintenance - Line Description").equals("")) {
                zenaM_LineDesc = row.get("Zena - Maintenance - Line Description");
            }
            if(row.get("Zena - Term License - Sales Price")!=null && !row.get("Zena - Term License - Sales Price").equals("")) {
                zenaTL_SalesPrice = row.get("Zena - Term License - Sales Price");
            }
            if(row.get("Zena - Term License - Quantity")!=null && !row.get("Zena - Term License - Quantity").equals("")) {
                zenaTL_Quantity = row.get("Zena - Term License - Quantity");
            }
            if(row.get("Zena - Term License - Line Description")!=null && !row.get("Zena - Term License - Line Description").equals("")) {
                zenaTL_LineDesc = row.get("Zena - Term License - Line Description");
            }


            // Process if an Account was found, otherwise continue to next in loop.
            String oppId = "";
            Boolean changedStageFromClosed = false;
            String closedStageToRestore = "";
            if(thisAccountId!=null && !thisAccountId.equals("")) {
                
                Boolean oppExists = false;

                String queryForOpp = "SELECT Id, StageName FROM Opportunity WHERE ASG_Opportunity_ID__c <> null AND ASG_Opportunity_ID__c <> '' AND ASG_Opportunity_ID__c = '" + asgOppId + "'";
                List<SObject> oppSearchList = SalesforceUtility.querySf(pc, queryForOpp);

                String whatToDo = "";

                if(oppSearchList.size()>1) {
                    oppExists = true;
                    // We found more than one Opportunity in Salesforce for the ASG Opportunity ID.  Log an error...
                    TextFileUtility.writetoLogFile("ERROR: More than one Salesforce Opportunity found for ASG Opportunity ID: " + asgOppId, verboseLogFileName);
                    TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR: More than one Salesforce Opportunity found for ASG Opportunity ID: " + asgOppId, errorLogFileName);
                    continue;
                }
                else if(oppSearchList.size()==1) {
                    oppExists = true;
                    // We found one matching Opportunity.  If it is in a Closed status, do nothing for this row; continue to next loop.
                    if(oppSearchList.get(0).getSObjectField("StageName")!=null && (oppSearchList.get(0).getSObjectField("StageName").toString().startsWith("Closed") || oppSearchList.get(0).getSObjectField("StageName").toString().equals("Omitted (Duplicate)"))) {
                        TextFileUtility.writetoLogFile("PRE-EXISTING OPPORTUNITY IS CLOSED OR OMITTED (DUPLICATE) - ASG Opportunity ID: " + asgOppId + " | Salesforce Opportunity ID: " + oppSearchList.get(0).getId() + " | Stage: " + oppSearchList.get(0).getSObjectField("StageName").toString(), verboseLogFileName);
                        continue;
                    }
                    
                    // If the Opportunity IS NOT in a Closed status, update it.
                    whatToDo = "UPDATE";
                    oppId = oppSearchList.get(0).getId();
                    if(oppId==null || oppId.equals("")) {
                        TextFileUtility.writetoLogFile("ERROR!  oppId was null for an update!!", verboseLogFileName);
                        TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR!  oppId was null for an update!!", errorLogFileName);
                        continue;
                    }
                    // If oppId is populated, go ahead and delete the OpportunityLineItem children now so we can update currency on parent Opportunity if needed...
                    String queryOlisToDelete = "SELECT Id FROM OpportunityLineItem WHERE OpportunityId <> null AND OpportunityId <> '' AND OpportunityId = '" + oppId + "'";
                    List<SObject> olisToDeleteList = SalesforceUtility.querySf(pc, queryOlisToDelete);

                    com.sforce.soap.partner.DeleteResult[] deleteResultsOlis = null;
                    if(olisToDeleteList.size()>0) {
                        deleteResultsOlis = SalesforceUtility.deleteSObjs(pc, olisToDeleteList);
                        if(deleteResultsOlis!=null && deleteResultsOlis.length > 0) {
                            for (int i = 0; i < deleteResultsOlis.length; i++) {
                                if(deleteResultsOlis[i].getErrors()!=null && deleteResultsOlis[i].getErrors().length > 0) {
                                    for(int j = 0; j < deleteResultsOlis[i].getErrors().length; j++) {
                                        TextFileUtility.writetoLogFile("ERROR! OLI DELETION FAILED: " + deleteResultsOlis[i].getErrors()[j].getMessage(), verboseLogFileName);
                                        TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR! OLI DELETION FAILED: " + deleteResultsOlis[i].getErrors()[j].getMessage(), errorLogFileName);
                                        continue;
                                    }
                                }
                                else if(deleteResultsOlis[i].isSuccess()) {
                                    TextFileUtility.writetoLogFile("DELETED OLIS FOR ASG OPPORRTUNITY ID " + asgOppId + "; " + deleteResultsOlis[i].getSuccess(), verboseLogFileName);
                                }
                                else {
                                    TextFileUtility.writetoLogFile("ERROR!  Does not look like Salesforce DeleteResult returned an expected object.", verboseLogFileName);
                                    TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR!  Does not look like Salesforce DeleteResult returned an expected object.", errorLogFileName);
                                    continue;
                                }
                            }
                        }
                    }
                }
                else if(oppSearchList.size()==0) {
                    // No matching Opportunity found.  Insert one.
                    whatToDo = "INSERT";
                }

                TextFileUtility.writetoLogFile("DOES THE OPP ALREADY EXIST IN SALESFORCE? " + oppExists.toString(), verboseLogFileName);
                

                Boolean oppInSalesforce = false;

                List<SObject> oppsToInsert = new ArrayList<SObject>();
                List<SObject> oppsToUpdate = new ArrayList<SObject>();
                List<SObject> oppsToRestoreClosedStage = new ArrayList<SObject>();
                SObject oppToHandle = new SObject();
                oppToHandle.setType("Opportunity");
                oppToHandle.setSObjectField("Name", oppName);
                oppToHandle.setSObjectField("ASG_Opportunity_ID__c", asgOppId);
                oppToHandle.setSObjectField("AccountId", thisAccountId);
                if(thePartnerAccountId!=null && !thePartnerAccountId.equals("")) {
                    oppToHandle.setSObjectField("Partner_Name__c", thePartnerAccountId);
                }
                oppToHandle.setSObjectField("Channel_Type__c", directIndirect);
                oppToHandle.setSObjectField("Acquisition_Billing_Period__c", supportTerm);
                oppToHandle.setSObjectField("Rocket_Contracting_Entity__c", rocketContractingEntity);
                
                if(whatToDo.equals("INSERT") && stage.startsWith("Closed")) {
                    closedStageToRestore = stage;
                    stage = "6 - Contracting";
                    changedStageFromClosed = true;
                }
                oppToHandle.setSObjectField("StageName", stage);

                oppToHandle.setSObjectField("CloseDate", closeDate);
                oppToHandle.setSObjectField("CurrencyIsoCode", currency);
                oppToHandle.setSObjectField("RecordTypeId", recordTypeId);
                oppToHandle.setSObjectField("OwnerId", salesRepUserId);
                if(whatToDo.equals("UPDATE")) {
                    oppToHandle.setId(oppId);
                    oppsToUpdate.add(oppToHandle);
                }
                else if(whatToDo.equals("INSERT")) {
                    oppsToInsert.add(oppToHandle);
                }

                
                com.sforce.soap.partner.SaveResult[] saveResultsOpp = null;
                if(whatToDo.equals("INSERT")) {
                    saveResultsOpp = SalesforceUtility.insertSObjs(pc, oppsToInsert);
                }
                else if(whatToDo.equals("UPDATE")) {
                    oppInSalesforce = true;
                }
                /*
                else if(whatToDo.equals("UPDATE")) {
                    saveResultsOpp = SalesforceUtility.updateSObjs(pc, oppsToHandle);
                }
                */

                if(saveResultsOpp!=null && saveResultsOpp.length > 0) {
                    for (int i = 0; i < saveResultsOpp.length; i++) {
                        if(saveResultsOpp[i].getErrors()!=null && saveResultsOpp[i].getErrors().length > 0) {
                            for(int j = 0; j < saveResultsOpp[i].getErrors().length; j++) {
                                TextFileUtility.writetoLogFile("ERROR! OPP " + whatToDo + " SAVE: " + saveResultsOpp[i].getErrors()[j].getMessage(), verboseLogFileName);
                                TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR! OPP " + whatToDo + " SAVE: " + saveResultsOpp[i].getErrors()[j].getMessage(), errorLogFileName);
                                continue;
                            }
                        }
                        else if(saveResultsOpp[i].isSuccess()) {
                            TextFileUtility.writetoLogFile(whatToDo + " FOR OPP FOR ASG OPPORRTUNITY ID " + asgOppId + "; " + saveResultsOpp[i].getSuccess(), verboseLogFileName);
                            oppId = saveResultsOpp[i].getId();
                            oppInSalesforce = true;
                        }
                        else {
                            TextFileUtility.writetoLogFile("ERROR!  Does not look like Salesforce SaveResult returned an expected object.", verboseLogFileName);
                            TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR!  Does not look like Salesforce SaveResult returned an expected object.", errorLogFileName);
                            continue;
                        }
                    }
                }

                if(oppInSalesforce) {
                    // Add in the new line item state from the ASG CRM source data sheet...
                    List<SObject> olisToInsert = new ArrayList<SObject>();
                    
                    if(cps_SalesPrice!=null && !cps_SalesPrice.equals("") && cps_Quantity!=null && !cps_Quantity.equals("")) {
                        SObject cpsSObj = new SObject();
                        cpsSObj.setType("OpportunityLineItem");
                        cpsSObj.setSObjectField("OpportunityId", oppId);
                        cpsSObj.setSObjectField("Product2Id", cpsSkuId);
                        cpsSObj.setSObjectField("Sales_Price__c", cps_SalesPrice);
                        cpsSObj.setSObjectField("TotalPrice", cps_SalesPrice);
                        cpsSObj.setSObjectField("Quantity", cps_Quantity);
                        cpsSObj.setSObjectField("Description", cps_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(cpsSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        cpsSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(cpsSObj);
                    }

                    if(cpsp_SalesPrice!=null && !cpsp_SalesPrice.equals("") && cpsp_Quantity!=null && !cpsp_Quantity.equals("")) {
                        SObject cpspSObj = new SObject();
                        cpspSObj.setType("OpportunityLineItem");
                        cpspSObj.setSObjectField("OpportunityId", oppId);
                        cpspSObj.setSObjectField("Product2Id", cpspSkuId);
                        cpspSObj.setSObjectField("Sales_Price__c", cpsp_SalesPrice);
                        cpspSObj.setSObjectField("TotalPrice", cpsp_SalesPrice);
                        cpspSObj.setSObjectField("Quantity", cpsp_Quantity);
                        cpspSObj.setSObjectField("Description", cpsp_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(cpspSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        cpspSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(cpspSObj);
                    }

                    if(cypPL_SalesPrice!=null && !cypPL_SalesPrice.equals("") && cypPL_Quantity!=null && !cypPL_Quantity.equals("")) {
                        SObject cypPLSObj = new SObject();
                        cypPLSObj.setType("OpportunityLineItem");
                        cypPLSObj.setSObjectField("OpportunityId", oppId);
                        cypPLSObj.setSObjectField("Product2Id", cypPLSkuId);
                        cypPLSObj.setSObjectField("Sales_Price__c", cypPL_SalesPrice);
                        cypPLSObj.setSObjectField("TotalPrice", cypPL_SalesPrice);
                        cypPLSObj.setSObjectField("Quantity", cypPL_Quantity);
                        cypPLSObj.setSObjectField("Description", cypPL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(cypPLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        cypPLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(cypPLSObj);
                    }

                    if(cypM_SalesPrice!=null && !cypM_SalesPrice.equals("") && cypM_Quantity!=null && !cypM_Quantity.equals("")) {
                        SObject cypMSObj = new SObject();
                        cypMSObj.setType("OpportunityLineItem");
                        cypMSObj.setSObjectField("OpportunityId", oppId);
                        cypMSObj.setSObjectField("Product2Id", cypMSkuId);
                        cypMSObj.setSObjectField("Sales_Price__c", cypM_SalesPrice);
                        cypMSObj.setSObjectField("TotalPrice", cypM_SalesPrice);
                        cypMSObj.setSObjectField("Quantity", cypM_Quantity);
                        cypMSObj.setSObjectField("Description", cypM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(cypMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        cypMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(cypMSObj);
                    }
                    
                    if(cypTL_SalesPrice!=null && !cypTL_SalesPrice.equals("") && cypTL_Quantity!=null && !cypTL_Quantity.equals("")) {
                        SObject cypTLSObj = new SObject();
                        cypTLSObj.setType("OpportunityLineItem");
                        cypTLSObj.setSObjectField("OpportunityId", oppId);
                        cypTLSObj.setSObjectField("Product2Id", cypTLSkuId);
                        cypTLSObj.setSObjectField("Sales_Price__c", cypTL_SalesPrice);
                        cypTLSObj.setSObjectField("TotalPrice", cypTL_SalesPrice);
                        cypTLSObj.setSObjectField("Quantity", cypTL_Quantity);
                        cypTLSObj.setSObjectField("Description", cypTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(cypTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        cypTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(cypTLSObj);
                    }
                    
                    if(diPL_SalesPrice!=null && !diPL_SalesPrice.equals("") && diPL_Quantity!=null && !diPL_Quantity.equals("")) {
                        SObject diPLSObj = new SObject();
                        diPLSObj.setType("OpportunityLineItem");
                        diPLSObj.setSObjectField("OpportunityId", oppId);
                        diPLSObj.setSObjectField("Product2Id", diPLSkuId);
                        diPLSObj.setSObjectField("Sales_Price__c", diPL_SalesPrice);
                        diPLSObj.setSObjectField("TotalPrice", diPL_SalesPrice);
                        diPLSObj.setSObjectField("Quantity", diPL_Quantity);
                        diPLSObj.setSObjectField("Description", diPL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(diPLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        diPLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(diPLSObj);
                    }

                    if(diM_SalesPrice!=null && !diM_SalesPrice.equals("") && diM_Quantity!=null && !diM_Quantity.equals("")) {
                        SObject diMSObj = new SObject();
                        diMSObj.setType("OpportunityLineItem");
                        diMSObj.setSObjectField("OpportunityId", oppId);
                        diMSObj.setSObjectField("Product2Id", diMSkuId);
                        diMSObj.setSObjectField("Sales_Price__c", diM_SalesPrice);
                        diMSObj.setSObjectField("TotalPrice", diM_SalesPrice);
                        diMSObj.setSObjectField("Quantity", diM_Quantity);
                        diMSObj.setSObjectField("Description", diM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(diMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        diMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(diMSObj);
                    }

                    if(diTL_SalesPrice!=null && !diTL_SalesPrice.equals("") && diTL_Quantity!=null && !diTL_Quantity.equals("")) {
                        SObject diTLSObj = new SObject();
                        diTLSObj.setType("OpportunityLineItem");
                        diTLSObj.setSObjectField("OpportunityId", oppId);
                        diTLSObj.setSObjectField("Product2Id", diTLSkuId);
                        diTLSObj.setSObjectField("Sales_Price__c", diTL_SalesPrice);
                        diTLSObj.setSObjectField("TotalPrice", diTL_SalesPrice);
                        diTLSObj.setSObjectField("Quantity", diTL_Quantity);
                        diTLSObj.setSObjectField("Description", diTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(diTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        diTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(diTLSObj);
                    }

                    if(dips_SalesPrice!=null && !dips_SalesPrice.equals("") && dips_Quantity!=null && !dips_Quantity.equals("")) {
                        SObject dipsSObj = new SObject();
                        dipsSObj.setType("OpportunityLineItem");
                        dipsSObj.setSObjectField("OpportunityId", oppId);
                        dipsSObj.setSObjectField("Product2Id", dipsSkuId);
                        dipsSObj.setSObjectField("Sales_Price__c", dips_SalesPrice);
                        dipsSObj.setSObjectField("TotalPrice", dips_SalesPrice);
                        dipsSObj.setSObjectField("Quantity", dips_Quantity);
                        dipsSObj.setSObjectField("Description", dips_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(dipsSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        dipsSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(dipsSObj);
                    }

                    if(dipsp_SalesPrice!=null && !dipsp_SalesPrice.equals("") && dipsp_Quantity!=null && !dipsp_Quantity.equals("")) {
                        SObject dipspSObj = new SObject();
                        dipspSObj.setType("OpportunityLineItem");
                        dipspSObj.setSObjectField("OpportunityId", oppId);
                        dipspSObj.setSObjectField("Product2Id", dipspSkuId);
                        dipspSObj.setSObjectField("Sales_Price__c", dipsp_SalesPrice);
                        dipspSObj.setSObjectField("TotalPrice", dipsp_SalesPrice);
                        dipspSObj.setSObjectField("Quantity", dipsp_Quantity);
                        dipspSObj.setSObjectField("Description", dipsp_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(dipspSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        dipspSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(dipspSObj);
                    }

                    if(mobiusPL_SalesPrice!=null && !mobiusPL_SalesPrice.equals("") && mobiusPL_Quantity!=null && !mobiusPL_Quantity.equals("")) {
                        SObject mobiusPLSObj = new SObject();
                        mobiusPLSObj.setType("OpportunityLineItem");
                        mobiusPLSObj.setSObjectField("OpportunityId", oppId);
                        mobiusPLSObj.setSObjectField("Product2Id", mobiusPLSkuId);
                        mobiusPLSObj.setSObjectField("Sales_Price__c", mobiusPL_SalesPrice);
                        mobiusPLSObj.setSObjectField("TotalPrice", mobiusPL_SalesPrice);
                        mobiusPLSObj.setSObjectField("Quantity", mobiusPL_Quantity);
                        mobiusPLSObj.setSObjectField("Description", mobiusPL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(mobiusPLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        mobiusPLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(mobiusPLSObj);
                    }

                    if(mobiusM_SalesPrice!=null && !mobiusM_SalesPrice.equals("") && mobiusM_Quantity!=null && !mobiusM_Quantity.equals("")) {
                        SObject mobiusMSObj = new SObject();
                        mobiusMSObj.setType("OpportunityLineItem");
                        mobiusMSObj.setSObjectField("OpportunityId", oppId);
                        mobiusMSObj.setSObjectField("Product2Id", mobiusMSkuId);
                        mobiusMSObj.setSObjectField("Sales_Price__c", mobiusM_SalesPrice);
                        mobiusMSObj.setSObjectField("TotalPrice", mobiusM_SalesPrice);
                        mobiusMSObj.setSObjectField("Quantity", mobiusM_Quantity);
                        mobiusMSObj.setSObjectField("Description", mobiusM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(mobiusMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        mobiusMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(mobiusMSObj);
                    }

                    if(mobiusTL_SalesPrice!=null && !mobiusTL_SalesPrice.equals("") && mobiusTL_Quantity!=null && !mobiusTL_Quantity.equals("")) {
                        SObject mobiusTLSObj = new SObject();
                        mobiusTLSObj.setType("OpportunityLineItem");
                        mobiusTLSObj.setSObjectField("OpportunityId", oppId);
                        mobiusTLSObj.setSObjectField("Product2Id", mobiusTLSkuId);
                        mobiusTLSObj.setSObjectField("Sales_Price__c", mobiusTL_SalesPrice);
                        mobiusTLSObj.setSObjectField("TotalPrice", mobiusTL_SalesPrice);
                        mobiusTLSObj.setSObjectField("Quantity", mobiusTL_Quantity);
                        mobiusTLSObj.setSObjectField("Description", mobiusTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(mobiusTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        mobiusTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(mobiusTLSObj);
                    }

                    if(othPL_SalesPrice!=null && !othPL_SalesPrice.equals("") && othPL_Quantity!=null && !othPL_Quantity.equals("")) {
                        SObject othPLSObj = new SObject();
                        othPLSObj.setType("OpportunityLineItem");
                        othPLSObj.setSObjectField("OpportunityId", oppId);
                        othPLSObj.setSObjectField("Product2Id", othPLSkuId);
                        othPLSObj.setSObjectField("Sales_Price__c", othPL_SalesPrice);
                        othPLSObj.setSObjectField("TotalPrice", othPL_SalesPrice);
                        othPLSObj.setSObjectField("Quantity", othPL_Quantity);
                        othPLSObj.setSObjectField("Description", othPL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(othPLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        othPLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(othPLSObj);
                    }

                    if(othM_SalesPrice!=null && !othM_SalesPrice.equals("") && othM_Quantity!=null && !othM_Quantity.equals("")) {
                        SObject othMSObj = new SObject();
                        othMSObj.setType("OpportunityLineItem");
                        othMSObj.setSObjectField("OpportunityId", oppId);
                        othMSObj.setSObjectField("Product2Id", othMSkuId);
                        othMSObj.setSObjectField("Sales_Price__c", othM_SalesPrice);
                        othMSObj.setSObjectField("TotalPrice", othM_SalesPrice);
                        othMSObj.setSObjectField("Quantity", othM_Quantity);
                        othMSObj.setSObjectField("Description", othM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(othMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        othMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(othMSObj);
                    }

                    if(othTL_SalesPrice!=null && !othTL_SalesPrice.equals("") && othTL_Quantity!=null && !othTL_Quantity.equals("")) {
                        SObject othTLSObj = new SObject();
                        othTLSObj.setType("OpportunityLineItem");
                        othTLSObj.setSObjectField("OpportunityId", oppId);
                        othTLSObj.setSObjectField("Product2Id", othTLSkuId);
                        othTLSObj.setSObjectField("Sales_Price__c", othTL_SalesPrice);
                        othTLSObj.setSObjectField("TotalPrice", othTL_SalesPrice);
                        othTLSObj.setSObjectField("Quantity", othTL_Quantity);
                        othTLSObj.setSObjectField("Description", othTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(othTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        othTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(othTLSObj);
                    }

                    if(sps_SalesPrice!=null && !sps_SalesPrice.equals("") && sps_Quantity!=null && !sps_Quantity.equals("")) {
                        SObject spsSObj = new SObject();
                        spsSObj.setType("OpportunityLineItem");
                        spsSObj.setSObjectField("OpportunityId", oppId);
                        spsSObj.setSObjectField("Product2Id", spsSkuId);
                        spsSObj.setSObjectField("Sales_Price__c", sps_SalesPrice);
                        spsSObj.setSObjectField("TotalPrice", sps_SalesPrice);
                        spsSObj.setSObjectField("Quantity", sps_Quantity);
                        spsSObj.setSObjectField("Description", sps_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(spsSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        spsSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(spsSObj);
                    }

                    if(spsp_SalesPrice!=null && !spsp_SalesPrice.equals("") && spsp_Quantity!=null && !spsp_Quantity.equals("")) {
                        SObject spspSObj = new SObject();
                        spspSObj.setType("OpportunityLineItem");
                        spspSObj.setSObjectField("OpportunityId", oppId);
                        spspSObj.setSObjectField("Product2Id", spspSkuId);
                        spspSObj.setSObjectField("Sales_Price__c", spsp_SalesPrice);
                        spspSObj.setSObjectField("TotalPrice", spsp_SalesPrice);
                        spspSObj.setSObjectField("Quantity", spsp_Quantity);
                        spspSObj.setSObjectField("Description", spsp_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(spspSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        spspSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(spspSObj);
                    }

                    if(tmonPL_SalesPrice!=null && !tmonPL_SalesPrice.equals("") && tmonPL_Quantity!=null && !tmonPL_Quantity.equals("")) {
                        SObject tmonPLSObj = new SObject();
                        tmonPLSObj.setType("OpportunityLineItem");
                        tmonPLSObj.setSObjectField("OpportunityId", oppId);
                        tmonPLSObj.setSObjectField("Product2Id", tmonPLSkuId);
                        tmonPLSObj.setSObjectField("Sales_Price__c", tmonPL_SalesPrice);
                        tmonPLSObj.setSObjectField("TotalPrice", tmonPL_SalesPrice);
                        tmonPLSObj.setSObjectField("Quantity", tmonPL_Quantity);
                        tmonPLSObj.setSObjectField("Description", tmonPL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(tmonPLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        tmonPLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(tmonPLSObj);
                    }

                    if(tmonM_SalesPrice!=null && !tmonM_SalesPrice.equals("") && tmonM_Quantity!=null && !tmonM_Quantity.equals("")) {
                        SObject tmonMSObj = new SObject();
                        tmonMSObj.setType("OpportunityLineItem");
                        tmonMSObj.setSObjectField("OpportunityId", oppId);
                        tmonMSObj.setSObjectField("Product2Id", tmonMSkuId);
                        tmonMSObj.setSObjectField("Sales_Price__c", tmonM_SalesPrice);
                        tmonMSObj.setSObjectField("TotalPrice", tmonM_SalesPrice);
                        tmonMSObj.setSObjectField("Quantity", tmonM_Quantity);
                        tmonMSObj.setSObjectField("Description", tmonM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(tmonMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        tmonMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(tmonMSObj);
                    }

                    if(tmonTL_SalesPrice!=null && !tmonTL_SalesPrice.equals("") && tmonTL_Quantity!=null && !tmonTL_Quantity.equals("")) {
                        SObject tmonTLSObj = new SObject();
                        tmonTLSObj.setType("OpportunityLineItem");
                        tmonTLSObj.setSObjectField("OpportunityId", oppId);
                        tmonTLSObj.setSObjectField("Product2Id", tmonTLSkuId);
                        tmonTLSObj.setSObjectField("Sales_Price__c", tmonTL_SalesPrice);
                        tmonTLSObj.setSObjectField("TotalPrice", tmonTL_SalesPrice);
                        tmonTLSObj.setSObjectField("Quantity", tmonTL_Quantity);
                        tmonTLSObj.setSObjectField("Description", tmonTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(tmonTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        tmonTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(tmonTLSObj);
                    }

                    if(zekePL_SalesPrice!=null && !zekePL_SalesPrice.equals("") && zekePL_Quantity!=null && !zekePL_Quantity.equals("")) {
                        SObject zekePLSObj = new SObject();
                        zekePLSObj.setType("OpportunityLineItem");
                        zekePLSObj.setSObjectField("OpportunityId", oppId);
                        zekePLSObj.setSObjectField("Product2Id", zekePLSkuId);
                        zekePLSObj.setSObjectField("Sales_Price__c", zekePL_SalesPrice);
                        zekePLSObj.setSObjectField("TotalPrice", zekePL_SalesPrice);
                        zekePLSObj.setSObjectField("Quantity", zekePL_Quantity);
                        zekePLSObj.setSObjectField("Description", zekePL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(zekePLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        zekePLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(zekePLSObj);
                    }

                    if(zekeM_SalesPrice!=null && !zekeM_SalesPrice.equals("") && zekeM_Quantity!=null && !zekeM_Quantity.equals("")) {
                        SObject zekeMSObj = new SObject();
                        zekeMSObj.setType("OpportunityLineItem");
                        zekeMSObj.setSObjectField("OpportunityId", oppId);
                        zekeMSObj.setSObjectField("Product2Id", zekeMSkuId);
                        zekeMSObj.setSObjectField("Sales_Price__c", zekeM_SalesPrice);
                        zekeMSObj.setSObjectField("TotalPrice", zekeM_SalesPrice);
                        zekeMSObj.setSObjectField("Quantity", zekeM_Quantity);
                        zekeMSObj.setSObjectField("Description", zekeM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(zekeMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        zekeMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(zekeMSObj);
                    }

                    if(zekeTL_SalesPrice!=null && !zekeTL_SalesPrice.equals("") && zekeTL_Quantity!=null && !zekeTL_Quantity.equals("")) {
                        SObject zekeTLSObj = new SObject();
                        zekeTLSObj.setType("OpportunityLineItem");
                        zekeTLSObj.setSObjectField("OpportunityId", oppId);
                        zekeTLSObj.setSObjectField("Product2Id", zekeTLSkuId);
                        zekeTLSObj.setSObjectField("Sales_Price__c", zekeTL_SalesPrice);
                        zekeTLSObj.setSObjectField("TotalPrice", zekeTL_SalesPrice);
                        zekeTLSObj.setSObjectField("Quantity", zekeTL_Quantity);
                        zekeTLSObj.setSObjectField("Description", zekeTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(zekeTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        zekeTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(zekeTLSObj);
                    }

                    if(zenaPL_SalesPrice!=null && !zenaPL_SalesPrice.equals("") && zenaPL_Quantity!=null && !zenaPL_Quantity.equals("")) {
                        SObject zenaPLSObj = new SObject();
                        zenaPLSObj.setType("OpportunityLineItem");
                        zenaPLSObj.setSObjectField("OpportunityId", oppId);
                        zenaPLSObj.setSObjectField("Product2Id", zenaPLSkuId);
                        zenaPLSObj.setSObjectField("Sales_Price__c", zenaPL_SalesPrice);
                        zenaPLSObj.setSObjectField("TotalPrice", zenaPL_SalesPrice);
                        zenaPLSObj.setSObjectField("Quantity", zenaPL_Quantity);
                        zenaPLSObj.setSObjectField("Description", zenaPL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(zenaPLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        zenaPLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(zenaPLSObj);
                    }

                    if(zenaM_SalesPrice!=null && !zenaM_SalesPrice.equals("") && zenaM_Quantity!=null && !zenaM_Quantity.equals("")) {
                        SObject zenaMSObj = new SObject();
                        zenaMSObj.setType("OpportunityLineItem");
                        zenaMSObj.setSObjectField("OpportunityId", oppId);
                        zenaMSObj.setSObjectField("Product2Id", zenaMSkuId);
                        zenaMSObj.setSObjectField("Sales_Price__c", zenaM_SalesPrice);
                        zenaMSObj.setSObjectField("TotalPrice", zenaM_SalesPrice);
                        zenaMSObj.setSObjectField("Quantity", zenaM_Quantity);
                        zenaMSObj.setSObjectField("Description", zenaM_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(zenaMSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        zenaMSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(zenaMSObj);
                    }

                    if(zenaTL_SalesPrice!=null && !zenaTL_SalesPrice.equals("") && zenaTL_Quantity!=null && !zenaTL_Quantity.equals("")) {
                        SObject zenaTLSObj = new SObject();
                        zenaTLSObj.setType("OpportunityLineItem");
                        zenaTLSObj.setSObjectField("OpportunityId", oppId);
                        zenaTLSObj.setSObjectField("Product2Id", zenaTLSkuId);
                        zenaTLSObj.setSObjectField("Sales_Price__c", zenaTL_SalesPrice);
                        zenaTLSObj.setSObjectField("TotalPrice", zenaTL_SalesPrice);
                        zenaTLSObj.setSObjectField("Quantity", zenaTL_Quantity);
                        zenaTLSObj.setSObjectField("Description", zenaTL_LineDesc);
                        Map<String, String> thisCurrencyPbeMap = pbeMap.get(zenaTLSkuId);
                        String thisPbeId = thisCurrencyPbeMap.get(currency);
                        zenaTLSObj.setSObjectField("PricebookEntryId", thisPbeId);
                        olisToInsert.add(zenaTLSObj);
                    }

                    com.sforce.soap.partner.SaveResult[] oliSaveResults = SalesforceUtility.insertSObjs(pc, olisToInsert);
                    if(oliSaveResults!=null && oliSaveResults.length > 0) {
                        for (int i = 0; i < oliSaveResults.length; i++) {
                            if(oliSaveResults[i].getErrors()!=null && oliSaveResults[i].getErrors().length > 0) {
                                for(int j = 0; j < oliSaveResults[i].getErrors().length; j++) {
                                    TextFileUtility.writetoLogFile("ERROR! OLI INSERT SAVE: " + oliSaveResults[i].getErrors()[j].getMessage(), verboseLogFileName);
                                    TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR! OLI INSERT SAVE: " + oliSaveResults[i].getErrors()[j].getMessage(), errorLogFileName);
                                }
                            }
                            else if(oliSaveResults[i].isSuccess()) {
                                TextFileUtility.writetoLogFile("INSERTED OLIs FOR ASG OPPORRTUNITY ID " + asgOppId + "; " + oliSaveResults[i].getSuccess(), verboseLogFileName);
                            }
                            else {
    
                            }
                        }
                    }
                }

                // Update Opps and swtich net new "Closed..." opps with temp stage of "6 - Contracting" back to closed...
                com.sforce.soap.partner.SaveResult[] saveResultsUpdateOpp = SalesforceUtility.updateSObjs(pc, oppsToUpdate);
                if(saveResultsUpdateOpp!=null && saveResultsUpdateOpp.length > 0) {
                    for (int i = 0; i < saveResultsUpdateOpp.length; i++) {
                        if(saveResultsUpdateOpp[i].getErrors()!=null && saveResultsUpdateOpp[i].getErrors().length > 0) {
                            for(int j = 0; j < saveResultsUpdateOpp[i].getErrors().length; j++) {
                                TextFileUtility.writetoLogFile("ERROR! OPP " + whatToDo + " SAVE: " + saveResultsUpdateOpp[i].getErrors()[j].getMessage(), verboseLogFileName);
                                TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR! OPP " + whatToDo + " SAVE: " + saveResultsUpdateOpp[i].getErrors()[j].getMessage(), errorLogFileName);
                                continue;
                            }
                        }
                        else if(saveResultsUpdateOpp[i].isSuccess()) {
                            TextFileUtility.writetoLogFile(whatToDo + " FOR OPP FOR ASG OPPORRTUNITY ID " + asgOppId + "; " + saveResultsUpdateOpp[i].getSuccess(), verboseLogFileName);
                            oppId = saveResultsUpdateOpp[i].getId();
                            oppInSalesforce = true;
                        }
                        else {
                            TextFileUtility.writetoLogFile("ERROR!  Does not look like Salesforce SaveResult returned an expected object.", verboseLogFileName);
                            TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR!  Does not look like Salesforce SaveResult returned an expected object.", errorLogFileName);
                            continue;
                        }
                    }
                }
                
                if(changedStageFromClosed) {
                    SObject oppBackToClosed = new SObject();
                    oppBackToClosed.setType("Opportunity");
                    oppBackToClosed.setId(oppId);
                    oppBackToClosed.setSObjectField("StageName", closedStageToRestore);
                    oppsToRestoreClosedStage.add(oppBackToClosed);

                    com.sforce.soap.partner.SaveResult[] saveResultsRestorceClosedStageToOpp = SalesforceUtility.updateSObjs(pc, oppsToRestoreClosedStage);
                    if(saveResultsRestorceClosedStageToOpp!=null && saveResultsRestorceClosedStageToOpp.length > 0) {
                        for (int i = 0; i < saveResultsRestorceClosedStageToOpp.length; i++) {
                            if(saveResultsRestorceClosedStageToOpp[i].getErrors()!=null && saveResultsRestorceClosedStageToOpp[i].getErrors().length > 0) {
                                for(int j = 0; j < saveResultsRestorceClosedStageToOpp[i].getErrors().length; j++) {
                                    TextFileUtility.writetoLogFile("ERROR! OPP " + whatToDo + " SAVE: " + saveResultsRestorceClosedStageToOpp[i].getErrors()[j].getMessage(), verboseLogFileName);
                                    TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR! OPP " + whatToDo + " SAVE: " + saveResultsRestorceClosedStageToOpp[i].getErrors()[j].getMessage(), errorLogFileName);
                                    continue;
                                }
                            }
                            else if(saveResultsRestorceClosedStageToOpp[i].isSuccess()) {
                                TextFileUtility.writetoLogFile(whatToDo + " FOR OPP FOR ASG OPPORRTUNITY ID " + asgOppId + "; " + saveResultsRestorceClosedStageToOpp[i].getSuccess(), verboseLogFileName);
                                oppId = saveResultsRestorceClosedStageToOpp[i].getId();
                                oppInSalesforce = true;
                            }
                            else {
                                TextFileUtility.writetoLogFile("ERROR!  Does not look like Salesforce SaveResult returned an expected object.", verboseLogFileName);
                                TextFileUtility.writetoLogFile("OPP ID: " + asgOppId + " | ERROR!  Does not look like Salesforce SaveResult returned an expected object.", errorLogFileName);
                                continue;
                            }
                        }
                    }
                }                

                TextFileUtility.writetoLogFile("### END ASG OPP: " + asgOppId + " ###", verboseLogFileName);
            }
            else {
                TextFileUtility.writetoLogFile("ACCOUNT NOT FOUND FOR ASG CRM SITE_ID: " + asgCrmSiteId, verboseLogFileName);
                continue;
            }



        }

        cleanUpTotalBookingValue(totalBookingValueLogFileName);
        secondCleanUpForBookingValue(secondBookingValueLogFileName);

    }


    public static void cleanUpTotalBookingValue(String logFileName) {
        
        String queryForOpp = "SELECT Id, Total_Booking_Value__c, Total_License_Amount2__c, Total_Subscription_Amount2__c, Total_PrePackaged_Services__c, Total_First_Year_Maintenance__c FROM Opportunity WHERE ASG_Opportunity_ID__c <> null AND ASG_Opportunity_ID__c <> ''";
        List<SObject> oppSearchList = SalesforceUtility.querySf(pc, queryForOpp);

        for(SObject opp : oppSearchList) {
            String oppId = opp.getId();
            
            String totalBookingValueString = opp.getSObjectField("Total_Booking_Value__c") == null ? "0.00" : opp.getSObjectField("Total_Booking_Value__c").toString();
            String totalLicenseAmountString = opp.getSObjectField("Total_License_Amount2__c") == null ? "0.00" : opp.getSObjectField("Total_License_Amount2__c").toString();
            String totalSubscriptionAmountString = opp.getSObjectField("Total_Subscription_Amount2__c") == null ? "0.00" : opp.getSObjectField("Total_Subscription_Amount2__c").toString();
            String totalPrePacakgedServicesString = opp.getSObjectField("Total_PrePackaged_Services__c") == null ? "0.00" : opp.getSObjectField("Total_PrePackaged_Services__c").toString();
            String totalFirstYearMaintenanceString = opp.getSObjectField("Total_First_Year_Maintenance__c") == null ? "0.00" : opp.getSObjectField("Total_First_Year_Maintenance__c").toString();

            Double totalBookingValue = Double.parseDouble(totalBookingValueString);
            Double totalLicenseAmount = Double.parseDouble(totalLicenseAmountString);
            Double totalSubscriptionAmount = Double.parseDouble(totalSubscriptionAmountString);
            Double totalPrePacakgedServices = Double.parseDouble(totalPrePacakgedServicesString);
            Double totalFirstYearMaintenance = Double.parseDouble(totalFirstYearMaintenanceString);

            Double calculatedTotalBookingValue = ((totalLicenseAmount == null) ? 0.00 : totalLicenseAmount)+((totalSubscriptionAmount == null) ? 0.00 : totalSubscriptionAmount)  + ((totalPrePacakgedServices == null) ? 0.00 : totalPrePacakgedServices) + ((totalFirstYearMaintenance == null) ? 0.00 : totalFirstYearMaintenance);
            calculatedTotalBookingValue = Math.round(calculatedTotalBookingValue * 100) / 100.0;

            if(!totalBookingValue.equals(calculatedTotalBookingValue)) {
                TextFileUtility.writetoLogFile("OPP: " + oppId + " | RETRIEVED TOTAL BOOKING VALUE: " + totalBookingValue + " | CALCULATED TOTAL BOOKING VALUE: " + calculatedTotalBookingValue, logFileName);
                
                List<SObject> oppsForUpdate = new ArrayList<SObject>();
                SObject oppForUpdate = new SObject();
                oppForUpdate.setType("Opportunity");
                oppForUpdate.setId(oppId);
                oppForUpdate.setSObjectField("Total_Booking_Value__c", calculatedTotalBookingValue);
                oppsForUpdate.add(oppForUpdate);

                com.sforce.soap.partner.SaveResult[] saveResultsTbv = SalesforceUtility.updateSObjs(pc, oppsForUpdate);
                if(saveResultsTbv!=null && saveResultsTbv.length > 0) {
                    for (int i = 0; i < saveResultsTbv.length; i++) {
                        if(saveResultsTbv[i].getErrors()!=null && saveResultsTbv[i].getErrors().length > 0) {
                            for(int j = 0; j < saveResultsTbv[i].getErrors().length; j++) {
                                TextFileUtility.writetoLogFile("ERROR! OPP ID: " + oppId + " | SAVE FOR TBV: " + saveResultsTbv[i].getErrors()[j].getMessage(), verboseLogFileName);
                                TextFileUtility.writetoLogFile("ERROR! OPP ID: " + oppId + " | SAVE FOR TBV: " + saveResultsTbv[i].getErrors()[j].getMessage(), errorLogFileName);
                                continue;
                            }
                        }
                        else if(saveResultsTbv[i].isSuccess()) {
                            TextFileUtility.writetoLogFile("TBV SAVE FOR OPP FOR ASG OPPORRTUNITY ID " + oppId + "; " + saveResultsTbv[i].getSuccess(), verboseLogFileName);
                        }
                        else {
                            TextFileUtility.writetoLogFile("ERROR!  Does not look like Salesforce SaveResult for TBV returned an expected object.", verboseLogFileName);
                            TextFileUtility.writetoLogFile("OPP ID: " + oppId + " | ERROR!  Does not look like Salesforce SaveResult for TBV returned an expected object.", errorLogFileName);
                            continue;
                        }
                    }
                }                
            }

        }
    }


    public static void secondCleanUpForBookingValue(String logFileName) {
        File oliLoadFile = createOliUpdateFile(pc);

        long lines = 0;
        try {
            lines = Files.lines(oliLoadFile.toPath()).count();
        } 
        catch(Exception e) {
            e.printStackTrace();
        }

        if(lines>1) {
            bulkOliUpdate(pc, oliLoadFile);
        }
    }


    private static File createOliUpdateFile(PartnerConnection pc) {

        File oliLoadFile = new File("loadFiles/OliLoadFile_" + runDateTime + ".csv");
        List<String> headerRowFields = new ArrayList<String>();
        headerRowFields.add("Id");
        headerRowFields.add("Description");
        CsvUtility.startCsv(oliLoadFile, headerRowFields);

        String queryOlis = "";
        
        if(!crmIdToProcess.equals("")) {
            queryOlis = "SELECT Id, Product2.Name, OpportunityId, Description FROM OpportunityLineItem WHERE (NOT Product2.Name LIKE '%Professional Services%') AND OpportunityId IN (SELECT Id FROM Opportunity WHERE ASG_Opportunity_Id__c = '" + crmIdToProcess + "' AND RecordType.Name LIKE 'Acq%') ORDER BY OpportunityId, Product2.Name";
        }
        else if(processOnlyTheseRows.size()>0) {
            String processOnlyTheseRowsString = "";
            for(Map<String,String> row : processOnlyTheseRows) {
                processOnlyTheseRowsString += "'" + row.get("AsgCrmId") + "',";
            }
            processOnlyTheseRowsString = processOnlyTheseRowsString.substring(0,processOnlyTheseRowsString.length()-1);
            queryOlis = "SELECT Id, Product2.Name, OpportunityId, Description FROM OpportunityLineItem WHERE (NOT Product2.Name LIKE '%Professional Services%') AND OpportunityId IN (SELECT Id FROM Opportunity WHERE ASG_Opportunity_Id__c IN (" + processOnlyTheseRowsString + ") AND RecordType.Name LIKE 'Acq%') ORDER BY OpportunityId, Product2.Name";
        }
        else {
            queryOlis = "SELECT Id, Product2.Name, OpportunityId, Description FROM OpportunityLineItem WHERE (NOT Product2.Name LIKE '%Professional Services%') AND OpportunityId IN (SELECT Id FROM Opportunity WHERE ASG_Opportunity_Id__c <> null AND RecordType.Name LIKE 'Acq%') ORDER BY OpportunityId, Product2.Name";
        }

        try {
            // Set query batch size
            pc.setQueryOptions(200);
            
            // Make the query call and get the query results
            QueryResult qr = pc.query(queryOlis);
            
            boolean done = false;

            int totalOlisQueried = qr.getSize();
            System.out.println("TOTAL OPPORTUNITY LINE ITEMS SELECTED: " + totalOlisQueried);
            int recordsQueriedCounter = 0;
            int thisLoopStartCount = 1;
            // Loop through the batches of returned results
            while (!done) {
                SObject[] records = qr.getRecords();
                recordsQueriedCounter += records.length;
                String startingMessage = "Adding Opportunity Line Items to Update CSV: " + thisLoopStartCount + " - " + recordsQueriedCounter + " of " + totalOlisQueried;
                thisLoopStartCount += records.length;
                System.out.println(startingMessage);

                for(int i=0; i < records.length; i++) {
                    SObject oliForLoop = records[i];
                    if(oliForLoop!=null) {
                        String description = runDateTime.toString();
                        String[] dataForRow = new String[]{oliForLoop.getId(), description};
                        CsvUtility.writeToCsv(dataForRow, oliLoadFile);
                    }
                }

                if (qr.isDone()) {
                    done = true;
                } else {
                    qr = pc.queryMore(qr.getQueryLocator());
                }

            }
        } catch(ConnectionException ce) {
            ce.printStackTrace();
        }
        return oliLoadFile;
    }


    private static void bulkOliUpdate(PartnerConnection pc, File oliLoadFile) {
        try {
            BulkConnection bulkConnection = SalesforceUtility.getBulkConnection(pc);
            JobInfo job = SalesforceUtility.createJob("OpportunityLineItem", bulkConnection, "update");
            List<BatchInfo> batchInfoList = SalesforceUtility.createBatchesFromCSVFile(bulkConnection, job, oliLoadFile.getPath());
            SalesforceUtility.closeJob(bulkConnection, job.getId());
            SalesforceUtility.awaitCompletion(bulkConnection, job, batchInfoList);
            SalesforceUtility.checkResults(bulkConnection, job, batchInfoList);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    

    private static void setUpProperties() {
        // create and load default properties
        defaultProps = new Properties();
        FileInputStream in = null;
        try {
            in = new FileInputStream("defaultProperties");
            defaultProps.load(in);
            in.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }

        // create application properties with default
        appProperties = new Properties(defaultProps);

        try {
            // now load properties 
            // from last invocation
            in = new FileInputStream("appProperties");
            appProperties.load(in);
            in.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }


    public static int getLineNumber() {
        return new Throwable().getStackTrace()[0].getLineNumber();
    }    
}
