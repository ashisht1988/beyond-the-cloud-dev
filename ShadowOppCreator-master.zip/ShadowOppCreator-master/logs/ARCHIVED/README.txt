The logs/ARCHIVED directory is a location to store log files from previous runs.  
Please keep all such CSVs from your previous runs in this directory.